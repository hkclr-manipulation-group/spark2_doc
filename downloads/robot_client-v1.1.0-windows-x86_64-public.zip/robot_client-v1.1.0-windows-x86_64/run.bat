@echo off
cd /d "%~dp0"
"robot_client.exe" %*
