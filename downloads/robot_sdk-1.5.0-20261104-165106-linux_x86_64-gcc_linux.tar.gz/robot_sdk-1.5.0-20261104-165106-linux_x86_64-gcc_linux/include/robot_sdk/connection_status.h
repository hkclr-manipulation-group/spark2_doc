#pragma once
#include <cstdint>
namespace robot {
/** SDK-owned session liveness. A timeout remains latched until reconnect. */
struct ConnectionStatus {
    bool connected = false;
    bool telemetry_timed_out = false;
    uint32_t receive_age_ms = 0;
    uint32_t receive_timeout_ms = 3000;
};
}
