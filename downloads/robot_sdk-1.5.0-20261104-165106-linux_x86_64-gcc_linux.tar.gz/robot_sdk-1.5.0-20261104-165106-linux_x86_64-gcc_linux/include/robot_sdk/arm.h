#ifndef ROBOT_ARM_H
#define ROBOT_ARM_H

#include <functional>

#include "robot_sdk/export.h"
#include "robot_sdk/configurator.h"
#include "robot_sdk/result.h"
#include "robot_sdk/motion_options.h"
#include "robot_sdk/types.h"

namespace robot {

class Robot;

namespace internal {
class Robot;
}

/**
 * Per-arm motion, feedback, and configuration handle (public SDK).
 *
 * This non-owning handle must not outlive its Robot. Reacquire after moving
 * the Robot or reconnecting.
 * Joint vectors use JointValues / JointMask whose length must match
 * jointCount() / gripperJointCount() after connect() (0 / empty before connect).
 *
 */
class ROBOT_API Arm {
public:
    int index() const;

    int jointCount() const;
    int gripperJointCount() const;
    std::vector<std::string> jointNames() const;

    JointValues zeroJoints() const;
    JointMask allEnabledMask() const;

    RobotResult enableArmJoint(JointMask arm_state);
    RobotResult setArmSmoothingMethod(SmoothingMethod method);

    /** Preferred explicit timing overload. */
    RobotResult movePosAndWait(const JointValues& joints, const MotionOptions& options, float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use movePosAndWait(..., MotionOptions) instead of v,t")
    RobotResult movePosAndWait(
        const JointValues& arm_pos, int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
    /** Fresh Idle plus joint arrival within 1 degree (both arms for DualArm). */
    /** Preferred explicit timing overload. */
    RobotResult goHomeAndWait(const MotionOptions& options, float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use goHomeAndWait(..., MotionOptions) instead of v,t")
    RobotResult goHomeAndWait(
        int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
    RobotResult foldArmAndWait(
        int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    // Position move timing: t=0 uses v in (0,100]; t>0 ignores v and may only extend t.
    /** Preferred explicit timing overload. */
    RobotResult movePos(const JointValues& joints, const MotionOptions& options);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use movePos(..., MotionOptions) instead of v,t")
    RobotResult movePos(const JointValues& arm_pos, int v = 50, float t = 0);
    RobotResult movePosPath(
        const Path<JointValues>& arm_pos, Path<int> v, Path<float> t);
    RobotResult moveVel(const JointValues& arm_vel, int a = 10, float t = 0);
    RobotResult moveEEPoint(const Pose& arm_ee, int v = 50, float t = 0);
    RobotResult moveEEPointPath(const Path<Pose>& arm_ee, Path<int> v, Path<float> t);
    RobotResult moveEELine(const Pose& arm_ee, int v = 50, float t = 0);
    RobotResult moveEELinePath(const Path<Pose>& arm_ee, Path<int> v, Path<float> t);
    RobotResult moveToolPoint(const Pose& arm_tool, int v = 50, float t = 0);
    RobotResult moveToolPointPath(const Path<Pose>& arm_tool, Path<int> v, Path<float> t);
    RobotResult moveToolLine(const Pose& arm_tool, int v = 50, float t = 0);
    RobotResult moveToolLinePath(const Path<Pose>& arm_tool, Path<int> v, Path<float> t);
    /** All-zero joint target. Legacy t>0 ignores v; prefer the explicit options variants. */
    /** Preferred explicit timing overload. */
    RobotResult goHome(const MotionOptions& options);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use goHome(..., MotionOptions) instead of v,t")
    RobotResult goHome(int v = 50, float t = 0);
    RobotResult foldArm(int v = 50, float t = 0);
    /** Panel units [0,1]: 0=open, 1=close (not configurator safety limits). */
    RobotResult moveGripperPos(const JointValues& pos, int v = 50, float t = 0);
    /** moveGripperPos then wait until gripper feedback reaches the target (RT may stay Idle). */
    RobotResult moveGripperPosAndWait(
        const JointValues& pos, int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    /** Start drag teaching and recording. Starting after a stop replaces the previous recording. */
    RobotResult startTeach();
    /** Freeze recording without changing control mode; drag teaching remains active.
     * Waits for RT acknowledgment and execution feedback. The legacy protocol
     * records/stops all arms together.
     */
    RobotResult stopRecording();
    /** End recording and switch this arm to joint position hold using fresh feedback.
     * Retains the recording; waits for the hold command ACK, not physical settling.
     */
    RobotResult stopTeach();
    /** Export this arm's frozen RT recording to a client-side UTF-8 JSON file.
     * Requires stopRecording() or stopTeach() first and an RT supporting Teach RPC.
     * Replaces the destination only after the complete export succeeds.
     */
    RobotResult saveTrajectory(const std::string& local_path);
    RobotResult startPlayback();
    RobotResult stopPlayback();
    RobotResult resetPlayback();

    JointState getJointState() const;
    JointState getJointVel() const;
    JointState getJointTor() const;
    Pose getEEPose() const;
    Pose getToolPose() const;
    JointMask getArmJointEnabledMask() const;

    Configurator& getConfigurator();


private:
    friend class Robot;
    friend class internal::Robot;
    Arm(Robot& robot, int index);
    RobotResult ensureReady() const;
    Robot* robot_ = nullptr;
    int index_ = 0;
};

}  // namespace robot

#endif
