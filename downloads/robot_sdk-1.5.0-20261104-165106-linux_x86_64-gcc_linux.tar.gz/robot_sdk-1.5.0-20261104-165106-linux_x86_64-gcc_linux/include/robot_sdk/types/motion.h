#ifndef ROBOT_SDK_TYPES_MOTION_H
#define ROBOT_SDK_TYPES_MOTION_H

#include "robot_sdk/types/geometry.h"

#include <cstdint>
#include <vector>

namespace robot {

/** SDK-local smoothing; platform mapping is by name in toPlatformSmoothing(). */
enum class SmoothingMethod : uint8_t {
    kLinear,
    kCos,
    kCubic,
    kQuintic,
    kQuinticPath,  // required for multi-waypoint Path APIs
    kLowPassFilter,
    kNone,
};

/** Runtime-sized arm and gripper joint feedback. */
struct JointState {
    JointValues arm;
    JointValues gripper;
};

template<typename T> using Path = std::vector<T>;

enum class PlanResult {
    kSuccess = 0,
    kPoseNotReachable = 1,
    kLinearPathFailed = 2,
    kNone = 3,  // platform kNone; not a motion failure
};

inline bool isPlanResultOk(PlanResult result) {
    return result == PlanResult::kSuccess || result == PlanResult::kNone;
}

}  // namespace robot

#endif
