#ifndef ROBOT_SDK_TYPES_NETWORK_H
#define ROBOT_SDK_TYPES_NETWORK_H

#include <string>

namespace robot {

/** Robot network settings returned by getNetworkConfig(). */
struct NetworkConfig {
    std::string eth_ip;
    int eth_prefix = 24;
    std::string eth_netmask;
    std::string eth_gateway;
    std::string eth_dns;
    std::string server_ip;

    bool wifi_enable = false;
    std::string wifi_ssid;
    /** Empty when password is masked by the server (kGet). */
    std::string wifi_password;
};

}  // namespace robot

#endif
