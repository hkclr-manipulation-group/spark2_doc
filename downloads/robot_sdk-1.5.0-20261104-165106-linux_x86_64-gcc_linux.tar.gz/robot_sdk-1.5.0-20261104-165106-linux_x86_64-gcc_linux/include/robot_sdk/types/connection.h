#ifndef ROBOT_SDK_TYPES_CONNECTION_H
#define ROBOT_SDK_TYPES_CONNECTION_H

#include <cstdint>
#include <string>

#include "robot_sdk/export.h"

namespace robot {

struct DiscoveredRobot;

namespace detail {
class DiscoveredRobotBuilder;
}  // namespace detail

/**
 * Result of enumerateRobots(). Obtain only from enumerateRobots(); pass to connect().
 * User code cannot construct instances (passkey).
 */
struct DiscoveredRobot {
    std::string robot_name;
    std::string server_ip;
    uint32_t session_id;
    uint32_t last_handshake_sequence_id;
    int64_t time_offset_us;
    int64_t handshake_rtt_us;
    std::string robot_version;

    DiscoveredRobot(const DiscoveredRobot&) = default;
    DiscoveredRobot(DiscoveredRobot&&) = default;
    DiscoveredRobot& operator=(const DiscoveredRobot&) = default;
    DiscoveredRobot& operator=(DiscoveredRobot&&) = default;

    ROBOT_API std::string toString() const;

private:
    struct Key {};

    DiscoveredRobot(
        Key,
        std::string robot_name_in,
        std::string server_ip_in,
        uint32_t session_id_in,
        uint32_t last_handshake_sequence_id_in,
        int64_t time_offset_us_in,
        int64_t handshake_rtt_us_in,
        std::string robot_version_in);

    friend class detail::DiscoveredRobotBuilder;
};

}  // namespace robot

#endif
