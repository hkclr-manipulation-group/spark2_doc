#ifndef ROBOT_SDK_TYPES_DIAGNOSTIC_FLAGS_H
#define ROBOT_SDK_TYPES_DIAGNOSTIC_FLAGS_H

#include <cstdint>

namespace robot {

/** Raw wire-protocol diagnostic bits; keep aligned with platform::DiagnosticFlags. */
namespace DiagnosticFlags {
    constexpr uint64_t kNone = 0;

    constexpr uint64_t kTargetPosOutOfRange = 1ULL << 1;
    constexpr uint64_t kTargetVelOutOfRange = 1ULL << 2;
    constexpr uint64_t kTargetTorOutOfRange = 1ULL << 3;
    constexpr uint64_t kTargetPosSaturation = 1ULL << 4;
    constexpr uint64_t kTargetVelSaturation = 1ULL << 5;
    constexpr uint64_t kTargetTorSaturation = 1ULL << 6;

    constexpr uint64_t kActuatorPosSaturation = 1ULL << 7;
    constexpr uint64_t kActuatorVelSaturation = 1ULL << 8;
    constexpr uint64_t kActuatorTorSaturation = 1ULL << 9;
    constexpr uint64_t kActuatorPosJumpSaturation = 1ULL << 10;
    constexpr uint64_t kActuatorVelJumpSaturation = 1ULL << 11;
    constexpr uint64_t kActuatorTorJumpSaturation = 1ULL << 12;

    constexpr uint64_t kBoundaryVelClamp = 1ULL << 13;
    constexpr uint64_t kBoundaryJointImpedance = 1ULL << 14;

    constexpr uint64_t kPlanTimelineExtended = 1ULL << 15;
    constexpr uint64_t kPlanVelLimitInvalid = 1ULL << 16;
    constexpr uint64_t kPlanDeltaTooLarge = 1ULL << 17;
    constexpr uint64_t kPlanVelocitySnap = 1ULL << 18;
    constexpr uint64_t kPlanPointSkipped = 1ULL << 19;

    constexpr uint64_t kPlanInvalidSetting = 1ULL << 51;
    // RT execution rejection; correlated with the command sequence in telemetry.
    constexpr uint64_t kMotionCommandRejected = 1ULL << 52;
    constexpr uint64_t kMotionStartPosOutOfRange = 1ULL << 53;
    constexpr uint64_t kMotionProfilePosOutOfRange = 1ULL << 54;
    constexpr uint64_t kMotionBoundaryBlocked = 1ULL << 55;

    constexpr uint64_t kFaultPosHardLimitReached = 1ULL << 20;
    constexpr uint64_t kFaultVelHardLimitReached = 1ULL << 21;
    constexpr uint64_t kFaultTorHardLimitReached = 1ULL << 22;
    constexpr uint64_t kFaultPosTrackingFailed = 1ULL << 23;
    constexpr uint64_t kFaultVelTrackingFailed = 1ULL << 24;
    constexpr uint64_t kFaultTorTrackingFailed = 1ULL << 25;
    constexpr uint64_t kFaultArmNotFound = 1ULL << 26;
    constexpr uint64_t kFaultGripperNotFound = 1ULL << 27;
    constexpr uint64_t kFaultButtonNotFound = 1ULL << 28;
    constexpr uint64_t kFaultArmInitFailed = 1ULL << 29;
    constexpr uint64_t kFaultGripperInitFailed = 1ULL << 30;
    constexpr uint64_t kFaultButtonInitFailed = 1ULL << 31;
    // Compatibility mask matching any hardware initialization failure.
    constexpr uint64_t kFaultHardwareInitFailed =
        (1ULL << 29) | (1ULL << 30) | (1ULL << 31);
    constexpr uint64_t kFaultHardwareEnableFailed = 1ULL << 32;
    constexpr uint64_t kFaultHardwareChangeModeFailed = 1ULL << 33;
    constexpr uint64_t kFaultHardwareSetReadFailed = 1ULL << 34;
    constexpr uint64_t kFaultArmSizeMismatch = 1ULL << 35;
    constexpr uint64_t kFaultGripperSizeMismatch = 1ULL << 36;
    constexpr uint64_t kFaultArmJointSizeMismatch = 1ULL << 37;
    constexpr uint64_t kFaultGripperJointSizeMismatch = 1ULL << 38;
    constexpr uint64_t kFaultRobotNameMismatch = 1ULL << 39;
    constexpr uint64_t kFaultArmControlStrategyMismatch = 1ULL << 40;
    constexpr uint64_t kFaultCollisionDetected = 1ULL << 41;
    constexpr uint64_t kFaultRecoveryRequired = 1ULL << 42;
    // Legacy alias: the protocol has no separate unknown-fault bit.
    constexpr uint64_t kFaultUnknown = 1ULL << 63;

    constexpr uint64_t kInvalidControlTypeCombination = 1ULL << 43;
    constexpr uint64_t kCartesianControlRequirePositionTarget = 1ULL << 44;
    constexpr uint64_t kControlStrategyNotAvailable = 1ULL << 45;
    constexpr uint64_t kWaypointControlStrategyNotAllowed = 1ULL << 46;
    constexpr uint64_t kWaypointTargetTypeNotAllowed = 1ULL << 47;
    constexpr uint64_t kWaypointSmoothingMethodNotAllowed = 1ULL << 48;
    constexpr uint64_t kPlaybackControlRequirePositionTarget = 1ULL << 49;
    constexpr uint64_t kPlaybackControlStartPoseNotReachable = 1ULL << 50;
    constexpr uint64_t kUnknown = 1ULL << 63;
}  // namespace DiagnosticFlags

}  // namespace robot

#endif
