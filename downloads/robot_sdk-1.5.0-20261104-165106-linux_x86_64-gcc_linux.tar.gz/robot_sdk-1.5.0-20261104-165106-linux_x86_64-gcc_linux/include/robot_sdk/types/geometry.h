#ifndef ROBOT_SDK_TYPES_GEOMETRY_H
#define ROBOT_SDK_TYPES_GEOMETRY_H

#include <cstdint>
#include <initializer_list>
#include <vector>

namespace robot {

constexpr float kPi = 3.14159265358979323846f;
constexpr float kDegToRad = kPi / 180.0f;
constexpr float kRadToDeg = 180.0f / kPi;

struct Quaternion { float w, x, y, z; };

/** Intrinsic XYZ: roll about x, then pitch about y', then yaw about z''. */
struct EulerAngle { float roll, pitch, yaw; };

struct Position { float x, y, z; };

struct Pose { Position position; Quaternion orientation; };

/** Variable-length per-joint container. */
template<typename T>
struct JointVector {
    std::vector<T> values;

    JointVector() = default;
    explicit JointVector(std::vector<T> values) : values(std::move(values)) {}
    JointVector(std::initializer_list<T> init) : values(init) {}
    explicit JointVector(std::size_t count, const T& fill = T{})
        : values(count, fill) {}

    std::size_t size() const { return values.size(); }
    T& operator[](std::size_t index) { return values[index]; }
    const T& operator[](std::size_t index) const { return values[index]; }
    auto begin() { return values.begin(); }
    auto end() { return values.end(); }
    auto begin() const { return values.begin(); }
    auto end() const { return values.end(); }
};

/** std::vector<bool> uses bit proxies; expose bool by value for reads. */
template<>
struct JointVector<bool> {
    std::vector<bool> values;

    JointVector() = default;
    explicit JointVector(std::vector<bool> values) : values(std::move(values)) {}
    JointVector(std::initializer_list<bool> init) : values(init) {}
    explicit JointVector(std::size_t count, bool fill = true)
        : values(count, fill) {}

    std::size_t size() const { return values.size(); }
    bool operator[](std::size_t index) const { return values[index]; }
    auto begin() { return values.begin(); }
    auto end() { return values.end(); }
    auto begin() const { return values.begin(); }
    auto end() const { return values.end(); }
};

/** Joint positions in degrees; length must match jointCount() after connect(). */
using JointValues = JointVector<float>;

/** Per-joint enable mask; length must match jointCount() after connect(). */
using JointMask = JointVector<bool>;

template<typename T> struct JointLimits { T min; T max; };

using JointLimitValues = JointVector<JointLimits<float>>;
using JointDiagnosticFlags = JointVector<uint64_t>;

template<typename T>
inline JointVector<T> makeJointVector(int count, const T& fill = T{}) {
    return JointVector<T>(static_cast<std::size_t>(count > 0 ? count : 0), fill);
}

inline JointValues makeJointValues(int count, float fill = 0.f) {
    return makeJointVector<float>(count, fill);
}

inline JointMask makeJointMask(int count, bool enabled = true) {
    return makeJointVector<bool>(count, enabled);
}

inline JointLimitValues makeJointLimitValues(
    int count, JointLimits<float> fill = {-90.f, 90.f}) {
    return makeJointVector<JointLimits<float>>(count, fill);
}

inline JointDiagnosticFlags makeJointDiagnosticFlags(int count, uint64_t fill = 0) {
    return makeJointVector<uint64_t>(count, fill);
}

}  // namespace robot

#endif
