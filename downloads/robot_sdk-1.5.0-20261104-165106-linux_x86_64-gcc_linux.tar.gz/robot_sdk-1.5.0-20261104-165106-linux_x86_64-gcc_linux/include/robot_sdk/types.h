#ifndef ROBOT_SDK_TYPES_H
#define ROBOT_SDK_TYPES_H

/** Aggregates all public SDK data types (prefer topic headers for new code). */
#include "robot_sdk/types/geometry.h"
#include "robot_sdk/types/motion.h"
#include "robot_sdk/types/diagnostic_flags.h"
#include "robot_sdk/types/status.h"
#include "robot_sdk/types/connection.h"
#include "robot_sdk/types/network.h"

#endif
