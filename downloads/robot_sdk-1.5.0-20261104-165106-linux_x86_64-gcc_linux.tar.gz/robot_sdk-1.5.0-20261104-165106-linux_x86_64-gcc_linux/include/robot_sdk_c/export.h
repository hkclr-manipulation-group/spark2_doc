#ifndef ROBOT_C_API_EXPORT_H
#define ROBOT_C_API_EXPORT_H

#if defined(_WIN32) || defined(__CYGWIN__)
#  if defined(robot_sdk_c_EXPORTS)
#    define ROBOT_C_API __declspec(dllexport)
#  else
#    define ROBOT_C_API __declspec(dllimport)
#  endif
#else
#  if defined(robot_sdk_c_EXPORTS)
#    define ROBOT_C_API __attribute__((visibility("default")))
#  else
#    define ROBOT_C_API
#  endif
#endif

#if defined(robot_kinematics_c_EXPORTS)
#  if defined(_WIN32) || defined(__CYGWIN__)
#    define ROBOT_KINEMATICS_C_API __declspec(dllexport)
#  else
#    define ROBOT_KINEMATICS_C_API __attribute__((visibility("default")))
#  endif
#elif defined(_WIN32) || defined(__CYGWIN__)
#  define ROBOT_KINEMATICS_C_API __declspec(dllimport)
#else
#  define ROBOT_KINEMATICS_C_API
#endif

#endif
