#ifndef ROBOT_C_API_SESSION_H
#define ROBOT_C_API_SESSION_H

#include <stddef.h>

#include "robot_sdk_c/export.h"
#include "robot_sdk_c/result.h"
#include "robot_sdk_c/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* --- lifecycle --- */
ROBOT_C_API robot_session* robot_session_create(void);
ROBOT_C_API void robot_session_destroy(robot_session* session);

/* --- connection --- */
ROBOT_C_API robot_result robot_session_connect_discovered(
    robot_session* session, const robot_discovered_robot* robot);
ROBOT_C_API robot_result robot_session_connect_info(
    robot_session* session, const robot_rt_connection_info* info);
ROBOT_C_API robot_result robot_session_disconnect(robot_session* session);
ROBOT_C_API robot_result robot_session_release_control(robot_session* session);

ROBOT_C_API robot_result robot_session_trigger_safeguard_stop(robot_session* session);
ROBOT_C_API robot_result robot_session_stop_motion(
    robot_session* session, int wait_for_command_ack, float ack_timeout_ms);

/* --- connection state ---
 *
 * Both calls are pure reads of SDK-owned state: they never touch the network and
 * never run the watchdog, so they are safe to poll from a UI thread. */
ROBOT_C_API robot_result robot_session_get_connection_status(
    const robot_session* session, robot_connection_status* out_status);
/* 1 while the session is connected and telemetry has not timed out, else 0. */
ROBOT_C_API int robot_session_is_connected(const robot_session* session);

/* --- network configuration ---
 *
 * All four require a connected session; they are accepted by the robot over the
 * command channel. set_eth_static() and reset_network_config() drop the link, so
 * the caller must reconnect afterwards (possibly with a different IP). */
ROBOT_C_API robot_result robot_session_get_network_config(
    robot_session* session, robot_network_config* out_config, float ack_timeout_ms);
ROBOT_C_API robot_result robot_session_set_wifi(
    robot_session* session, const char* ssid, const char* password, int enable,
    float ack_timeout_ms);
ROBOT_C_API robot_result robot_session_set_eth_static(
    robot_session* session, const char* eth_ip, const char* eth_netmask,
    const char* eth_gateway, const char* eth_dns, float ack_timeout_ms);
ROBOT_C_API robot_result robot_session_reset_network_config(
    robot_session* session, float ack_timeout_ms);

/* --- metadata --- */
ROBOT_C_API int robot_session_arm_count(const robot_session* session);
ROBOT_C_API int robot_session_gripper_count(const robot_session* session);
ROBOT_C_API robot_result robot_session_robot_name(
    const robot_session* session, char* buffer, size_t capacity);
ROBOT_C_API int robot_session_joint_count(const robot_session* session);
ROBOT_C_API int robot_session_gripper_joint_count(const robot_session* session);
/* Active joint count for the arm at arm_index (0-based). Returns 0 when the
 * index is out of range or the session is not connected. Use this to size the
 * per-arm vectors passed to the dual-arm calls below. */
ROBOT_C_API int robot_session_arm_joint_count(
    const robot_session* session, int arm_index);
ROBOT_C_API robot_result robot_session_joint_names(
    const robot_session* session, char names[][ROBOT_NAME_MAX], size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_zero_joints(
    const robot_session* session, float* values, size_t capacity, size_t* out_count);
ROBOT_C_API robot_result robot_session_all_enabled_mask(
    const robot_session* session, int* values, size_t capacity, size_t* out_count);
/* Per-arm mirrors of the two helpers above; select the arm by index instead of
 * always reading arm 0. Useful when sizing dual-arm targets/masks. */
ROBOT_C_API robot_result robot_session_arm_zero_joints(
    const robot_session* session, int arm_index,
    float* values, size_t capacity, size_t* out_count);
ROBOT_C_API robot_result robot_session_arm_all_enabled_mask(
    const robot_session* session, int arm_index,
    int* values, size_t capacity, size_t* out_count);
ROBOT_C_API robot_result robot_session_enable_arm_joint(
    robot_session* session, const int* mask, size_t count);

/* --- motion completion --- */
ROBOT_C_API robot_result robot_session_wait_until_idle(
    robot_session* session, float timeout_sec, float poll_interval_sec);
typedef robot_result (*robot_move_fn)(robot_session* session, void* user_data);
ROBOT_C_API robot_result robot_session_move_and_wait(
    robot_session* session, robot_move_fn move, void* user_data,
    float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_move_pos_and_wait(
    robot_session* session, const float* arm_pos, size_t count, int v, float t,
    float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_go_home_and_wait(
    robot_session* session, int v, float t, float timeout_sec,
    float poll_interval_sec);
ROBOT_C_API robot_result robot_session_fold_arm_and_wait(
    robot_session* session, int v, float t, float timeout_sec,
    float poll_interval_sec);

/* Waits on gripper feedback rather than on robot state: RT keeps system_state at
 * Idle during gripper-only motion, so go_home_and_wait()/wait_until_idle() would
 * return before the jaws reach the target. */
ROBOT_C_API robot_result robot_session_move_gripper_pos_and_wait(
    robot_session* session, const float* pos, size_t count, int v, float t,
    float timeout_sec, float poll_interval_sec);

/* --- motion mode --- */
ROBOT_C_API robot_result robot_session_set_arm_smoothing_method(
    robot_session* session, robot_smoothing_method method);

/* --- manual motion --- */
ROBOT_C_API robot_result robot_session_move_pos(
    robot_session* session, const float* arm_pos, size_t count, int v, float t);
ROBOT_C_API robot_result robot_session_move_pos_path(
    robot_session* session, const robot_joint_path* path, const int* v,
    const float* t);
ROBOT_C_API robot_result robot_session_move_vel(
    robot_session* session, const float* arm_vel, size_t count, int a, float t);
ROBOT_C_API robot_result robot_session_move_ee_point(
    robot_session* session, const robot_pose* arm_ee, int v, float t);
ROBOT_C_API robot_result robot_session_move_ee_point_path(
    robot_session* session, const robot_pose_path* path, const int* v,
    const float* t);
ROBOT_C_API robot_result robot_session_move_ee_line(
    robot_session* session, const robot_pose* arm_ee, int v, float t);
ROBOT_C_API robot_result robot_session_move_ee_line_path(
    robot_session* session, const robot_pose_path* path, const int* v,
    const float* t);
ROBOT_C_API robot_result robot_session_move_tool_point(
    robot_session* session, const robot_pose* arm_tool, int v, float t);
ROBOT_C_API robot_result robot_session_move_tool_point_path(
    robot_session* session, const robot_pose_path* path, const int* v,
    const float* t);
ROBOT_C_API robot_result robot_session_move_tool_line(
    robot_session* session, const robot_pose* arm_tool, int v, float t);
ROBOT_C_API robot_result robot_session_move_tool_line_path(
    robot_session* session, const robot_pose_path* path, const int* v,
    const float* t);
ROBOT_C_API robot_result robot_session_go_home(
    robot_session* session, int v, float t);
ROBOT_C_API robot_result robot_session_fold_arm(
    robot_session* session, int v, float t);
ROBOT_C_API robot_result robot_session_move_gripper_pos(
    robot_session* session, const float* pos, size_t count, int v, float t);

/* --- synchronized dual-arm motion ---
 *
 * Both arms are commanded in a single packet (index 0 = left, 1 = right).
 * Every per-arm joint vector / path dof must match that arm's joint count
 * (see robot_session_arm_joint_count). Path calls require both paths to have
 * the same waypoint_count; v/t are shared timing paths across the two arms.
 * All calls require a connected dual-arm robot. */
ROBOT_C_API robot_result robot_session_dual_arm_enable_arm_joint(
    robot_session* session,
    const int* arm0_mask, size_t arm0_count,
    const int* arm1_mask, size_t arm1_count);

ROBOT_C_API robot_result robot_session_dual_arm_move_pos(
    robot_session* session,
    const float* arm0_pos, size_t arm0_count,
    const float* arm1_pos, size_t arm1_count, int v, float t);
ROBOT_C_API robot_result robot_session_dual_arm_move_pos_and_wait(
    robot_session* session,
    const float* arm0_pos, size_t arm0_count,
    const float* arm1_pos, size_t arm1_count, int v, float t,
    float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_dual_arm_move_pos_path(
    robot_session* session,
    const robot_joint_path* arm0_path, const robot_joint_path* arm1_path,
    const int* v, const float* t);
ROBOT_C_API robot_result robot_session_dual_arm_move_pos_path_and_wait(
    robot_session* session,
    const robot_joint_path* arm0_path, const robot_joint_path* arm1_path,
    const int* v, const float* t, float timeout_sec, float poll_interval_sec);

ROBOT_C_API robot_result robot_session_dual_arm_move_vel(
    robot_session* session,
    const float* arm0_vel, size_t arm0_count,
    const float* arm1_vel, size_t arm1_count, int a, float t);
ROBOT_C_API robot_result robot_session_dual_arm_move_vel_and_wait(
    robot_session* session,
    const float* arm0_vel, size_t arm0_count,
    const float* arm1_vel, size_t arm1_count, int a, float t,
    float timeout_sec, float poll_interval_sec);

ROBOT_C_API robot_result robot_session_dual_arm_move_ee_point(
    robot_session* session, const robot_pose* arm0_ee, const robot_pose* arm1_ee,
    int v, float t);
ROBOT_C_API robot_result robot_session_dual_arm_move_ee_point_and_wait(
    robot_session* session, const robot_pose* arm0_ee, const robot_pose* arm1_ee,
    int v, float t, float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_dual_arm_move_ee_point_path(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t);
ROBOT_C_API robot_result robot_session_dual_arm_move_ee_point_path_and_wait(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t, float timeout_sec, float poll_interval_sec);

ROBOT_C_API robot_result robot_session_dual_arm_move_ee_line(
    robot_session* session, const robot_pose* arm0_ee, const robot_pose* arm1_ee,
    int v, float t);
ROBOT_C_API robot_result robot_session_dual_arm_move_ee_line_and_wait(
    robot_session* session, const robot_pose* arm0_ee, const robot_pose* arm1_ee,
    int v, float t, float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_dual_arm_move_ee_line_path(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t);
ROBOT_C_API robot_result robot_session_dual_arm_move_ee_line_path_and_wait(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t, float timeout_sec, float poll_interval_sec);

ROBOT_C_API robot_result robot_session_dual_arm_move_tool_point(
    robot_session* session, const robot_pose* arm0_tool, const robot_pose* arm1_tool,
    int v, float t);
ROBOT_C_API robot_result robot_session_dual_arm_move_tool_point_and_wait(
    robot_session* session, const robot_pose* arm0_tool, const robot_pose* arm1_tool,
    int v, float t, float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_dual_arm_move_tool_point_path(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t);
ROBOT_C_API robot_result robot_session_dual_arm_move_tool_point_path_and_wait(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t, float timeout_sec, float poll_interval_sec);

ROBOT_C_API robot_result robot_session_dual_arm_move_tool_line(
    robot_session* session, const robot_pose* arm0_tool, const robot_pose* arm1_tool,
    int v, float t);
ROBOT_C_API robot_result robot_session_dual_arm_move_tool_line_and_wait(
    robot_session* session, const robot_pose* arm0_tool, const robot_pose* arm1_tool,
    int v, float t, float timeout_sec, float poll_interval_sec);
ROBOT_C_API robot_result robot_session_dual_arm_move_tool_line_path(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t);
ROBOT_C_API robot_result robot_session_dual_arm_move_tool_line_path_and_wait(
    robot_session* session,
    const robot_pose_path* arm0_path, const robot_pose_path* arm1_path,
    const int* v, const float* t, float timeout_sec, float poll_interval_sec);

ROBOT_C_API robot_result robot_session_dual_arm_go_home(
    robot_session* session, int v, float t);
ROBOT_C_API robot_result robot_session_dual_arm_go_home_and_wait(
    robot_session* session, int v, float t,
    float timeout_sec, float poll_interval_sec);

/* --- teach & playback --- */
ROBOT_C_API robot_result robot_session_start_teach(robot_session* session);
/* Freeze recording without changing drag/control mode. */
ROBOT_C_API robot_result robot_session_stop_recording(robot_session* session);
ROBOT_C_API robot_result robot_session_stop_teach(robot_session* session);
/* Export arm 0's frozen recording to a client-side JSON file (UTF-8 path). */
ROBOT_C_API robot_result robot_session_save_trajectory(robot_session* session, const char* local_path);
ROBOT_C_API robot_result robot_session_start_playback(robot_session* session);
ROBOT_C_API robot_result robot_session_stop_playback(robot_session* session);
ROBOT_C_API robot_result robot_session_reset_playback(robot_session* session);

/* --- feedback --- */
ROBOT_C_API robot_result robot_session_get_joint_state(
    const robot_session* session, robot_joint_state* out_state);
/* Per-arm feedback for the arm at arm_index; the plain variants read arm 0. */
ROBOT_C_API robot_result robot_session_arm_get_joint_state(
    const robot_session* session, int arm_index, robot_joint_state* out_state);
ROBOT_C_API robot_result robot_session_joint_positions(
    const robot_session* session, float* values, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_get_joint_vel(
    const robot_session* session, robot_joint_state* out_state);
ROBOT_C_API robot_result robot_session_get_joint_tor(
    const robot_session* session, robot_joint_state* out_state);
ROBOT_C_API robot_result robot_session_get_ee_pose(
    const robot_session* session, robot_pose* out_pose);
ROBOT_C_API robot_result robot_session_arm_get_ee_pose(
    const robot_session* session, int arm_index, robot_pose* out_pose);
ROBOT_C_API robot_result robot_session_get_tool_pose(
    const robot_session* session, robot_pose* out_pose);
ROBOT_C_API robot_result robot_session_arm_get_tool_pose(
    const robot_session* session, int arm_index, robot_pose* out_pose);
ROBOT_C_API robot_result robot_session_get_arm_joint_enabled_mask(
    const robot_session* session, int* values, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_get_status(
    const robot_session* session, robot_system_status* out_status);
ROBOT_C_API void robot_session_print_status(
    const robot_session* session, const robot_system_status* status);

/* --- events --- */
typedef void (*robot_state_changed_fn)(
    robot_robot_state previous, robot_robot_state current,
    const robot_system_status* status, void* user_data);

typedef void (*robot_motion_done_fn)(
    const robot_system_status* status, const robot_result* result,
    void* user_data);

ROBOT_C_API void robot_session_set_on_state_changed(
    robot_session* session, robot_state_changed_fn callback, void* user_data);

ROBOT_C_API void robot_session_set_on_motion_done(
    robot_session* session, robot_motion_done_fn callback, void* user_data);
ROBOT_C_API void robot_session_clear_event_callbacks(robot_session* session);

/* --- connection metrics --- */


#ifdef __cplusplus
}
#endif

#endif
