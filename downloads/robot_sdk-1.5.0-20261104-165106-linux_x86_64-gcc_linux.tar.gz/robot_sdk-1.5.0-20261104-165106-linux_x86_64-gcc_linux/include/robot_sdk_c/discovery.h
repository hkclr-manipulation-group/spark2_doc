#ifndef ROBOT_C_API_DISCOVERY_H
#define ROBOT_C_API_DISCOVERY_H

#include <stddef.h>

#include "robot_sdk_c/export.h"
#include "robot_sdk_c/result.h"
#include "robot_sdk_c/types.h"

#ifdef __cplusplus
extern "C" {
#endif

ROBOT_C_API robot_result robot_enumerate_robots(
    robot_discovered_robot* robots,
    size_t capacity,
    size_t* out_count);

#ifdef __cplusplus
}
#endif

#endif
