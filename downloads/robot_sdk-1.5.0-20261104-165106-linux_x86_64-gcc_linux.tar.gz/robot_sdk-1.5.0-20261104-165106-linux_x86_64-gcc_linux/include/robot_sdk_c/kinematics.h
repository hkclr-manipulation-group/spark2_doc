#ifndef ROBOT_C_API_KINEMATICS_H
#define ROBOT_C_API_KINEMATICS_H

#include <stddef.h>

#include "robot_sdk_c/export.h"
#include "robot_sdk_c/result.h"
#include "robot_sdk_c/types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct robot_kinematics robot_kinematics;

ROBOT_KINEMATICS_C_API robot_kinematics* robot_kinematics_create(
    const char* config_prefix_path, const char* model_id);
ROBOT_KINEMATICS_C_API void robot_kinematics_destroy(robot_kinematics* kin);

ROBOT_KINEMATICS_C_API int robot_kinematics_joint_count(const robot_kinematics* kin);

ROBOT_KINEMATICS_C_API robot_result robot_kinematics_forward_kinematics(
    const robot_kinematics* kin, const float* arm_pos, size_t count,
    robot_pose* out_pose);

ROBOT_KINEMATICS_C_API robot_result robot_kinematics_inverse_kinematics(
    const robot_kinematics* kin, const robot_pose* ee_pose, float* arm_pos,
    size_t count);

ROBOT_KINEMATICS_C_API robot_quaternion robot_kinematics_euler_to_quaternion(
    robot_kinematics* kin, robot_euler_angle euler);
ROBOT_KINEMATICS_C_API robot_euler_angle robot_kinematics_quaternion_to_euler(
    robot_kinematics* kin, robot_quaternion quat);
ROBOT_KINEMATICS_C_API robot_pose robot_kinematics_ee_to_tool_pose(
    robot_kinematics* kin, const robot_pose* ee_pose,
    const robot_position* tool_offset);
ROBOT_KINEMATICS_C_API robot_pose robot_kinematics_tool_to_ee_pose(
    robot_kinematics* kin, const robot_pose* tool_pose,
    const robot_position* tool_offset);

#ifdef __cplusplus
}
#endif

#endif
