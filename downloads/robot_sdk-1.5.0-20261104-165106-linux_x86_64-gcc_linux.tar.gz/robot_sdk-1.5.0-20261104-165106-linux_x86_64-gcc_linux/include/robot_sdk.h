#ifndef ROBOT_SDK_H
#define ROBOT_SDK_H

/**
 * Recommended entry point for third-party RT control applications.
 *
 * Includes core types, error handling, and the Robot session API.
 * Optional headers (include explicitly when needed):
 *   #include "robot_sdk/configurator.h"  — already pulled in via robot.h
 *   #include "robot_kinematics/kinematics.h" — offline FK/IK (separate library)
 */
#include "robot_sdk/types/geometry.h"
#include "robot_sdk/types/motion.h"
#include "robot_sdk/types/status.h"
#include "robot_sdk/types/connection.h"
#include "robot_sdk/result.h"
#include "robot_sdk/motion_options.h"
#include "robot_sdk/robot.h"
#include "robot_sdk/arm.h"
#include "robot_sdk/dual_arm.h"

#endif
