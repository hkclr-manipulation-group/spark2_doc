#include "example_common.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

int main(int argc, char* argv[]){
    std::cout << "Demonstrates connectToRobot / RtConnectionInfo (optional [IP] or --ip).\n\n";

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");

    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");

    std::cout << "\nConnected to rt_control.\n";

    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
