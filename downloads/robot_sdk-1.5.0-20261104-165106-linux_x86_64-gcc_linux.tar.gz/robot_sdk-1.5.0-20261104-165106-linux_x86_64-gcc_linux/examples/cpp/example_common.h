#ifndef ROBOT_EXAMPLE_COMMON_H
#define ROBOT_EXAMPLE_COMMON_H

#include "robot_sdk.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

namespace robot_example {

inline bool checkBool(bool ok, const char* context){
    if (ok){
        return true;
    }
    std::cerr << context << " failed\n";
    return false;
}

inline bool checkResult(const robot::RobotResult& result, const char* context){
    if (result){
        return true;
    }
    std::cerr << context << " failed: " << result.message
              << " (" << robot::errorCodeToString(result.code) << ")\n";
    return false;
}

#define ROBOT_CHECK(result, context) \
    do { \
        if (!robot_example::checkResult((result), (context))) { \
            return 1; \
        } \
    } while (0)

#define ROBOT_CHECK_BOOL(expr, context) \
    do { \
        if (!robot_example::checkBool((expr), (context))) { \
            return 1; \
        } \
    } while (0)

inline const char* robotStateName(robot::RobotState state){
    switch (state){
        case robot::RobotState::kStartup: return "Startup";
        case robot::RobotState::kIdle: return "Idle";
        case robot::RobotState::kMoving: return "Moving";
        case robot::RobotState::kSettling: return "Settling";
        case robot::RobotState::kError: return "Error";
        case robot::RobotState::kRecovery: return "Recovery";
        case robot::RobotState::kShutdown: return "Shutdown";
    }
    return "Unknown";
}





/** Enumerate robots and return the first entry; exits process on failure via ROBOT_CHECK callers. */
inline robot::DiscoveredRobot requireFirstRobot(){
    const std::vector<robot::DiscoveredRobot> robots = robot::enumerateRobots();
    if (robots.empty()){
        std::cerr << "enumerateRobots: no robots found on the network\n";
        std::exit(1);
    }
    for (const auto& robot : robots){
        std::cout << robot.toString() << "\n";
    }
    std::cout << "Found " << robots.size() << " robot(s); connecting to "
              << robots.front().server_ip
              << " (session_id=" << robots.front().session_id << ")\n";
    return robots.front();
}

/** Parse optional robot IP from argv: program [IP] or program --ip IP ... */
inline std::string robotIpFromArgs(int argc, char* argv[]){
    for (int i = 1; i + 1 < argc; ++i){
        if (std::strcmp(argv[i], "--ip") == 0){
            return argv[i + 1];
        }
    }
    if (argc >= 2 && argv[1][0] != '-'){
        return argv[1];
    }
    return "";
}

/** Enable all arm joints reported by the connected robot (after connect()). */
inline robot::RobotResult enableAllArmJoints(robot::Robot& robot){
    return robot.enableArmJoint(robot.allEnabledMask());
}

/** Wait using the SDK command-bound, fresh-state completion checks. */
template<class RobotLike>
inline bool printMotionFeedback(RobotLike& robot, float dt_sec, float timeout_sec,
    robot::JointState* joint_pos = nullptr, robot::Pose* tool_pose = nullptr,
    const std::string& prefix_text = "", const robot::JointValues& target_joints = {}) {
    (void)target_joints;
    // The SDK owns fresh-state and command-bound completion checks.
    const auto result = robot.waitUntilIdle(timeout_sec, std::max(.001f, dt_sec));
    if (joint_pos) *joint_pos = robot.getJointState();
    if (tool_pose) *tool_pose = robot.getToolPose();
    std::cout << prefix_text;
    robot.printStatus(robot.getStatus());
    if (!result) std::cout << result.message << "\n";
    return result.ok();
}

/** Connect to ip when non-empty, otherwise enumerate and use the first robot. */
inline robot::RobotResult connectToRobot(robot::Robot& robot, const std::string& ip = ""){
    if (!ip.empty()){
        std::cout << "Connecting to " << ip << "\n";
        return robot.connect(robot::RtConnectionInfo::to(ip));
    }
    return robot.connect(requireFirstRobot());
}

}  // namespace robot_example

#endif
