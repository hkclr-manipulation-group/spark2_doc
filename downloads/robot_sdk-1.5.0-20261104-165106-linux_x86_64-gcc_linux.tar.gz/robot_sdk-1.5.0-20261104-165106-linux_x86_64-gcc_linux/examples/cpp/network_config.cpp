#include "example_common.h"

#include <cstring>
#include <iostream>
#include <string>

using namespace robot;
using namespace robot_example;

namespace {

void printUsage(const char* program){
    std::cout
        << "Usage:\n"
        << "  " << program << " [--ip ROBOT_IP]\n"
        << "      Read current network settings (default).\n"
        << "  " << program << " [--ip ROBOT_IP] --set-eth IP NETMASK GATEWAY [DNS]\n"
        << "      Set wired static IP. Connection drops; example reconnects with the new IP.\n"
        << "  " << program << " [--ip ROBOT_IP] --set-wifi SSID PASSWORD\n"
        << "      Connect robot WiFi to a router (STA mode).\n"
        << "  " << program << " --reset\n"
        << "      Restore factory network settings from network.factory.env.\n";
}

void printNetworkConfig(const NetworkConfig& config){
    std::cout << "Network configuration:\n"
              << "  eth_ip=" << config.eth_ip << "\n"
              << "  eth_prefix=/" << config.eth_prefix << "\n"
              << "  eth_netmask=" << config.eth_netmask << "\n"
              << "  eth_gateway=" << config.eth_gateway << "\n"
              << "  eth_dns=" << (config.eth_dns.empty() ? "(none)" : config.eth_dns) << "\n"
              << "  server_ip=" << config.server_ip << "\n"
              << "  wifi_enable=" << (config.wifi_enable ? "true" : "false") << "\n"
              << "  wifi_ssid=" << (config.wifi_ssid.empty() ? "(none)" : config.wifi_ssid) << "\n"
              << "  wifi_password="
              << (config.wifi_password.empty() ? "(masked or none)" : config.wifi_password)
              << "\n";
}

bool fetchNetworkConfig(Robot& robot, NetworkConfig& config){
    const RobotResult result = robot.getNetworkConfig(config);
    if (!result){
        std::cerr << "getNetworkConfig failed: " << result.message
                  << " (" << errorCodeToString(result.code) << ")\n";
        return false;
    }
    return true;
}

struct Options {
    enum class Mode {
        kGet,
        kSetEth,
        kSetWifi,
        kReset,
    } mode = Mode::kGet;

    std::string eth_ip;
    std::string eth_netmask;
    std::string eth_gateway;
    std::string eth_dns;
    std::string wifi_ssid;
    std::string wifi_password;
    std::string robot_ip;
};

bool parseOptions(int argc, char* argv[], Options& options){
    for (int i = 1; i + 1 < argc; ++i){
        if (std::strcmp(argv[i], "--ip") == 0){
            options.robot_ip = argv[i + 1];
        }
    }

    for (int i = 1; i < argc; ++i){
        if (std::strcmp(argv[i], "--ip") == 0){
            ++i;
            continue;
        }

        if (std::strcmp(argv[i], "--set-eth") == 0){
            if (i + 3 >= argc){
                printUsage(argv[0]);
                return false;
            }
            options.mode = Options::Mode::kSetEth;
            options.eth_ip = argv[i + 1];
            options.eth_netmask = argv[i + 2];
            options.eth_gateway = argv[i + 3];
            if (i + 4 < argc && std::strcmp(argv[i + 4], "--ip") != 0){
                options.eth_dns = argv[i + 4];
            }
            return true;
        }

        if (std::strcmp(argv[i], "--set-wifi") == 0){
            if (i + 2 >= argc){
                printUsage(argv[0]);
                return false;
            }
            options.mode = Options::Mode::kSetWifi;
            options.wifi_ssid = argv[i + 1];
            options.wifi_password = argv[i + 2];
            return true;
        }

        if (std::strcmp(argv[i], "--reset") == 0){
            options.mode = Options::Mode::kReset;
            return true;
        }

        printUsage(argv[0]);
        return false;
    }

    return true;
}

}  // namespace

int main(int argc, char* argv[]){
    Options options;
    if (!parseOptions(argc, argv, options)){
        return 1;
    }

    std::cout << "Network configuration example (requires connect() first).\n";
    std::cout << "WARNING: --set-eth / --set-wifi / --reset change controller network. Lab use only.\n\n";

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, options.robot_ip), "connect");

    NetworkConfig config;
    if (options.mode == Options::Mode::kGet){
        if (!fetchNetworkConfig(robot, config)){
            return 1;
        }
        printNetworkConfig(config);
        ROBOT_CHECK(robot.disconnect(), "disconnect");
        return 0;
    }

    if (options.mode == Options::Mode::kSetEth){
        std::cout << "Setting wired static IP to " << options.eth_ip << " ...\n";
        ROBOT_CHECK(robot.setEthStatic(
            options.eth_ip,
            options.eth_netmask,
            options.eth_gateway,
            options.eth_dns),
            "setEthStatic");

        std::cout << "Connection dropped after IP change. Reconnecting to "
                  << options.eth_ip << " ...\n";
        ROBOT_CHECK(robot.connect(RtConnectionInfo::to(options.eth_ip)), "reconnect");

        if (!fetchNetworkConfig(robot, config)){
            return 1;
        }
        printNetworkConfig(config);
        ROBOT_CHECK(robot.disconnect(), "disconnect");
        return 0;
    }

    if (options.mode == Options::Mode::kSetWifi){
        std::cout << "Connecting robot WiFi to SSID \"" << options.wifi_ssid << "\" ...\n";
        ROBOT_CHECK(robot.setWifi(options.wifi_ssid, options.wifi_password), "setWifi");

        if (!fetchNetworkConfig(robot, config)){
            return 1;
        }
        printNetworkConfig(config);
        ROBOT_CHECK(robot.disconnect(), "disconnect");
        return 0;
    }

    if (options.mode == Options::Mode::kReset){
        std::cout << "Restoring factory network settings ...\n";
        ROBOT_CHECK(robot.resetNetworkConfig(), "resetNetworkConfig");

        if (!fetchNetworkConfig(robot, config)){
            return 1;
        }
        printNetworkConfig(config);
        std::cout << "If eth_ip changed, reconnect with RtConnectionInfo::to(new_ip).\n";
        ROBOT_CHECK(robot.disconnect(), "disconnect");
        return 0;
    }

    return 0;
}
