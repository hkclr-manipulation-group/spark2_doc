
#include "example_common.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

int main(int argc, char* argv[]){
    std::cout << "Demonstrates movePosAndWait / goHomeAndWait / moveAndWait (P0).\n\n";

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");

    const int v = 30;
    const float timeout_sec = 60.f;
    const float poll_interval_sec = 0.1f;

    std::cout << "==> movePosAndWait\n";
    ROBOT_CHECK(
        robot.movePosAndWait({10.f, 20.f, 30.f, 40.f, 50.f, 60.f}, v, 0.f, timeout_sec, poll_interval_sec),
        "movePosAndWait");

    const auto pos = robot.getJointState();
    std::cout << "Reached joint position: ";
    for (std::size_t i = 0; i < pos.arm.size(); ++i){
        std::cout << pos.arm[i] << " ";
    }
    std::cout << "\n";

    std::cout << "\n==> moveAndWait (custom lambda)\n";
    ROBOT_CHECK(
        robot.moveAndWait(
            [&]() { return robot.moveToolPoint(robot.getToolPose(), v, 0.f); },
            timeout_sec,
            poll_interval_sec),
        "moveAndWait");

    std::cout << "\n==> goHomeAndWait\n";
    ROBOT_CHECK(robot.goHomeAndWait(20, 5.f, timeout_sec, poll_interval_sec), "goHomeAndWait");


    ROBOT_CHECK(robot.disconnect(), "disconnect");
    std::cout << "\nAll motions completed via wait-until-idle APIs.\n";
    return 0;
}
