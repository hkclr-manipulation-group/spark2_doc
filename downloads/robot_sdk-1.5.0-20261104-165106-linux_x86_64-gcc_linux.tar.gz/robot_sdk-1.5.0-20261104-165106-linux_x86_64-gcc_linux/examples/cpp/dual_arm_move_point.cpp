/**
 * Synchronized dual-arm point motions (public SDK).
 *
 * Ported from dual_arm_sdk/cpp/examples/move_point.cpp.
 * Requires a robot with arm_count >= 2.
 */

#include "example_common.h"
#include "robot_sdk.h"

#include <iostream>
#include <string>

using namespace robot;
using namespace robot_example;

namespace {

void printJointState(const Robot& robot, int arm_index, const char* label) {
    const JointState state = robot.arm(arm_index).getJointState();
    std::cout << label << " joints (" << state.arm.size() << "): ";
    for (float joint : state.arm) {
        std::cout << joint << " ";
    }
    std::cout << "\n";
}

Pose makeToolPoseLeft() {
    Pose pose{};
    pose.position = {0.363605f, 0.760355f, 1.33114f};
    pose.orientation = {0.680006f, -0.645236f, -0.200654f, 0.284605f};
    return pose;
}

Pose makeToolPoseRight() {
    Pose pose{};
    pose.position = {0.363605f, -0.760355f, 1.33114f};
    pose.orientation = {0.645234f, -0.680031f, 0.284588f, -0.200598f};
    return pose;
}

JointValues makeJointTarget(const Arm& arm, float j4_deg) {
    JointValues target = arm.zeroJoints();
    if (target.size() > 3) {
        target[3] = j4_deg;
    }
    if (target.size() > 4) target[4] = 5.f;
    if (target.size() > 5) target[5] = 5.f;
    if (target.size() > 6) {
        target[6] = 5.f;
    }
    return target;
}

}  // namespace

int main(int argc, char* argv[]) {
    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");

    const int arm_count = robot.armCount();
    std::cout << "arm_count=" << arm_count << "\n";
    if (arm_count < 2) {
        std::cerr << "This example requires a dual-arm robot (arm_count >= 2).\n";
        return 1;
    }

    ROBOT_CHECK(
        robot.dualArm().enableArmJoint(robot.arm(0).allEnabledMask(), robot.arm(1).allEnabledMask()),
        "enableArmJoint both");
    std::cout << "Both arms enabled\n";

    printJointState(robot, 0, "Left");
    printJointState(robot, 1, "Right");

    const int v = 30;
    const float t = 0.f; // Speed mode: v remains the active speed limit.
    DualArm both = robot.dualArm();

    std::cout << "==> movePos both arms\n";
    ROBOT_CHECK(
        both.movePosAndWait(
            makeJointTarget(robot.arm(0), 45.f),
            makeJointTarget(robot.arm(1), 45.f),
            MotionOptions::speedLimited(v)),
        "dual_arm.movePosAndWait");
    printJointState(robot, 0, "Left");
    printJointState(robot, 1, "Right");

    std::cout << "==> moveToolPoint both arms\n";
    ROBOT_CHECK(
        both.moveToolPointAndWait(makeToolPoseLeft(), makeToolPoseRight(), v, t),
        "dual_arm.moveToolPointAndWait");

    std::cout << "==> movePos with different targets\n";
    ROBOT_CHECK(
        both.movePosAndWait(
            makeJointTarget(robot.arm(0), 45.f),
            makeJointTarget(robot.arm(1), 30.f),
            MotionOptions::speedLimited(v)),
        "dual_arm.movePosAndWait (different targets)");

    std::cout << "==> moveToolLine both arms\n";
    ROBOT_CHECK(
        both.moveToolLineAndWait(makeToolPoseLeft(), makeToolPoseRight(), v, t),
        "dual_arm.moveToolLineAndWait");

    std::cout << "==> goHome both arms\n";
    ROBOT_CHECK(both.goHomeAndWait(MotionOptions::speedLimited(20)), "dual_arm.goHomeAndWait");

    std::cout << "Motion completed\n";
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
