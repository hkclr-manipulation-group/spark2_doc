from utils import (
    check_result,
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    print("Demonstrates move_pos_and_wait / go_home_and_wait / move_and_wait (P0).\n")

    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)

        v = 30
        timeout_sec = 60.0
        poll_interval_sec = 0.1

        print("==> move_pos_and_wait")
        check_result(
            robot.move_pos_and_wait(
                [10.0, 20.0, 30.0, 40.0, 50.0, 60.0],
                v,
                0.0,
                timeout_sec,
                poll_interval_sec,
            ),
            "move_pos_and_wait",
        )
        pos = robot.get_joint_state()
        print("Reached joint position:", list(pos.arm))

        print("\n==> move_and_wait (custom callable)")
        check_result(
            robot.move_and_wait(
                lambda: robot.move_tool_point(robot.get_tool_pose(), v, 0.0),
                timeout_sec,
                poll_interval_sec,
            ),
            "move_and_wait",
        )

        print("\n==> go_home_and_wait")
        check_result(
            robot.go_home_and_wait(20, 5.0, timeout_sec, poll_interval_sec),
            "go_home_and_wait",
        )


    print("\nAll motions completed via wait-until-idle APIs.")


if __name__ == "__main__":
    main()
