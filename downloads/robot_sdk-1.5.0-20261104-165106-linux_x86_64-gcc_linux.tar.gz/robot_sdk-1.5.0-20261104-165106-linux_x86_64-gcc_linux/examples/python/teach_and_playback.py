from utils import (
    print_feedback,
    check_result,
    check_bool,
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)


def main() -> None:
    parser = build_robot_ip_parser()
    parser.add_argument("--trajectory", help="Export the frozen RT recording to this client-side JSON file")
    args = parser.parse_args()
    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)
        print("Arm started")

        print_dt = 0.3
        timeout = 50.0

        input("Press Enter to START TEACH...")
        check_result(robot.start_teach(), "start_teach")

        input("Press Enter to STOP RECORDING (drag remains enabled)...")
        check_result(robot.stop_recording(), "stop_recording")

        input("Press Enter to END TEACH and HOLD the current position...")
        check_result(robot.stop_teach(), "stop_teach")

        if args.trajectory:
            check_result(robot.save_trajectory(args.trajectory), "save_trajectory")

        input("Press Enter to MOVE TO INITIAL POSITION of playback...")
        check_result(robot.reset_playback(), "reset_playback")
        check_bool(
            print_feedback(
                robot, print_dt, timeout, "==> Go to initial position of playback.\n", print_joint=True
            ),
            "wait after reset_playback",
        )

        input("Press Enter to START REPLAY...")
        check_result(robot.start_playback(), "start_playback")
        check_bool(
            print_feedback(robot, print_dt, timeout, "==> Playback\n", print_joint=True),
            "wait after start_playback",
        )

        input("Press Enter to STOP REPLAY...")
        check_result(robot.stop_playback(), "stop_playback")

        input("Press Enter to GO HOME...")
        check_result(robot.go_home(30, 0), "go_home")
        check_bool(
            print_feedback(robot, print_dt, timeout, "==> Go home.\n", print_joint=True),
            "wait after go_home",
        )

        print("Motion completed")


if __name__ == "__main__":
    main()
