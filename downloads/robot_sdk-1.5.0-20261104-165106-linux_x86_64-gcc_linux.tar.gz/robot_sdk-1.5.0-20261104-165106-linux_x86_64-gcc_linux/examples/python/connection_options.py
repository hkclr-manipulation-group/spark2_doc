"""Demonstrates connect via optional IP or auto-discovery (same as other examples)."""

from utils import (
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    print("Demonstrates get_robot_connection / connect (optional [IP]).\n")

    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)
        print("\nConnected to rt_control.")


if __name__ == "__main__":
    main()
