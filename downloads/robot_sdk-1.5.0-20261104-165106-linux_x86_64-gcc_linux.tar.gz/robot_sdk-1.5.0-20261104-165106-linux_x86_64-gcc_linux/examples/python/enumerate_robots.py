"""Probe the LAN for rt_control servers (enumerate_robots)."""

from __future__ import annotations

import argparse
import sys

from robot_sdk import Robot, enumerate_robots
from utils import disconnect_quietly


def print_discovered_robots(robots) -> None:
    print(f"Found {len(robots)} robot(s):")
    for index, entry in enumerate(robots):
        rtt_ms = entry.handshake_rtt_us / 1000.0
        print(f"  [{index}] {entry!r}")
        print(f"      handshake_rtt_ms={rtt_ms:.3f}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Search for rt_control robots on the local network.",
    )
    parser.add_argument(
        "--connect",
        nargs="?",
        const=0,
        type=int,
        metavar="INDEX",
        help="After search, connect to robot at INDEX (default 0) and disconnect",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()

    print("Probe the LAN for rt_control servers (enumerate_robots).\n")
    robots = enumerate_robots()
    if not robots:
        print(
            "No robots found.\n"
            "Tips:\n"
            "  - Ensure cuarm_rt_control is running and reachable on the same subnet.\n"
            "  - WiFi may block broadcast/multicast; SDK falls back to unicast subnet sweep.\n"
            "  - If search still fails, use move_point.py <IP> or RtConnectionInfo.to(ip).",
            file=sys.stderr,
        )
        sys.exit(1)

    print_discovered_robots(robots)

    if args.connect is None:
        print(
            "\nSearch complete. Pass --connect [INDEX] to verify connect() on a listed robot."
        )
        return

    index = args.connect
    if index < 0 or index >= len(robots):
        print(f"Index {index} out of range (0..{len(robots) - 1}).", file=sys.stderr)
        sys.exit(1)

    chosen = robots[index]
    print(f"\nConnecting to [{index}] {chosen.server_ip} ...")
    robot = Robot()
    try:
        result = robot.connect(chosen)
        if not result.ok:
            print(f"connect failed: {result.message} ({result.code.name})", file=sys.stderr)
            sys.exit(1)
        print(f"Connected. robot_name={robot.robot_name()}")
    finally:
        disconnect_quietly(robot)


if __name__ == "__main__":
    main()
