"""Read or update robot network settings via get_network_config / set_eth_static / set_wifi."""

import argparse

from robot_sdk import Robot, RtConnectionInfo
from utils import check_result, print_network_config, get_robot_connection, disconnect_quietly


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Network configuration example (requires connect() first)."
    )
    parser.add_argument(
        "--ip",
        dest="robot_ip",
        default=None,
        help="RT server IP address (auto-discover first robot if omitted)",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--set-eth",
        nargs="+",
        metavar=("IP", "NETMASK", "GATEWAY"),
        help="Set wired static IP. Optional 4th argument: DNS (space-separated list).",
    )
    group.add_argument(
        "--set-wifi",
        nargs=2,
        metavar=("SSID", "PASSWORD"),
        help="Connect robot WiFi to a router (STA mode).",
    )
    group.add_argument(
        "--reset",
        action="store_true",
        help="Restore factory network settings from network.factory.env.",
    )
    return parser


def fetch_network_config(robot: Robot):
    result, config = robot.get_network_config()
    check_result(result, "get_network_config")
    return config


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    print("Network configuration example (requires connect() first).")
    print("WARNING: --set-eth / --set-wifi / --reset change controller network. Lab use only.\n")

    robot = Robot()
    try:
        check_result(robot.connect(get_robot_connection(args.robot_ip)), "connect")

        if args.set_eth is None and args.set_wifi is None and not args.reset:
            config = fetch_network_config(robot)
            print_network_config(config)
            return

        if args.set_eth is not None:
            if len(args.set_eth) < 3:
                parser.error("--set-eth requires at least IP, NETMASK, and GATEWAY")
            eth_ip, eth_netmask, eth_gateway = args.set_eth[:3]
            eth_dns = args.set_eth[3] if len(args.set_eth) >= 4 else ""

            print(f"Setting wired static IP to {eth_ip} ...")
            check_result(
                robot.set_eth_static(eth_ip, eth_netmask, eth_gateway, eth_dns),
                "set_eth_static",
            )

            print(f"Connection dropped after IP change. Reconnecting to {eth_ip} ...")
            check_result(robot.connect(RtConnectionInfo.to(eth_ip)), "reconnect")

            config = fetch_network_config(robot)
            print_network_config(config)
            return

        if args.set_wifi is not None:
            ssid, password = args.set_wifi
            print(f'Connecting robot WiFi to SSID "{ssid}" ...')
            check_result(robot.set_wifi(ssid, password), "set_wifi")

            config = fetch_network_config(robot)
            print_network_config(config)
            return

        if args.reset:
            print("Restoring factory network settings ...")
            check_result(robot.reset_network_config(), "reset_network_config")

            config = fetch_network_config(robot)
            print_network_config(config)
            print("If eth_ip changed, reconnect with RtConnectionInfo.to(new_ip).")
    finally:
        disconnect_quietly(robot)


if __name__ == "__main__":
    main()
