import os
import sys
import time
import argparse
from typing import Any, Iterable, Optional, Union
from robot_sdk.types import RobotState, is_plan_result_ok
from robot_sdk.errors import RobotResult
from robot_sdk import enumerate_robots, RtConnectionInfo, DiscoveredRobot

def get_config_prefix_path() -> str:
    """Resolve <root>/configuration for Kinematics examples (URDF/meshes)."""
    example_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.dirname(os.path.dirname(example_dir))
    return os.path.join(root_dir, "configuration")

def check_result(result: RobotResult, context: str) -> None:
    if not result.ok:
        print(f"{context} failed: {result.message} ({result.code.name})")
        sys.exit(1)

def check_bool(ok: bool, context: str) -> None:
    if not ok:
        print(f"{context} failed")
        sys.exit(1)

def enable_all_arm_joints(robot: Any) -> None:
    check_result(robot.enable_arm_joint(list(robot.all_enabled_mask())), "enable_arm_joint")


def disconnect_quietly(robot: Any) -> None:
    """Release control and tear down transport; safe on Ctrl+C or after errors."""
    try:
        robot.disconnect()
    except Exception:
        pass


class robot_session:
    """Context manager: connect on enter, disconnect on exit (including Ctrl+C)."""

    def __init__(
        self,
        ip: Optional[str] = None,
        setup: Optional[Any] = None,
    ):
        from robot_sdk import Robot

        self._ip = ip
        self._setup = setup
        self._robot = Robot()

    @property
    def robot(self) -> Any:
        return self._robot

    def __enter__(self) -> Any:
        try:
            if self._setup is not None:
                self._setup(self._robot)
            check_result(self._robot.connect(get_robot_connection(self._ip)), "connect")
            return self._robot
        except BaseException:
            disconnect_quietly(self._robot)
            raise

    def __exit__(self, exc_type, exc, tb) -> None:
        disconnect_quietly(self._robot)
        return None

def require_first_robot():
    """Enumerate robots and return the first; exit if none found."""
    robots = enumerate_robots()
    if not robots:
        print("enumerate_robots: no robots found on the network")
        sys.exit(1)
    chosen = robots[0]
    print(
        f"Found {len(robots)} robot(s); connecting to {chosen.server_ip} "
        f"(session_id={chosen.session_id})"
    )
    return chosen

def add_robot_ip_arg(parser: argparse.ArgumentParser) -> None:
    """Add optional positional IP argument: script.py [IP]."""
    parser.add_argument(
        "ip",
        nargs="?",
        default=None,
        help="RT server IP address (auto-discover first robot if omitted)",
    )

def build_robot_ip_parser(description: str = "") -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    add_robot_ip_arg(parser)
    return parser

def get_robot_connection(ip: Optional[str] = None) -> Union[DiscoveredRobot, RtConnectionInfo]:
    """Return target for Robot.connect(): use ip when given, else first discovered robot."""
    if ip:
        print(f"Connecting to {ip}")
        return RtConnectionInfo.to(ip)
    return require_first_robot()

def print_network_config(config: Any) -> None:
    print("Network configuration:")
    print(f"  eth_ip={config.eth_ip}")
    print(f"  eth_prefix=/{config.eth_prefix}")
    print(f"  eth_netmask={config.eth_netmask}")
    print(f"  eth_gateway={config.eth_gateway}")
    print(f"  eth_dns={config.eth_dns or '(none)'}")
    print(f"  server_ip={config.server_ip}")
    print(f"  wifi_enable={config.wifi_enable}")
    print(f"  wifi_ssid={config.wifi_ssid or '(none)'}")
    print(
        "  wifi_password="
        + (config.wifi_password if config.wifi_password else "(masked or none)")
    )

def robot_state_name(state: RobotState) -> str:
    return state.name



def print_feedback(
    arm: Any,
    dt: float,
    timeout: float,
    prefix_text: str = "",
    print_joint: bool = False,
    print_tool: bool = False,
) -> bool:
    """Poll until motion finishes. Requires a non-Idle sample then settled Idle.

    Does not treat continuous Idle after a short grace as success (avoids false
    complete when RT never starts the move).
    """
    elapsed_time = 0.0
    interval = dt
    idle_settle_samples = 3
    seen_busy = False
    idle_streak = 0
    is_idle = False
    is_interrupted = False
    timed_out = False
    never_started = False

    while elapsed_time <= timeout:
        print(prefix_text, end="")
        print(f"Elapsed time: {elapsed_time:.1f}s")

        if print_joint:
            joint_pos = arm.get_joint_state()
            print("Current joint position")
            print("\tArm:", list(joint_pos.arm))
            print("\tGripper:", list(joint_pos.gripper))

        if print_tool:
            tool_pose = arm.get_tool_pose()
            print("Current tool pose")
            print(f"\tposition(x, y, z): {tool_pose.position.x}, {tool_pose.position.y}, {tool_pose.position.z}")
            print(
                f"\torientation(w, x, y, z): {tool_pose.orientation.w}, "
                f"{tool_pose.orientation.x}, {tool_pose.orientation.y}, {tool_pose.orientation.z}"
            )

        sys_status = arm.get_status()
        arm.print_status(sys_status)
        is_idle = sys_status.robot_state == RobotState.IDLE
        is_error = sys_status.robot_state == RobotState.ERROR
        is_interrupted = is_error or not is_plan_result_ok(sys_status.plan_result)
        if not is_idle and not is_error:
            seen_busy = True
            idle_streak = 0
        elif is_idle and (not is_error) and (not is_interrupted):
            idle_streak += 1
        else:
            idle_streak = 0
        print("---------------------------------------------------------------")

        timed_out = elapsed_time >= timeout
        settled_idle = idle_streak >= idle_settle_samples
        finished_after_motion = is_idle and seen_busy and settled_idle
        failed_while_idle = is_idle and is_interrupted and seen_busy
        if timed_out or finished_after_motion or failed_while_idle or is_error:
            never_started = timed_out and (not seen_busy) and is_idle and (not is_interrupted)
            break

        time.sleep(interval)
        elapsed_time += interval

    print("is_idle:", is_idle)
    if is_interrupted:
        print("Motion wait failed (error or plan_result).")
    elif never_started:
        print("Motion wait failed: robot stayed Idle (motion never started).")
    elif timed_out:
        print("Motion wait timed out.")
    print("===============================================================")
    return is_idle and seen_busy and (not is_interrupted) and (not timed_out)
