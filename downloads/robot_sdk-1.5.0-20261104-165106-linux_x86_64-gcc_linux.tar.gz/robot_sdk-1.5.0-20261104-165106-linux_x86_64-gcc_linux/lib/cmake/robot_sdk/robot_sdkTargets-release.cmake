#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "robot::sdk" for configuration "Release"
set_property(TARGET robot::sdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(robot::sdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/librobot_sdk.so"
  IMPORTED_SONAME_RELEASE "librobot_sdk.so"
  )

list(APPEND _cmake_import_check_targets robot::sdk )
list(APPEND _cmake_import_check_files_for_robot::sdk "${_IMPORT_PREFIX}/lib/librobot_sdk.so" )

# Import target "robot::sdk_c" for configuration "Release"
set_property(TARGET robot::sdk_c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(robot::sdk_c PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "robot::sdk"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/librobot_sdk_c.so"
  IMPORTED_SONAME_RELEASE "librobot_sdk_c.so"
  )

list(APPEND _cmake_import_check_targets robot::sdk_c )
list(APPEND _cmake_import_check_files_for_robot::sdk_c "${_IMPORT_PREFIX}/lib/librobot_sdk_c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
