# Robot SDK User Guide

This guide is for application developers using a released Robot SDK package. It explains how to install the SDK, run an example, and integrate it into a Python or C++ application.

## Package Contents

A release package contains the following directories:

```text
<prefix>/
|-- bin/                     Runtime libraries on Windows
|-- bindings/python/         Python wheel files
|-- configuration/           URDF and meshes (for offline Kinematics)
|-- docs/                    API documentation and this guide
|-- examples/                Public C++ and Python examples (`cpp/`, `python/`, `csharp/`)
|-- include/                 C++ headers
`-- lib/                     C++ libraries and CMake package files
```

Keep the package layout intact. Do not move or remove `configuration/` if you use offline **Kinematics** (FK/IK). **Robot** itself does not load files from that directory.

## Prerequisites

- A release package built for your operating system and architecture
- Python version matching one of the wheel files, if using Python
- CMake 3.21+ and a C++17 compiler, if using C++

## Quick Start with Python

1. Select the wheel whose `cpXY` tag matches your Python version.

   ```powershell
   # Example for Python 3.10 on Windows
   pip install .\bindings\python\robot_sdk-*-cp310-*.whl
   ```

2. Verify the installation.

   ```powershell
   python -c "from robot_sdk import Robot; print('Robot SDK import ok')"
   ```

3. Run an example from the package root.

   ```powershell
   cd .\examples\python
   python .\move_point.py
   python .\move_point.py 192.168.1.10   # optional: connect to a known RT IP
   ```

Motion examples connect to rt_control on the network. **By default**, examples auto-discover and connect to the **first robot** found on the LAN. To connect to a specific host, pass the RT server IP as an optional command-line argument (see [Running examples](#running-examples) below). Kinematics examples resolve `<prefix>/configuration` automatically via `utils.get_config_prefix_path()`.

### Minimal Python Program

<!-- sdk-smoke:python -->
```python
from robot_sdk import Robot, RtConnectionInfo

robot = Robot()
try:
    robot.connect(RtConnectionInfo.to("192.168.1.10")).raise_for_error()
    robot.enable_arm_joint(robot.all_enabled_mask()).raise_for_error()
    # Joint commands use degrees; gripper position commands use [0, 1].
finally:
    robot.disconnect()
```

If multiple robots are visible, enumerate first and connect to one entry:

<!-- sdk-smoke:python -->
```python
from robot_sdk import Robot, enumerate_robots

robots = enumerate_robots()
if not robots:
    raise RuntimeError("No robots discovered")
# Choose the intended robot by name/IP when more than one is visible.
chosen = robots[0]
robot = Robot()
try:
    robot.connect(chosen).raise_for_error()
finally:
    robot.disconnect()
```

Always call `disconnect()` when the application exits or when robot control is no longer required.

## Quick Start with C++

Add the SDK to your CMake project:

```cmake
cmake_minimum_required(VERSION 3.21)
project(my_app LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)

find_package(robot_sdk REQUIRED)

add_executable(my_app main.cpp)
target_link_libraries(my_app PRIVATE robot::sdk)
```

Configure with the package prefix:

```bash
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/prefix
cmake --build build --parallel
```

To build the shipped C++ examples:

```bash
cmake -S /path/to/prefix/examples/cpp -B build -DCMAKE_PREFIX_PATH=/path/to/prefix
cmake --build build --parallel
./build/move_point                        # auto-discover first robot
./build/move_point 192.168.1.10           # connect to known RT IP
```

On Windows, ensure `robot_sdk.dll` and the other DLLs from `<prefix>/bin` are available beside your executable or through `PATH`.

## Running examples

Motion examples share the same connection rule across languages:

| If you pass an IP | If you omit the IP |
|---|---|
| Connect directly via `RtConnectionInfo.to(ip)` | Enumerate the network and connect to the **first** discovered robot |

### Python (`examples/python/`)

Helpers live in `utils.py`:

- `build_robot_ip_parser()` — optional positional `[IP]` argument
- `get_robot_connection(ip)` — returns a `connect()` target

```powershell
cd examples\python
python move_point.py
python move_point.py 192.168.1.10
python network_config.py --ip 192.168.1.10          # examples with other flags use --ip
python network_config.py --ip 192.168.1.10 --set-eth 192.168.2.100 255.255.255.0 192.168.2.1
```

See also `connection_options.py` for auto-discover, fixed IP, and enumerate-first patterns.

### C++ (`examples/cpp/`)

Helpers live in `example_common.h`:

- `robotIpFromArgs(argc, argv)` — parse `[IP]` or `--ip IP`
- `connectToRobot(robot, ip)` — connect with optional IP

```bash
./move_point
./move_point 192.168.1.10
./network_config --ip 192.168.1.10
./network_config --ip 192.168.1.10 --set-eth 192.168.2.100 255.255.255.0 192.168.2.1
```

See also `connection_options.cpp`.

### C# (`examples/csharp/`)

Helpers live in `MovePoint/ExampleCommon.cs`:

- `RobotIpFromArgs(args)` — parse `[IP]` or `--ip IP`
- `ConnectToRobot(robot, ip)` — connect with optional IP

Build and run from Visual Studio or `dotnet` (see `MovePoint.csproj`). Point `Spark2SdkClrPath` at the directory containing `RobotSdk.Clr.dll` and `robot_sdk.dll`.

```powershell
MovePoint.exe
MovePoint.exe 192.168.1.10
MovePoint.exe --ip 192.168.1.10
```

Kinematics-only examples (`calculate_kinematics.*`) do not connect to a robot and accept no IP argument.

### Minimal C++ Program

```cpp
#include "robot_sdk.h"

int main() {
    robot::Robot robot;
    if (robot::RobotResult result = robot.connect(robot::RtConnectionInfo{}); !result) {
        return 1;
    }
    robot.enableArmJoint({true, true, true, true, true, true});
    robot.disconnect();
    return 0;
}
```

## Runtime Configuration

### Robot (robot control)

`Robot()` creates a disconnected client; pass `RtConnectionInfo` to `connect()`. It does **not** take a configuration directory.

| Need | Source |
|------|--------|
| RT server IP | `connect(RtConnectionInfo.to(ip))` |
| Discovery | `enumerate_robots()` + `connect(robot)` |
| Joint limits, tool offset, modes | RT platform after `connect()` (`getConfigurator()`) |
| HMAC keys | Built into the SDK |

```python
from robot_sdk import Robot, RtConnectionInfo

# Auto-discover on the network (default empty server_ip).
robot = Robot()
robot.connect(RtConnectionInfo())

# Known RT host.
robot = Robot()
robot.connect(RtConnectionInfo.to("192.168.1.10"))
```

Internal SDK releases also ship trusted-application examples under `examples/internal/` (see [INTERNAL_SDK.md](INTERNAL_SDK.md)).

Bulk / non-real-time uploads (teach programs, calibration blobs) are available
only in the **internal SDK** (`robot_sdk.internal` / `robot_internal.h`).
See [INTERNAL_SDK.md](INTERNAL_SDK.md) and [TCP_DATA.md](TCP_DATA.md).

See [BREAKING_CONFIG.md](BREAKING_CONFIG.md) for migration notes from older SDK versions.

Use `connect()` to start a control session. Normal motion calls return after sending; use the `*AndWait` / `*_and_wait` APIs when completion confirmation is required.

### Error handling

Motion, connection, and configuration APIs return `RobotResult` (C++) or a result object with `.ok` / `.code` / `.message` (Python). Check the result before continuing:

```python
result = robot.move_pos(q, 50, 0.0)
result.raise_for_error()
```

Invalid parameters (mismatched path sizes, bad timeout) return `INVALID_ARGUMENT` instead of raising Python exceptions. Public handle accessors `arm()` and `dual_arm()` can raise `RobotError`; negative arm indices are rejected even before connecting. `dual_arm()` requires a connected robot with at least two arms.

```cpp
if (robot::RobotResult result = robot.movePosPath(path, v, t); !result) {
    // result.code == robot::RobotErrorCode::kInvalidArgument
}
```

`wait_until_idle` / `waitUntilIdle` wake on each incoming telemetry update (event-driven). `poll_interval_sec` is the maximum wait when the link is quiet.

### Dual-arm motion

Existing `robot.move_pos(...)` / `robot.movePos(...)` APIs drive arm 0 with variable-length joint lists. Dual-arm robots use the same session. `robot.get_joint_state()` / `get_ee_pose()` are also arm 0 only — use internal `robot.arm(i).get_joint_state()` for other arms.

To move both arms **at the same time**, use the **internal SDK** (`robot_sdk.internal` / `robot::internal::Robot`). See `examples/internal/python/dual_arm.py` in internal releases.

Internal APIs:

| Python | C++ |
|--------|-----|
| `robot.dual_arm().move_pos(q0, q1)` | `robot.dualArm().movePos(q0, q1)` |
| `robot.move_pos_both(q0, q1)` | `robot.movePos(q0, q1)` |
| `robot.move_ee_line_both(p0, p1)` | `robot.moveEELine(p0, p1)` |

```python
from robot_sdk.internal import Robot

robot = Robot()
# ... connect ...
both = robot.dual_arm()
check_result(both.move_pos(q_left, q_right, 50, 0.0), "dual move_pos")
check_result(robot.wait_until_idle(), "wait_until_idle")
```

A single-arm command holds the other arm at its current pose. `wait_until_idle` is whole-robot.

### Kinematics (offline FK/IK)

Use a separate `Kinematics` instance with the configuration **resource directory** (URDF and meshes):

```python
from robot_sdk import Kinematics

kinematics = Kinematics("/path/to/prefix/configuration")
```

The directory must contain `arm_v2.urdf` and `meshes/` for the built-in model (`spark2_v2`). Optional `config.yaml` can override `model` / `robot.name`.

## Troubleshooting

### The Python wheel does not install

Ensure the Python version matches the wheel tag. For example, a `cp310` wheel requires CPython 3.10.

### Python import or application startup reports a missing DLL

Keep the package directories together and make the contents of `<prefix>/bin` discoverable by the operating system.

### The robot starts but does not move

Confirm that the application calls `connect(...)` and `enable_arm_joint(...)`, and that rt_control is reachable on the network.

### Kinematics fails to load

Verify that `configuration/` contains `arm_v2.urdf` and the mesh files referenced by the URDF.

## Related Documentation

- C++ API and usage: `robot_sdk_cpp.md`
- C API and usage: `robot_sdk_c.md`
- C# API and usage: `robot_sdk_csharp.md`
- Python API and usage: `robot_sdk_python.md`
- Runnable public examples: `<prefix>/examples/cpp`, `<prefix>/examples/python`, and `<prefix>/examples/csharp`
- Internal SDK examples (internal releases only): `<prefix>/examples/internal/cpp` and `<prefix>/examples/internal/python`


## Component API and language capabilities

Robot owns the session, whole-robot state and stop operations. Arm owns per-arm
motion/feedback/configuration; DualArm owns synchronized motion for arms 0 and 1.
Existing Robot motion/feedback convenience methods select arm 0. The whole-robot
smoothing setter is an exception: it still applies to every arm. Gripper methods
remain available on Robot and Arm.

| Capability | C++ | Python | C | C# / CLR |
|---|---|---|---|---|
| Connect, arm-0 motion and gripper | Yes | Yes | Yes | Yes |
| Arm(index), synchronized DualArm | Yes | Yes | No | No |
| Explicit MotionOptions adapters | Yes | Yes | Use existing v/t calls | Use existing v/t calls |
| Maintenance/recovery details | Internal SDK | Internal SDK | No | No |

C++ handles borrow their Robot and must not outlive it. Reacquire after moving
Robot or reconnecting. Python handles retain their owning Robot; reacquire after
reconnecting. `arm(index)` permits valid non-negative handles before connection,
but topology-dependent validation happens after connecting. `dualArm()` requires
an established dual-arm topology. Missing hardware does not create a new capability.

## Motion timing and completion

Prefer these explicit alternatives:

```cpp
robot.arm(0).goHomeAndWait(robot::MotionOptions::speedLimited(20));
robot.dualArm().goHomeAndWait(robot::MotionOptions::timed(5.f));
```

```python
from robot_sdk import MotionOptions
robot.arm(0).go_home_and_wait(MotionOptions.speed_limited(20)).raise_for_error()
```

`speedLimited` / `speed_limited` uses a percentage in (0,100] with automatic
duration. `timed(seconds)` requests a positive duration using full configured
limits; RT may extend it. Setting a lower speed on timed options returns
Unsupported, because the current SDK protocol does not negotiate timed speed caps.
The MotionOptions form is an overload of the same method name. No parameter is
silently ignored by these overloads. The old numeric `(v,t)` overloads of movePos,
movePosAndWait, goHome and goHomeAndWait on Robot/Arm/DualArm are deprecated and
planned for removal in a future major release; a removal version is not yet set.
They remain callable with their documented behavior: t>0 ignores v. C++ emits a
deprecation diagnostic; Python emits DeprecationWarning for numeric calls.
C and CLR still expose their existing numeric APIs. Methods without a matching
MotionOptions overload (paths, Cartesian moves, grippers, velocity and fold) are
not deprecated by this change.

```cpp
// Deprecated: robot.goHome(20, 0.f);
robot.goHome(robot::MotionOptions::speedLimited(20));
robot.goHomeAndWait(robot::MotionOptions::timed(5.f), 30.f);
```

```python
# Deprecated: robot.go_home(v=20, t=0.0)
robot.go_home(options=MotionOptions.speed_limited(20)).raise_for_error()
```

Joint position/home/fold waits check arrival within 1 degree and fresh consecutive
Idle observations. Dual-arm joint position/path waits check both arms. When an
updated RT clamps a target, the wait uses authenticated effective-target feedback
bound to this command/session. If the effective goal cannot be confirmed, the wait
fails rather than declaring success. Older RTs retain the requested goal and can
time out when it is not reached. State-only `waitUntilIdle` / generic `moveAndWait`
and Cartesian waits do not independently prove target pose accuracy.

Command success can mean only local submission. For completion use the appropriate
AndWait API and check its result. A timeout does not cancel a motion; explicitly
request stopMotion() if your application requires stopping on timeout.

## Error handling styles

C++ commands return RobotResult; inspect code/message or call throwIfError().
Python callers can inspect result.ok/code/message or call result.raise_for_error().
The opt-in helper raises RobotException / RobotError only for a failed result.
Handle accessors and some queries can also throw; existing exception behavior is
preserved. Wrap the whole operation in try/catch (C++) or try/finally (Python),
not only the connect call. Do not issue blocking motion from SDK event callbacks.


| Error class | Application response |
|---|---|
| NotStarted / TransportUnavailable | Inspect connection state; connect or reconnect when appropriate. |
| InvalidArgument / InvalidConfig | Fix dimensions, indices or timing; resending unchanged inputs will not help. |
| ControlLost / InvalidClientOrSession | Check control ownership; establish a fresh authorized session before new motion. |
| CommandInvalid / MotionInterrupted | Inspect the message and diagnostics; a rejected trajectory is not automatically a hardware fault. |
| Timeout | Determine whether submission/execution is still pending; timeout itself does not cancel motion. |
| Unsupported | Select a supported operation or timing mode; do not silently discard a requested constraint. |
