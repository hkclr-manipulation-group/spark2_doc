# Robot SDK API (C# / .NET)

Maintenance API boundary: TCP calibration solving, detailed diagnostics/metrics/fault callbacks and fault recovery are internal SDK features. Use the Robot Client UI for these operations. C++ trusted clients include `robot_internal.h` / `tcp_calibration.h` and link `robot::internal_sdk`; Python trusted clients import `robot_sdk.internal`. These entry points are removed from the public C++, Python, C and CLR surfaces. This is a source/API breaking change; rebuild affected consumers. Basic SystemStatus/raw flags, connection state, ordinary state/motion events, known tool offsets and stop commands remain public.

- **Requirements:** .NET Framework 4.6+ or .NET 6+
- **Platform:** Windows x64 (C++/CLI mixed assembly `RobotSdk.Clr.dll`)
- **Default TFM in releases:** .NET Framework 4.6 (`net46`)

Reference `RobotSdk.Clr.dll` from your project and copy `robot_sdk.dll` next to your executable (both are in `bindings/csharp/` of your SDK release). The CLR assembly TFM must match your app (.NET Framework vs .NET Core).

## Quick start

Reference the mixed-mode assembly from your `.csproj`:

```xml
<PropertyGroup>
  <TargetFramework>net46</TargetFramework>
</PropertyGroup>
<ItemGroup>
  <Reference Include="RobotSdk.Clr">
    <HintPath>path\to\RobotSdk.Clr.dll</HintPath>
  </Reference>
</ItemGroup>
```

Copy `robot_sdk.dll` next to your executable (same directory as `RobotSdk.Clr.dll`).

```csharp
using Robot.Sdk;

var robot = new Robot();
var result = robot.Connect(new RtConnectionInfo());
if (!result.Ok)
{
    Console.WriteLine("connect failed: " + result.Message);
    return;
}

robot.EnableArmJoint(new[] { true, true, true, true, true, true });
robot.MovePos(new[] { 0f, -30f, 60f, 0f, 0f, 0f }, 50, 0f);
robot.WaitUntilIdle(30f, 0.1f);

var status = robot.GetStatus();
Console.WriteLine(status.RobotState);
```

## Namespace

All public types live in `Robot.Sdk`:

| Type | Description |
|---|---|
| `Robot` | Main SDK client (connection, motion, feedback, events). Deprecated alias: `RobotRobot`. |
| `Configurator` | Tool offset and safety limits |
| `Kinematics` | Offline FK/IK from URDF configuration directory |
| `RobotResult` | Command return value (`Ok`, `Code`, `Message`) |
| `RobotException` | Thrown when native query APIs fail before connect |
| `Logging` | `SetLogLevel`, `SetLogToFile`, `SetLogToStderr` |

Joint arrays use `float[]` sized to runtime DOF after `connect()` (and `bool[]` for enable flags).

## API parity

The CLR layer mirrors the public Python/C++ surface:

- Connection: `EnumerateRobots`, `Connect`, `Disconnect`, `ArmCount`, `GripperCount`
- Motion: `MovePos`, `MoveEeLine`, path variants, teach/playback (arm slot 0 on `Robot`)
- Feedback: `GetPos` / `GetVel` / `GetTor` / `GetEePose` (arm slot 0 on `Robot`)
- Events: `SetOnStateChanged`, `SetOnFault`, `SetOnMotionDone`, `ClearEventCallbacks`
- Config: `GetConfigurator()` on `Robot`

On dual-arm robots, public CLR APIs target **arm slot 0** only. `Robot.GetPos()` and motion methods on `Robot` follow the same rule as C++/Python.

`RobotRobot` is a deprecated alias that inherits `Robot`.

### Error handling

Most motion and connection APIs return `RobotResult` with `Ok`, `Code`, and `Message`. Invalid parameters (mismatched path sizes, non-positive timeout) return `RobotErrorCode.InvalidArgument`.

Handle accessor `EnumerateRobots()` throws `RobotException` when the call cannot succeed (active session).

`WaitUntilIdle` is event-driven: it wakes on each incoming telemetry update. `pollIntervalSec` is the maximum backoff when the link is quiet.

```csharp
// Arm slot 0 motion and feedback on Robot.
CheckResult(robot.MovePos(q, 50, 0f), "move");
CheckResult(robot.WaitUntilIdle(30f, 0.1f), "wait");
```

Same rules as the C++ SDK: one `Robot` instance is not thread-safe. Event handlers run on the SDK event thread (never a transport thread), so a slow handler cannot stall telemetry — but do not call blocking motion APIs or `Connect()` from callbacks. `Disconnect()` from a handler is supported; the socket close and thread joins are deferred to the next application-thread call.

## Examples (`examples/csharp/`)

The shipped sample is `MovePoint/`. Shared helpers are in `ExampleCommon.cs`:

| Helper | Description |
|---|---|
| `RobotIpFromArgs(args)` | Parse optional `[IP]` or `--ip IP` from command-line args |
| `ConnectToRobot(robot, ip)` | Connect via `RtConnectionInfo.To(ip)` when `ip` is set, else enumerate and use the first robot |
| `CheckResult(result, label)` | Throw on failure |

Build `MovePoint.csproj` with `Spark2SdkClrPath` pointing at the directory that contains `RobotSdk.Clr.dll` and `robot_sdk.dll` (see the project file comments).

```powershell
MovePoint.exe
MovePoint.exe 192.168.1.10
MovePoint.exe --ip 192.168.1.10
```

Typical example flow:

```csharp
using Robot.Sdk;
using Spark2.Examples;

var robot = new Robot();
ExampleCommon.ConnectToRobot(robot, ExampleCommon.RobotIpFromArgs(args));
```

When no IP is passed, the example enumerates the network and connects to the first discovered robot. Pass an IP to connect directly without enumeration.
