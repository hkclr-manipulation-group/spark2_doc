#ifndef ROBOT_SDK_EXPORT_H
#define ROBOT_SDK_EXPORT_H

#if defined(_WIN32) || defined(__CYGWIN__)
#  if defined(robot_sdk_EXPORTS)
#    define ROBOT_API __declspec(dllexport)
#  else
#    define ROBOT_API __declspec(dllimport)
#  endif
#else
#  if defined(robot_sdk_EXPORTS)
#    define ROBOT_API __attribute__((visibility("default")))
#  else
#    define ROBOT_API
#  endif
#endif

// Deprecated v/t overloads remain available for source and binary compatibility.
// Do not warn while compiling the SDK's own compatibility implementations.
#if defined(robot_sdk_EXPORTS)
#  define ROBOT_DEPRECATED(message)
#else
#  define ROBOT_DEPRECATED(message) [[deprecated(message)]]
#endif

#endif
