#pragma once
#include <functional>
#include "robot_sdk/types.h"
#include "robot_sdk/result.h"
namespace robot {
using StateChangedCallback = std::function<void(
    RobotState previous, RobotState current, const SystemStatus& status)>;

using MotionDoneCallback = std::function<void(
    const SystemStatus& status, const RobotResult& result)>;

}
