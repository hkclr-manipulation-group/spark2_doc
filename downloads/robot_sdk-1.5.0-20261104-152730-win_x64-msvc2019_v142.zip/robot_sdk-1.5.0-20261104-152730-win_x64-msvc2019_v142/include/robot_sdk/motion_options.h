#pragma once
#include <cmath>
#include "robot_sdk/result.h"

namespace robot {

enum class MotionMode { kSpeedLimited, kTimed };

/** Explicit adapter for legacy position-motion timing. Timed mode uses full
 * configured limits; a timed velocity cap requires a future negotiated RT capability. */
struct MotionOptions {
    MotionMode mode = MotionMode::kSpeedLimited;
    int speed_percent = 50;
    float duration_sec = 0.f;

    static MotionOptions speedLimited(int percent) {
        MotionOptions options;
        options.speed_percent = percent;
        return options;
    }
    static MotionOptions timed(float seconds) {
        MotionOptions options;
        options.mode = MotionMode::kTimed;
        options.speed_percent = 100;
        options.duration_sec = seconds;
        return options;
    }
    RobotResult legacyTiming(int& speed, float& duration) const {
        if (!std::isfinite(duration_sec) || speed_percent < 1 || speed_percent > 100)
            return RobotResult::error(RobotErrorCode::kInvalidArgument, "Invalid motion speed or duration");
        if (mode == MotionMode::kSpeedLimited) {
            if (duration_sec != 0.f)
                return RobotResult::error(RobotErrorCode::kInvalidArgument, "Speed-limited mode requires duration_sec=0");
        } else if (mode == MotionMode::kTimed) {
            if (duration_sec <= 0.f)
                return RobotResult::error(RobotErrorCode::kInvalidArgument, "Timed mode requires duration_sec>0");
            if (speed_percent != 100)
                return RobotResult::error(RobotErrorCode::kUnsupported,
                    "Timed motion with a speed cap is not supported by this SDK protocol; use speedLimited() or timed()");
        } else {
            return RobotResult::error(RobotErrorCode::kInvalidArgument, "Unknown motion mode");
        }
        speed = speed_percent;
        duration = duration_sec;
        return RobotResult::success();
    }
};
} // namespace robot
