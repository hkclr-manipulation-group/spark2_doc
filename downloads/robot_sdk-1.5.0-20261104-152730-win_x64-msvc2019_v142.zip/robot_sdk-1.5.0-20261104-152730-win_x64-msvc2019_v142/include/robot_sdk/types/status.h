#ifndef ROBOT_SDK_TYPES_STATUS_H
#define ROBOT_SDK_TYPES_STATUS_H

#include "robot_sdk/types/geometry.h"
#include "robot_sdk/types/motion.h"

#include <cstdint>
#include <vector>

namespace robot {

constexpr int kMaxArmCount = 2;
constexpr int kMaxGripperCount = 2;

enum class RobotState {
    kStartup = 0,
    kIdle = 1,
    kMoving = 2,
    kSettling = 3,
    kError = 4,
    kRecovery = 5,
    kShutdown = 6,
    kOffline = 7,
};

/** Configure via setLogLevel / setLogToFile in robot.h. */
enum class LogLevel {
    kTrace = 0,
    kDebug,
    kInfo,
    kWarn,
    kError,
    kOff,
};

/** Whole-robot runtime status from telemetry. */
struct SystemStatus {
    RobotState robot_state;
    PlanResult plan_result;
    uint64_t robot_diagnostic_flags;
    int arm_size = 0;
    int gripper_size = 0;
    std::vector<JointDiagnosticFlags> arm_joint_diagnostic_flags;
    std::vector<JointDiagnosticFlags> gripper_joint_diagnostic_flags;
};

}  // namespace robot

#endif
