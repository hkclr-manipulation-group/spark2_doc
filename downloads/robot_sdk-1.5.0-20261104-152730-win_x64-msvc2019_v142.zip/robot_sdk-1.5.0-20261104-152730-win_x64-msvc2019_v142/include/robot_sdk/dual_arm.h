#ifndef ROBOT_DUAL_ARM_H
#define ROBOT_DUAL_ARM_H

#include "robot_sdk/export.h"
#include "robot_sdk/result.h"
#include "robot_sdk/motion_options.h"
#include "robot_sdk/types.h"

namespace robot {

class Robot;

namespace internal {
class Robot;
}

/**
 * Synchronized dual-arm motion handle (public SDK).
 *
 * Legacy position timing: t=0 uses v percent; t>0 ignores v and uses full configured limits.
 * Both arms share timing; sequential Arm commands are not synchronized.
 * This non-owning handle must not outlive its Robot. Reacquire after moving
 * the Robot or reconnecting. Acquisition requires a connected dual-arm robot.
 * Joint targets use JointValues vectors sized to each arm's jointCount().
 */
class ROBOT_API DualArm {
public:
    /** Enable both arm joint groups in one configuration packet. */
    RobotResult enableArmJoint(const JointMask& arm0, const JointMask& arm1);

    /** Preferred explicit timing overload. */
    RobotResult movePos(const JointValues& arm0, const JointValues& arm1, const MotionOptions& options);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use movePos(..., MotionOptions) instead of v,t")
    RobotResult movePos(
        const JointValues& arm0, const JointValues& arm1,
        int v = 50, float t = 0);
    /** Preferred explicit timing overload. */
    RobotResult movePosAndWait(const JointValues& arm0, const JointValues& arm1, const MotionOptions& options, float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use movePosAndWait(..., MotionOptions) instead of v,t")
    RobotResult movePosAndWait(
        const JointValues& arm0, const JointValues& arm1,
        int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult movePosPath(
        const Path<JointValues>& arm0, const Path<JointValues>& arm1,
        Path<int> v, Path<float> t);
    RobotResult movePosPathAndWait(
        const Path<JointValues>& arm0, const Path<JointValues>& arm1,
        Path<int> v, Path<float> t,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveVel(
        const JointValues& arm0, const JointValues& arm1,
        int a = 10, float t = 0);
    RobotResult moveVelAndWait(
        const JointValues& arm0, const JointValues& arm1,
        int a = 10, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveEEPoint(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0);
    RobotResult moveEEPointAndWait(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveEEPointPath(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t);
    RobotResult moveEEPointPathAndWait(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveEELine(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0);
    RobotResult moveEELineAndWait(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveEELinePath(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t);
    RobotResult moveEELinePathAndWait(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveToolPoint(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0);
    RobotResult moveToolPointAndWait(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveToolPointPath(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t);
    RobotResult moveToolPointPathAndWait(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveToolLine(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0);
    RobotResult moveToolLineAndWait(
        const Pose& arm0, const Pose& arm1, int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    RobotResult moveToolLinePath(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t);
    RobotResult moveToolLinePathAndWait(
        const Path<Pose>& arm0, const Path<Pose>& arm1, Path<int> v, Path<float> t,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

    /** All-zero joint target. Legacy t>0 ignores v; prefer the explicit options variants. */
    /** Preferred explicit timing overload. */
    RobotResult goHome(const MotionOptions& options);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use goHome(..., MotionOptions) instead of v,t")
    RobotResult goHome(int v = 50, float t = 0);
    /** Fresh Idle plus joint arrival within 1 degree (both arms for DualArm). */
    /** Preferred explicit timing overload. */
    RobotResult goHomeAndWait(const MotionOptions& options, float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
    /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
    ROBOT_DEPRECATED("Use goHomeAndWait(..., MotionOptions) instead of v,t")
    RobotResult goHomeAndWait(
        int v = 50, float t = 0,
        float timeout_sec = 30.f, float poll_interval_sec = 0.1f);


private:
    friend class Robot;
    friend class internal::Robot;
    explicit DualArm(Robot& robot);
    Robot* robot_ = nullptr;
};

}  // namespace robot

#endif
