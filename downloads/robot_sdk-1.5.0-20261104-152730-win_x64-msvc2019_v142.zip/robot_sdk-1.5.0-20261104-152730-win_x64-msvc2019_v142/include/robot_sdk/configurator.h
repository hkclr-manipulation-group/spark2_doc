#ifndef ROBOT_SDK_CONFIGURATOR_H
#define ROBOT_SDK_CONFIGURATOR_H

#include <memory>

#include "robot_sdk/export.h"
#include "robot_sdk/types.h"
#include "robot_sdk/result.h"

namespace robot {

class ROBOT_API Configurator {
public:
    ~Configurator();

    RobotResult setToolOffset(const Position& offset);
    Position getToolOffset() const;

    RobotResult setArmPosLimits(const JointLimitValues& limit);
    RobotResult setArmVelLimits(const JointLimitValues& limit);
    JointLimitValues getArmPosLimits() const;
    JointLimitValues getArmVelLimits() const;
    JointLimitValues getArmMaxPos() const;
    JointLimitValues getArmMaxVel() const;
    JointValues getArmMaxPosJump() const;
    JointValues getArmMaxVelJump() const;
    JointValues getArmMaxPosFollowError() const;
    JointValues getArmMaxVelFollowError() const;
    JointValues getArmMaxTorFollowError() const;

    /** Gripper safety soft limits (RT motor units, often degrees). Not panel [0,1]. */
    RobotResult setGripperPosLimits(const JointLimitValues& limit);
    JointLimitValues getGripperPosLimits() const;
    /** Gripper safety hard limits (RT motor units). Not moveGripperPos command space. */
    JointLimitValues getGripperMaxPos() const;

private:
    Configurator();
    struct Impl;
    std::unique_ptr<Impl> pimpl_;
    friend class Robot;
};

}  // namespace robot

#endif
