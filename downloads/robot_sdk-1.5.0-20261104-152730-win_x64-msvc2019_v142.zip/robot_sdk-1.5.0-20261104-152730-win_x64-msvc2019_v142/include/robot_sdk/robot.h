#ifndef ROBOT_SDK_ROBOT_H
#define ROBOT_SDK_ROBOT_H

#include <functional>
#include <memory>
#include <vector>
#include <string>

#include "robot_sdk/export.h"
#include "robot_sdk/types.h"
#include "robot_sdk/result.h"
#include "robot_sdk/motion_options.h"
#include "robot_sdk/events.h"
#include "robot_sdk/connection_status.h"
#include "robot_sdk/configurator.h"

namespace robot{

    namespace detail {
        struct RobotMotionTestAccess;
    }

    class Arm;
    class DualArm;

    namespace internal {
        class Robot;
    }

    /**
     * Connection parameters for rt_control (Robot Controller).
     *
     * Leave server_ip empty to auto-discover when calling connect(RtConnectionInfo{}).
     * UDP/TCP ports are fixed by the SDK and are not configurable in the public API.
     */
    struct ROBOT_API RtConnectionInfo {
      /**
       * @brief Constructor with server_ip (empty string = auto-discovery on connect()).
       * @param server_ip The IP address of the RT server (empty string = auto-discovery via connect(info)).
       */
      explicit RtConnectionInfo(std::string server_ip = "");

      /** RT server IP. */
      std::string server_ip;

      /**
       * @brief Create a RtConnectionInfo with a known RT server IP.
       * @param server_ip The IP address of the RT server.
       * @return The RtConnectionInfo.
       */
      static RtConnectionInfo to(std::string server_ip);
    };

    /** Minimum severity written to stderr / log file (default: kInfo). */
    /**
     * @brief Set the minimum severity for logs.
     * @param level The minimum severity for logs.
     */
    ROBOT_API void setLogLevel(LogLevel level);

    /**
     * @brief Get the minimum severity for logs.
     * @return The minimum severity for logs.
     */
    ROBOT_API LogLevel getLogLevel();

    /** 
     * @brief Write logs under logs/robot_YYYY-MM-DD.log (creates logs/ if needed).
     * @param enabled Whether to write logs to a file.
     * Files rotate automatically at local midnight. Default: disabled.
     */
    ROBOT_API void setLogToFile(bool enabled);

    /**
     * @brief Mirror logs to stderr (default: true). Independent of setLogToFile().
     * @param enabled Whether to mirror logs to stderr.
     */
    ROBOT_API void setLogToStderr(bool enabled);

    /**
     * @brief Enumerate reachable robot RT servers on the network (no lasting session).
     *
     * Always probes multicast / broadcast / localhost. Returns an empty list when none reply.
     * Call before Robot::connect(robot) / connect(info).
     */
    ROBOT_API std::vector<DiscoveredRobot> enumerateRobots();

    class ROBOT_API Robot{
        public:
            /** Create an SDK client; call connect() to start a session. */
            Robot();
            virtual ~Robot();

            // A Robot owns a live session and is not copyable. It is movable:
            // the user-declared destructor would otherwise suppress the implicit
            // move operations, silently forcing std::move() to fall back to a
            // (deleted) copy and making std::vector<Robot> unusable.
            // Defined out-of-line (robot.cpp) where Impl is complete: the move
            // of unique_ptr<Impl> needs the full type for the deleter.
            Robot(const Robot&) = delete;
            Robot& operator=(const Robot&) = delete;
            Robot(Robot&&) noexcept;
            Robot& operator=(Robot&&) noexcept;

            // --- RT connection ---

            /** Connect using a robot from enumerateRobots() (skips discovery).
             * Normal setup waits for fresh, consecutive Idle states. A faulted
             * connection may succeed for diagnostics and explicit recovery. */
            RobotResult connect(const DiscoveredRobot& robot);

            /** Apply connection settings, then connect() with the same setup wait. */
            RobotResult connect(const RtConnectionInfo& connection);

            /**
             * @brief End the RT session via SdkDisconnectReq (best-effort), then stop
             *        heartbeats/transport. Waits for SdkDisconnectRes before tearing
             *        down local sockets so RT can drop the session immediately; the
             *        next connect() handshake receives a new assigned_session_id.
             * @return The result of the operation (local cleanup always runs).
             */
            RobotResult disconnect();

            /**
             * @brief Number of arms reported by RT (0 before connect() / after disconnect()).
             */
            int armCount() const;

            /**
             * @brief Number of gripper slots reported by RT (0 before connect() / after disconnect()).
             */
            int gripperCount() const;

            /**
             * @brief RT robot_name from SdkConfigRes (empty before connect() / after disconnect()).
             */
            std::string robotName() const;

            /**
             * @brief Active joint count for arm 0 (0 before connect() / after disconnect()).
             */
            int jointCount() const;

            /**
             * @brief Active gripper joint count for arm 0 (0 before connect() / after disconnect()).
             */
            int gripperJointCount() const;

            /**
             * @brief Joint names for arm 0 (empty before connect(); generic j1…jN from DOF).
             */
            std::vector<std::string> jointNames() const;

            /**
             * @brief Zero-filled arm joint vector with length jointCount().
             */
            JointValues zeroJoints() const;

            /**
             * @brief All arm joints enabled; length jointCount().
             */
            JointMask allEnabledMask() const;

            /**
             * @brief Enable arm 0 joints. Length must match jointCount().
             */
            RobotResult enableArmJoint(JointMask arm_state);

            /**
             * @brief Release the control.
             * @return The result of the operation.
             */
            RobotResult releaseControl();

            /**
             * Request a protective software stop (SdkSafeguardReq on monitoring UDP, same as Panel).
             * The SDK latches and keeps sending safeguard (no heartbeats) until SrvState is ERROR.
             * Does not replace the hardware emergency stop. Use the UI recovery action after clearing
             * the fault condition. Requires connect(); does not require holding control.
             */
            RobotResult triggerSafeguardStop();

            /**
             * Stop motion immediately at the current measured pose (Core SdkCommandReq hold).
             * Does not send SdkSafeguardReq and does not put rt_control into ERROR/Fault.
             * Use for UI "stop" while jogging or during movePos; use triggerSafeguardStop() only
             * for protective stop that latches fault like Panel abort.
             *
             * @param wait_for_command_ack If false (default), send hold without waiting for ACK (lowest latency).
             * @param ack_timeout_ms Used when wait_for_command_ack is true.
             */
            RobotResult stopMotion(
                bool wait_for_command_ack = false,
                float ack_timeout_ms = 5000.f);

            // --- Network configuration ---

            /** Read current robot network settings (WiFi password masked). Requires connect(). */
            RobotResult getNetworkConfig(NetworkConfig& out_config, float ack_timeout_ms = 5000.f);

            /** Connect robot WiFi to a router (STA mode). Requires connect(). */
            RobotResult setWifi(
                const std::string& ssid,
                const std::string& password,
                bool enable = true,
                float ack_timeout_ms = 10000.f);

            /**
             * Change wired static IP. Connection will drop; reconnect using the new IP.
             * Provide eth_netmask (e.g. "255.255.255.0") or leave empty with default /24.
             */
            RobotResult setEthStatic(
                const std::string& eth_ip,
                const std::string& eth_netmask,
                const std::string& eth_gateway,
                const std::string& eth_dns = "",
                float ack_timeout_ms = 5000.f);

            /** Restore factory network settings from network.factory.env. */
            RobotResult resetNetworkConfig(float ack_timeout_ms = 10000.f);

            // Motion completion
            /**
             * @brief Wait until the whole robot becomes idle.
             *
             * Wakes promptly on each incoming SrvState (event-driven). poll_interval_sec
             * is the maximum wait between telemetry updates when the link is quiet.
             *
             * @param timeout_sec The timeout in seconds.
             * @param poll_interval_sec Max backoff between state updates (default 0.1 s).
             * @return The result of the operation.
             */
            RobotResult waitUntilIdle(float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

            /**
             * @brief Move and wait.
             * @param move The move function.
             * @param timeout_sec The timeout in seconds.
             * @param poll_interval_sec The poll interval in seconds.
             * @return The result of the operation.
             */
            RobotResult moveAndWait(
                const std::function<RobotResult()>& move,
                float timeout_sec = 30.f,
                float poll_interval_sec = 0.1f);

            /**
             * @brief Move arm 0 and wait. Vector length must match jointCount().
             */
            /** Preferred explicit timing overload. */
            RobotResult movePosAndWait(const JointValues& joints, const MotionOptions& options, float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
            /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
            ROBOT_DEPRECATED("Use movePosAndWait(..., MotionOptions) instead of v,t")
            RobotResult movePosAndWait(
                const JointValues& arm_pos, int v = 50, float t = 0,
                float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

            /**
             * @brief Go home and wait.
             * @param v The velocity.
             * @param t The time.
             * @param timeout_sec The timeout in seconds.
             * @param poll_interval_sec The poll interval in seconds.
             * @return The result of the operation.
             */
            /** Preferred explicit timing overload. */
            RobotResult goHomeAndWait(const MotionOptions& options, float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
            /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
            ROBOT_DEPRECATED("Use goHomeAndWait(..., MotionOptions) instead of v,t")
            RobotResult goHomeAndWait(
                int v = 50, float t = 0,
                float timeout_sec = 30.f, float poll_interval_sec = 0.1f);
            
            /**
             * @brief Fold arm 0 and wait.
             * @param v The velocity.
             * @param t The time.
             * @param timeout_sec The timeout in seconds.
             * @param poll_interval_sec The poll interval in seconds.
             * @return The result of the operation.
             */
            RobotResult foldArmAndWait(
                int v = 50, float t = 0,
                float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

            // Motion Mode
            /**
             * @brief Set the arm smoothing method for every arm.
             *        Per-arm smoothing uses arm(i).setArmSmoothingMethod().
             * @param method The smoothing method.
             * @return The result of the operation.
             */
            RobotResult setArmSmoothingMethod(SmoothingMethod method); //Smoothing method for single target movement

            // Manual Mode
            //
            // Ordinary position moves: t=0 uses v in (0,100] percent; t>0 uses full configured soft limits.
            // t is the requested duration in seconds and may be extended, never shortened.
            // Default v=50 applies to speed mode. Path t[i] is a per-segment duration.
            // Velocity ramps, jog and grippers retain their separate timing semantics.
            /**
             * @brief Move arm 0 joint positions (degrees). Length must match jointCount().
             * @param v Speed percent (0,100] when t=0; ignored when t>0.
             * @param t Requested move duration in seconds; 0 selects speed mode.
             */
            /** Preferred explicit timing overload. */
            RobotResult movePos(const JointValues& joints, const MotionOptions& options);
            /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
            ROBOT_DEPRECATED("Use movePos(..., MotionOptions) instead of v,t")
            RobotResult movePos(const JointValues& arm_pos, int v=50, float t=0);

            /**
             * @brief Move arm 0 through joint waypoints. Each vector length must match jointCount().
             */
            RobotResult movePosPath(const Path<JointValues>& arm_pos, Path<int> v, Path<float> t);

            /**
             * @brief Move arm 0 joint velocities (deg/s). Length must match jointCount().
             */
            RobotResult moveVel(const JointValues& arm_vel, int a=10, float t=0);

            /**
             * @brief Move the end effector point.
             * @param arm_ee The end effector pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveEEPoint(const Pose& arm_ee, int v=50, float t=0);

            /**
             * @brief Move the end effector point path.
             * @param arm_ee The end effector pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveEEPointPath(const Path<Pose>& arm_ee, Path<int> v, Path<float> t);

            /**
             * @brief Move the end effector line.
             * @param arm_ee The end effector pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveEELine(const Pose& arm_ee, int v=50, float t=0);

            /**
             * @brief Move the end effector line path.
             * @param arm_ee The end effector pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveEELinePath(const Path<Pose>& arm_ee, Path<int> v, Path<float> t);

            /**
             * @brief Move the tool point.
             * @param arm_tool The tool pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveToolPoint(const Pose& arm_tool, int v=50, float t=0);

            /**
             * @brief Move the tool point path.
             * @param arm_tool The tool pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveToolPointPath(const Path<Pose>& arm_tool, Path<int> v, Path<float> t);

            /**
             * @brief Move the tool line.
             * @param arm_tool The tool pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveToolLine(const Pose& arm_tool, int v=50, float t=0);

            /**
             * @brief Move the tool line path.
             * @param arm_tool The tool pose.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            RobotResult moveToolLinePath(const Path<Pose>& arm_tool, Path<int> v, Path<float> t);
            
            /**
             * @brief Go home.
             * @param v The velocity.
             * @param t The time.
             * @return The result of the operation.
             */
            /** Preferred explicit timing overload. */
            RobotResult goHome(const MotionOptions& options);
            /** @deprecated Use the overload taking MotionOptions; removal is planned for a future major release. */
            ROBOT_DEPRECATED("Use goHome(..., MotionOptions) instead of v,t")
            RobotResult goHome(int v=50, float t=0);

            /**
             * @brief Fold arm 0 to the built-in fold posture (degrees) from the current joints.
             *        Use foldArmAndWait to block until done.
             */
            RobotResult foldArm(int v=50, float t=0);

            /**
             * @brief Move arm 0 gripper joints. Length must match gripperJointCount().
             *        Values are panel-normalized [0, 1] (0=open, 1=close), matching
             *        getJointState().gripper — not Configurator gripper soft/hard limits.
             */
            RobotResult moveGripperPos(const JointValues& pos, int v=50, float t=0);

            /**
             * @brief moveGripperPos then wait until gripper feedback reaches the target.
             *        Prefer this over moveAndWait(moveGripperPos): RT system_state often
             *        stays Idle during gripper-only motion, so Idle-based waits finish early.
             *        @p pos uses the same panel [0, 1] units as moveGripperPos.
             */
            RobotResult moveGripperPosAndWait(
                const JointValues& pos, int v = 50, float t = 0,
                float timeout_sec = 30.f, float poll_interval_sec = 0.1f);

            // Teach & Replayback Mode
            /**
             * @brief Start drag teaching and recording. Starting after a stop replaces the previous recording.
             * @return The result of the operation.
             */
            RobotResult startTeach();

            /**
             * @brief Freeze recording without leaving drag teaching or changing control mode.
             *        Waits for RT acknowledgment and execution feedback. The legacy protocol stops recording
             *        for all arms together. Equivalent to arm(0).stopRecording().
             */
            RobotResult stopRecording();

            /**
             * @brief Stop recording and hold the current position in joint control.
             *        Retains the recorded trajectory for playback. Waits for fresh
             *        feedback and acknowledgment of the hold command, not physical
             *        settling. Equivalent to arm(0).stopTeach().
             * @return The result of the operation.
             */
            RobotResult stopTeach();

            /**
             * @brief Export arm 0's frozen recording to a client-side JSON file.
             *        Requires stopRecording() or stopTeach() and a compatible RT.
             *        Replaces the file only after successful export; never stops motion.
             */
            RobotResult saveTrajectory(const std::string& local_path);

            /**
             * @brief Start the playback mode.
             * @return The result of the operation.
             */
            RobotResult startPlayback();

            /**
             * @brief Stop the playback mode.
             * @return The result of the operation.
             */
            RobotResult stopPlayback();

            /**
             * @brief Reset the playback mode.
             * @return The result of the operation.
             */
            RobotResult resetPlayback();

            // Feedback — Robot methods below are equivalent to arm(0).
            /**
             * @brief Get arm 0 joint state with runtime-sized vectors.
             */
            JointState getJointState() const;

            /**
             * @brief Current arm 0 joint positions (length jointCount(), degrees).
             */
            JointValues jointPositions() const;

            /**
             * @brief Get arm 0 joint velocities with runtime-sized vectors.
             */
            JointState getJointVel() const;

            /**
             * @brief Get arm 0 joint torques with runtime-sized vectors.
             */
            JointState getJointTor() const;

            /**
             * @brief Get arm 0 end-effector pose. Equivalent to arm(0).getEEPose().
             */
            Pose getEEPose() const;

            /**
             * @brief Get arm 0 tool pose. Equivalent to arm(0).getToolPose().
             */
            Pose getToolPose() const;

            /**
             * @brief Arm 0 joint enable mask (length jointCount()).
             */
            JointMask getArmJointEnabledMask() const;

            /**
             * @brief Get the system status.
             * @return Whole-robot state. Joint diagnostic arrays are indexed [arm][joint].
             */
            SystemStatus getStatus() const;

            /**
             * @brief Print the system status.
             * @param status The system status.
             */
            void printStatus(const SystemStatus& status) const;

            // Events & diagnostics
            // on_state_changed / on_fault: SDK event dispatch thread, never a
            // transport thread, so a slow callback cannot stall telemetry or trip
            // the receive watchdog. Callbacks for one Robot are serialized.
            // on_motion_done: caller thread of waitUntilIdle / moveAndWait.
            // disconnect() from a callback is allowed: the session closes at once,
            // and the socket close plus thread joins run on the next call from the
            // application thread (or in ~Robot). Blocking motion APIs and connect()
            // are not allowed from a callback, and destroying the Robot from one
            // leaks its implementation rather than freeing state still in use.
            /**
             * @brief Set the state changed callback.
             * @param callback The state changed callback.
             */
            void setOnStateChanged(StateChangedCallback callback);

            /**
             * @brief Set the motion done callback.
             * @param callback The motion done callback.
             */
            void setOnMotionDone(MotionDoneCallback callback);

            /**
             * @brief Clear the event callbacks.
             */
            void clearEventCallbacks();

            /** SDK watchdog disconnects after 3000 ms without an authenticated
             * RT packet from this robot, before timestamp/sequence filtering.
             * Status reads do not run the watchdog. Reconnect clears the latch.
             */
            ConnectionStatus getConnectionStatus() const;
            bool isConnected() const;

            /**
             * @brief Get the configurator.
             * @return The configurator.
             */
            Configurator& getConfigurator();

            /** Non-owning per-arm handle. Reacquire after moving this Robot or reconnecting.
             * Include robot_sdk/arm.h for the complete handle type. */
            Arm arm(int index);
            Arm arm(int index) const;
            /** Synchronized arms 0/1 handle; throws RobotException unless connected
             * with at least two arms. Include robot_sdk/dual_arm.h. */
            DualArm dualArm();
            DualArm dualArm() const;


        private:
            friend struct detail::RobotMotionTestAccess;
            friend class Arm;
            friend class DualArm;
            friend class Component;
            friend class CommandFrame;
            friend class ControlStream;
            friend class internal::Robot;
            Configurator& configuratorFor(int arm_index);

            struct Impl;
            std::unique_ptr<Impl> pimpl_;
    };
}
#endif  // ROBOT_SDK_ROBOT_H
