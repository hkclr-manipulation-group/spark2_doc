#ifndef ROBOT_SDK_RESULT_H
#define ROBOT_SDK_RESULT_H

#include <cstdint>
#include <stdexcept>
#include <string>

#include "robot_sdk/export.h"

namespace robot::platform {
enum class CommandResponseStatus : uint8_t;
}

namespace robot {

enum class RobotErrorCode : uint16_t {
    kOk = 0,
    kNotStarted,
    kTransportUnavailable,
    kTimeout,
    kKeysLoadFailed,
    kStartFailed,
    kCommandRejectedFaulted,
    kCommandRejectedSequence,
    kCommandInvalid,
    kInvalidClientOrSession,
    kInvalidConfig,
    kConfigAckFailed,
    kCommandAckFailed,
    kControlLost,
    kMotionInterrupted,
    kPoseNotReachable,
    kRecoveryFailed,
    kReleaseControlFailed,
    kDisconnectFailed,
    kInvalidArgument,
    kUnknown,
    kUnsupported,
    kRecoveryConflict,
    kRecoveryResultExpired,
    kRecoveryResultUnknown,

};

struct ROBOT_API RobotResult {
    RobotErrorCode code = RobotErrorCode::kOk;
    std::string message;

    bool ok() const { return code == RobotErrorCode::kOk; }
    explicit operator bool() const { return ok(); }

    /** Opt in to exception-style handling while preserving result-returning APIs. */
    void throwIfError() const;

    static RobotResult success();
    static RobotResult error(RobotErrorCode code, std::string message);
};

#define ROBOT_RETURN_IF_ERROR(expr) \
    do { \
        const RobotResult _robot_result = (expr); \
        if (!_robot_result) { \
            return _robot_result; \
        } \
    } while (0)

class ROBOT_API RobotException : public std::runtime_error {
public:
    RobotErrorCode code;

    RobotException(RobotErrorCode code, const std::string& message);
};

ROBOT_API RobotErrorCode fromCommandStatus(robot::platform::CommandResponseStatus status);
ROBOT_API std::string errorCodeToString(RobotErrorCode code);
ROBOT_API RobotResult fromPlatformStatus(
    robot::platform::CommandResponseStatus status,
    const std::string& context);

}  // namespace robot

#endif
