#ifndef ROBOT_C_API_RESULT_H
#define ROBOT_C_API_RESULT_H

#include <stddef.h>
#include <stdint.h>

#include "robot_sdk_c/export.h"
#include "robot_sdk_c/types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum robot_error_code {
    ROBOT_OK = 0,
    ROBOT_NOT_STARTED,
    ROBOT_TRANSPORT_UNAVAILABLE,
    ROBOT_TIMEOUT,
    ROBOT_KEYS_LOAD_FAILED,
    ROBOT_START_FAILED,
    ROBOT_COMMAND_REJECTED_FAULTED,
    ROBOT_COMMAND_REJECTED_SEQUENCE,
    ROBOT_COMMAND_INVALID,
    ROBOT_INVALID_CLIENT_OR_SESSION,
    ROBOT_INVALID_CONFIG,
    ROBOT_CONFIG_ACK_FAILED,
    ROBOT_COMMAND_ACK_FAILED,
    ROBOT_CONTROL_LOST,
    ROBOT_MOTION_INTERRUPTED,
    ROBOT_POSE_NOT_REACHABLE,
    ROBOT_RECOVERY_FAILED,
    ROBOT_RELEASE_CONTROL_FAILED,
    ROBOT_DISCONNECT_FAILED,
    ROBOT_INVALID_ARGUMENT,
    ROBOT_UNKNOWN,
    ROBOT_UNSUPPORTED,
    ROBOT_RECOVERY_CONFLICT,
    ROBOT_RECOVERY_RESULT_EXPIRED,
    ROBOT_RECOVERY_RESULT_UNKNOWN,
} robot_error_code;

typedef struct robot_result {
    robot_error_code code;
    char message[ROBOT_RESULT_MESSAGE_SIZE];
} robot_result;

ROBOT_C_API int robot_result_ok(const robot_result* result);
ROBOT_C_API const char* robot_error_code_to_string(robot_error_code code);

#ifdef __cplusplus
}
#endif

#endif
