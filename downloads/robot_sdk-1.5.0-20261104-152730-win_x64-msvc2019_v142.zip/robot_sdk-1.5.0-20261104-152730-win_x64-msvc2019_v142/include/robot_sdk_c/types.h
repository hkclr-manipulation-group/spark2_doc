#ifndef ROBOT_C_API_TYPES_H
#define ROBOT_C_API_TYPES_H

#include <stddef.h>
#include <stdint.h>

#include "robot_sdk_c/export.h"

#ifdef __cplusplus
extern "C" {
#endif

#define ROBOT_C_PI 3.14159265358979323846f
#define ROBOT_C_DEG_TO_RAD (ROBOT_C_PI / 180.0f)
#define ROBOT_C_RAD_TO_DEG (180.0f / ROBOT_C_PI)

#define ROBOT_MAX_ARM_COUNT 2
#define ROBOT_MAX_GRIPPER_COUNT 2
#define ROBOT_MAX_JOINTS 32
#define ROBOT_RESULT_MESSAGE_SIZE 256
#define ROBOT_NAME_MAX 128
#define ROBOT_IP_MAX 64
#define ROBOT_VERSION_MAX 64
#define ROBOT_SSID_MAX 64
#define ROBOT_PASSWORD_MAX 128
#define ROBOT_NETMASK_MAX 64

typedef struct robot_quaternion {
    float w, x, y, z;
} robot_quaternion;

typedef struct robot_euler_angle {
    float roll, pitch, yaw;
} robot_euler_angle;

typedef struct robot_position {
    float x, y, z;
} robot_position;

typedef struct robot_pose {
    robot_position position;
    robot_quaternion orientation;
} robot_pose;

typedef struct robot_joint_limits {
    float min;
    float max;
} robot_joint_limits;

typedef struct robot_joint_state {
    float arm[ROBOT_MAX_JOINTS];
    size_t arm_count;
    float gripper[ROBOT_MAX_JOINTS];
    size_t gripper_count;
} robot_joint_state;

typedef enum robot_log_level {
    ROBOT_LOG_TRACE = 0,
    ROBOT_LOG_DEBUG,
    ROBOT_LOG_INFO,
    ROBOT_LOG_WARN,
    ROBOT_LOG_ERROR,
    ROBOT_LOG_OFF
} robot_log_level;

typedef enum robot_robot_state {
    ROBOT_STATE_STARTUP = 0,
    ROBOT_STATE_IDLE = 1,
    ROBOT_STATE_MOVING = 2,
    ROBOT_STATE_SETTLING = 3,
    ROBOT_STATE_ERROR = 4,
    ROBOT_STATE_RECOVERY = 5,
    ROBOT_STATE_SHUTDOWN = 6,
    ROBOT_STATE_OFFLINE = 7
} robot_robot_state;

typedef enum robot_plan_result {
    ROBOT_PLAN_SUCCESS = 0,
    ROBOT_PLAN_POSE_NOT_REACHABLE = 1,
    ROBOT_PLAN_LINEAR_PATH_FAILED = 2,
    ROBOT_PLAN_NONE = 3
} robot_plan_result;

typedef enum robot_smoothing_method {
    ROBOT_SMOOTHING_LINEAR = 0,
    ROBOT_SMOOTHING_COS,
    ROBOT_SMOOTHING_CUBIC,
    ROBOT_SMOOTHING_QUINTIC,
    ROBOT_SMOOTHING_QUINTIC_PATH,
    ROBOT_SMOOTHING_LOW_PASS_FILTER,
    ROBOT_SMOOTHING_NONE
} robot_smoothing_method;

typedef struct robot_system_status {
    robot_robot_state robot_state;
    robot_plan_result plan_result;
    uint64_t robot_diagnostic_flags;
    int arm_size;
    int gripper_size;
    uint64_t arm_joint_diagnostic_flags[ROBOT_MAX_ARM_COUNT][ROBOT_MAX_JOINTS];
    size_t arm_joint_counts[ROBOT_MAX_ARM_COUNT];
    uint64_t gripper_joint_diagnostic_flags[ROBOT_MAX_GRIPPER_COUNT][ROBOT_MAX_JOINTS];
    size_t gripper_joint_counts[ROBOT_MAX_GRIPPER_COUNT];
} robot_system_status;

typedef struct robot_rt_connection_info {
    const char* server_ip; /* empty or NULL = auto-discovery on connect */
} robot_rt_connection_info;

typedef struct robot_discovered_robot {
    char robot_name[ROBOT_NAME_MAX];
    char server_ip[ROBOT_IP_MAX];
    uint32_t session_id;
    uint32_t last_handshake_sequence_id;
    int64_t time_offset_us;
    int64_t handshake_rtt_us;
    char robot_version[ROBOT_VERSION_MAX];
} robot_discovered_robot;

typedef struct robot_joint_path {
    const float* waypoints; /* waypoint_count * dof contiguous */
    size_t waypoint_count;
    size_t dof;
} robot_joint_path;
typedef struct robot_pose_path {
    const robot_pose* waypoints;
    size_t waypoint_count;
} robot_pose_path;

/* Fixed-size mirror of robot::NetworkConfig, filled by
 * robot_session_get_network_config(). String fields are always NUL-terminated;
 * wifi_password is empty when the server masks it. */
typedef struct robot_network_config {
    char eth_ip[ROBOT_IP_MAX];
    int eth_prefix;
    char eth_netmask[ROBOT_NETMASK_MAX];
    char eth_gateway[ROBOT_IP_MAX];
    char eth_dns[ROBOT_IP_MAX];
    char server_ip[ROBOT_IP_MAX];
    int wifi_enable;
    char wifi_ssid[ROBOT_SSID_MAX];
    char wifi_password[ROBOT_PASSWORD_MAX];
} robot_network_config;

/* Fixed-size mirror of robot::ConnectionStatus. Booleans are 0/1 ints so the
 * struct layout does not depend on the C compiler's _Bool ABI.
 *
 * receive_age_ms stops advancing while the session is torn down; a latched
 * telemetry_timed_out stays 1 until the next successful connect(). */
typedef struct robot_connection_status {
    int connected;
    int telemetry_timed_out;
    uint32_t receive_age_ms;
    uint32_t receive_timeout_ms;
} robot_connection_status;





typedef struct robot_session robot_session;

#ifdef __cplusplus
}
#endif

#endif
