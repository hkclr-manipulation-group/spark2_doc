#ifndef ROBOT_C_API_CONFIGURATOR_H
#define ROBOT_C_API_CONFIGURATOR_H

#include <stddef.h>

#include "robot_sdk_c/export.h"
#include "robot_sdk_c/result.h"
#include "robot_sdk_c/types.h"

#ifdef __cplusplus
extern "C" {
#endif

ROBOT_C_API robot_result robot_session_config_set_tool_offset(
    robot_session* session, const robot_position* offset);
ROBOT_C_API robot_result robot_session_config_get_tool_offset(
    robot_session* session, robot_position* out_offset);

ROBOT_C_API robot_result robot_session_config_set_arm_pos_limits(
    robot_session* session, const robot_joint_limits* limits, size_t count);
ROBOT_C_API robot_result robot_session_config_set_arm_vel_limits(
    robot_session* session, const robot_joint_limits* limits, size_t count);
ROBOT_C_API robot_result robot_session_config_get_arm_pos_limits(
    robot_session* session, robot_joint_limits* limits, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_vel_limits(
    robot_session* session, robot_joint_limits* limits, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_pos(
    robot_session* session, robot_joint_limits* limits, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_vel(
    robot_session* session, robot_joint_limits* limits, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_pos_jump(
    robot_session* session, float* values, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_vel_jump(
    robot_session* session, float* values, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_pos_follow_error(
    robot_session* session, float* values, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_vel_follow_error(
    robot_session* session, float* values, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_arm_max_tor_follow_error(
    robot_session* session, float* values, size_t capacity,
    size_t* out_count);

ROBOT_C_API robot_result robot_session_config_set_gripper_pos_limits(
    robot_session* session, const robot_joint_limits* limits, size_t count);
ROBOT_C_API robot_result robot_session_config_get_gripper_pos_limits(
    robot_session* session, robot_joint_limits* limits, size_t capacity,
    size_t* out_count);
ROBOT_C_API robot_result robot_session_config_get_gripper_max_pos(
    robot_session* session, robot_joint_limits* limits, size_t capacity,
    size_t* out_count);

#ifdef __cplusplus
}
#endif

#endif
