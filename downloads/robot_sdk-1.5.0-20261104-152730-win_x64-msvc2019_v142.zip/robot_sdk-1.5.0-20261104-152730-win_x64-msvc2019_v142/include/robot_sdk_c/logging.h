#ifndef ROBOT_C_API_LOGGING_H
#define ROBOT_C_API_LOGGING_H

#include "robot_sdk_c/export.h"
#include "robot_sdk_c/types.h"

#ifdef __cplusplus
extern "C" {
#endif

ROBOT_C_API void robot_set_log_level(robot_log_level level);
ROBOT_C_API robot_log_level robot_get_log_level(void);
ROBOT_C_API void robot_set_log_to_file(int enabled);
ROBOT_C_API void robot_set_log_to_stderr(int enabled);

#ifdef __cplusplus
}
#endif

#endif
