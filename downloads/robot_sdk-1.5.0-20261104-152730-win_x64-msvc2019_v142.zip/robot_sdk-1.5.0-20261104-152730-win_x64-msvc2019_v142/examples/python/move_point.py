from utils import (
    print_feedback,
    check_result,
    check_bool,
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)
from robot_sdk import Pose, Position


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)
        print("Arm started")

        v = 30
        t = 5.0
        print_dt = 0.3
        timeout = 50.0

        prefix_text = "==> move_pos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n"
        check_result(robot.move_pos([10.0, 20.0, 30.0, 40.0, 50.0, 60.0], v, 0.0), "move_pos")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )
        current_pose = robot.get_tool_pose()

        target_pose = Pose(
            position=Position(
                x=current_pose.position.x,
                y=current_pose.position.y - 0.1,
                z=current_pose.position.z - 0.05,
            ),
            orientation=current_pose.orientation,
        )
        prefix_text = (
            f"==> move_tool_point (position: ({target_pose.position.x}, "
            f"{target_pose.position.y}, {target_pose.position.z}), "
            f"orientation: ({target_pose.orientation.w}, {target_pose.orientation.x}, "
            f"{target_pose.orientation.y}, {target_pose.orientation.z}))\n"
        )
        check_result(robot.move_tool_point(target_pose, v, 0.0), "move_tool_point")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )

        prefix_text = "==> move_pos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n"
        check_result(robot.move_pos([10.0, 20.0, 30.0, 40.0, 50.0, 60.0], v, 0.0), "move_pos")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )
        current_pose = robot.get_tool_pose()

        target_pose = Pose(
            position=Position(
                x=current_pose.position.x,
                y=current_pose.position.y + 0.1,
                z=current_pose.position.z - 0.05,
            ),
            orientation=current_pose.orientation,
        )
        prefix_text = (
            f"==> move_tool_line (position: ({target_pose.position.x}, "
            f"{target_pose.position.y}, {target_pose.position.z}), "
            f"orientation: ({target_pose.orientation.w}, {target_pose.orientation.x}, "
            f"{target_pose.orientation.y}, {target_pose.orientation.z}))\n"
        )
        check_result(robot.move_tool_line(target_pose, 0, t), "move_tool_line")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )

        prefix_text = "==> Go to home position (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)\n"
        check_result(robot.go_home(20, t), "go_home")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )

        print("Motion completed")


if __name__ == "__main__":
    main()
