"""Synchronized dual-arm path motions (public SDK).

Ported from dual_arm_sdk/python/examples/move_path.py.
"""

from utils import check_result, build_robot_ip_parser, robot_session
from robot_sdk import Pose, Position, Quaternion, MotionOptions


def _joint_target(arm, j4_deg: float) -> list[float]:
    target = list(arm.zero_joints())
    if len(target) > 3:
        target[3] = j4_deg
    for i in range(4, min(len(target), 7)):
        target[i] = 5.0
    return target


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    with robot_session(args.ip) as robot:
        if robot.arm_count() < 2:
            print("This example requires a dual-arm robot (arm_count >= 2).")
            return

        left = robot.arm(0)
        right = robot.arm(1)
        check_result(
            robot.dual_arm().enable_arm_joint(left.all_enabled_mask(), right.all_enabled_mask()),
            "enable_arm_joint_both",
        )

        both = robot.dual_arm()
        v, t = 30, 0.0
        speeds = [v, v]
        durations = [t, t]

        left_path = [_joint_target(left, 30.0), _joint_target(left, 45.0)]
        right_path = [_joint_target(right, 30.0), _joint_target(right, 45.0)]

        print("==> move_pos_path both arms")
        check_result(
            both.move_pos_path_and_wait(left_path, right_path, speeds, durations),
            "dual_arm.move_pos_path_and_wait",
        )

        tool_left = Pose(
            position=Position(0.363605, 0.760355, 1.33114),
            orientation=Quaternion(0.680006, -0.645236, -0.200654, 0.284605),
        )
        tool_right = Pose(
            position=Position(0.363605, -0.760355, 1.33114),
            orientation=Quaternion(0.645234, -0.680031, 0.284588, -0.200598),
        )

        print("==> move_tool_line_path both arms")
        check_result(
            both.move_tool_line_path_and_wait(
                [tool_left, tool_left], [tool_right, tool_right], speeds, durations
            ),
            "dual_arm.move_tool_line_path_and_wait",
        )

        print("==> go_home both arms")
        check_result(both.go_home_and_wait(MotionOptions.speed_limited(20)), "dual_arm.go_home_and_wait")

        print("Path motion completed")


if __name__ == "__main__":
    main()
