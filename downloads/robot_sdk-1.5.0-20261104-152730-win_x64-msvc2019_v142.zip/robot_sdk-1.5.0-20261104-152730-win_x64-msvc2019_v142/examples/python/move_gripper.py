from utils import (
    check_result,
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)


def print_gripper_state(robot, title: str) -> None:
    state = robot.get_joint_state()
    gripper = list(state.gripper)
    print(f"{title} gripper joints:", gripper if gripper else "(none)")


def print_limits(title: str, limits) -> None:
    print(f"{title}:")
    for i, lim in enumerate(limits):
        print(f"  joint {i}: [{lim.min}, {lim.max}]")


def gripper_panel_pos(dof: int, panel_value: float):
    """Panel gripper command space is [0, 1] (0=open, 1=close)."""
    return [panel_value] * dof


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    print(
        "Demonstrates move_gripper_pos_and_wait (open / close).\n"
        "Requires a robot with gripper_count() > 0.\n"
        "Gripper commands/feedback use panel units [0, 1]:\n"
        "  0 = open, 1 = close (same as get_joint_state().gripper).\n"
        "Safety soft/hard limits from the configurator are motor units\n"
        "(e.g. degrees) and must not be used as move_gripper_pos targets.\n"
    )

    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)

        gripper_slots = robot.gripper_count()
        gripper_dof = robot.gripper_joint_count()
        print(
            f"Topology: arm_count={robot.arm_count()} "
            f"gripper_count={gripper_slots} "
            f"gripper_joint_count={gripper_dof}"
        )
        if gripper_slots <= 0 or gripper_dof <= 0:
            print("No gripper on this robot; nothing to demo.")
            return

        cfg = robot.get_configurator()
        print_limits(
            "Gripper soft limits (safety, not command units)",
            list(cfg.get_gripper_pos_limits()),
        )
        print_limits(
            "Gripper hard limits (safety, not command units)",
            list(cfg.get_gripper_max_pos()),
        )

        v = 30
        timeout_sec = 30.0
        poll_interval_sec = 0.1
        # Panel space: keep a margin from the endpoints so both moves are visible.
        open_pos = gripper_panel_pos(gripper_dof, 0.1)
        close_pos = gripper_panel_pos(gripper_dof, 0.9)

        print_gripper_state(robot, "Current")
        print("Open command (panel):", open_pos)
        print("Close command (panel):", close_pos)

        print("\n==> move_gripper_pos_and_wait (open)")
        check_result(
            robot.move_gripper_pos_and_wait(
                open_pos, v, 0.0, timeout_sec, poll_interval_sec
            ),
            "move_gripper_pos_and_wait(open)",
        )
        print_gripper_state(robot, "After open")

        print("\n==> move_gripper_pos_and_wait (close)")
        check_result(
            robot.move_gripper_pos_and_wait(
                close_pos, v, 0.0, timeout_sec, poll_interval_sec
            ),
            "move_gripper_pos_and_wait(close)",
        )
        print_gripper_state(robot, "After close")


    print("\nGripper demo completed.")


if __name__ == "__main__":
    main()
