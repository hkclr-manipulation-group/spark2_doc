from utils import (
    check_result,
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    print("Demonstrates fold_arm: move directly to built-in fold posture.\n")

    v = 30
    timeout_sec = 120.0
    poll_interval_sec = 0.1

    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)

        print("==> move_pos_and_wait (start away from home / fold)")
        check_result(
            robot.move_pos_and_wait(
                [10.0, 15.0, 10.0, 10.0, 0.0, 0.0],
                v,
                0.0,
                timeout_sec,
                poll_interval_sec,
            ),
            "move_pos_and_wait",
        )

        print("\n==> fold_arm_and_wait")
        check_result(
            robot.fold_arm_and_wait(v, 0.0, timeout_sec, poll_interval_sec),
            "fold_arm_and_wait",
        )

        pos = robot.get_joint_state()
        print("Final joint position (deg):", list(pos.arm))


    print("Fold motion completed.")


if __name__ == "__main__":
    main()
