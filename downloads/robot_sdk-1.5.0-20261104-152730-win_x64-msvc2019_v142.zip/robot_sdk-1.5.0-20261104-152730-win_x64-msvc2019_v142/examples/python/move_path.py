from utils import (
    print_feedback,
    check_result,
    check_bool,
    enable_all_arm_joints,
    build_robot_ip_parser,
    robot_session,
)
from robot_sdk import Pose, Position


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    with robot_session(args.ip) as robot:
        enable_all_arm_joints(robot)
        print("Arm started")

        print_dt = 0.3
        timeout = 50.0

        prefix_text = "==> move_pos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n"
        check_result(robot.move_pos([10.0, 20.0, 30.0, 40.0, 50.0, 60.0], 0, 5.0), "move_pos")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )
        current_pose = robot.get_tool_pose()

        prefix_text = "==> Move Tool Line\n"
        target_pose = Pose(
            position=Position(
                x=current_pose.position.x,
                y=current_pose.position.y - 0.1,
                z=current_pose.position.z - 0.05,
            ),
            orientation=current_pose.orientation,
        )
        path1 = [target_pose, current_pose]
        check_result(robot.move_tool_line_path(path1, [30, 30], []), "move_tool_line_path")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )

        prefix_text = "==> move_pos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n"
        check_result(robot.move_pos([10.0, 20.0, 30.0, 40.0, 50.0, 60.0], 0, 5.0), "move_pos")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )
        current_pose = robot.get_tool_pose()

        prefix_text = "==> Move Tool Point\n"
        target_pose = Pose(
            position=Position(
                x=current_pose.position.x - 0.2,
                y=current_pose.position.y + 0.1,
                z=current_pose.position.z - 0.05,
            ),
            orientation=current_pose.orientation,
        )
        path2 = [target_pose, current_pose]
        check_result(robot.move_tool_point_path(path2, [], [5.0, 5.0]), "move_tool_point_path")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )

        prefix_text = "==> Move Joint Pos\n"
        path3 = [
            ([-10.0, -20.0, -30.0, -10.0, -10.0, -10.0]),
            ([0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
        ]
        check_result(robot.move_pos_path(path3, [], [10.0, 10.0]), "move_pos_path")
        check_bool(
            print_feedback(robot, print_dt, timeout, prefix_text, print_joint=True, print_tool=True),
            "wait after motion",
        )

        print("Motion completed")


if __name__ == "__main__":
    main()
