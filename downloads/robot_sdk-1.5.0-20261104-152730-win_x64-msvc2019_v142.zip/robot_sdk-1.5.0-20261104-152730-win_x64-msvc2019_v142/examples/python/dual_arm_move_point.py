"""Synchronized dual-arm point motions (public SDK).

Ported from dual_arm_sdk/python/examples/move_point.py.
"""

from utils import check_result, build_robot_ip_parser, robot_session
from robot_sdk import Pose, Position, Quaternion, MotionOptions


def _joint_target(arm, j4_deg: float) -> list[float]:
    target = list(arm.zero_joints())
    if len(target) > 3:
        target[3] = j4_deg
    for i in range(4, min(len(target), 7)):
        target[i] = 5.0
    return target


def _tool_pose_left() -> Pose:
    return Pose(
        position=Position(0.363605, 0.760355, 1.33114),
        orientation=Quaternion(0.680006, -0.645236, -0.200654, 0.284605),
    )


def _tool_pose_right() -> Pose:
    return Pose(
        position=Position(0.363605, -0.760355, 1.33114),
        orientation=Quaternion(0.645234, -0.680031, 0.284588, -0.200598),
    )


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    with robot_session(args.ip) as robot:
        n = robot.arm_count()
        print(f"arm_count={n}")
        if n < 2:
            print("This example requires a dual-arm robot (arm_count >= 2).")
            return

        left = robot.arm(0)
        right = robot.arm(1)
        check_result(
            robot.dual_arm().enable_arm_joint(left.all_enabled_mask(), right.all_enabled_mask()),
            "enable_arm_joint_both",
        )
        print("Both arms enabled")

        both = robot.dual_arm()
        v, t = 30, 0.0
        options = MotionOptions.speed_limited(v)

        print("==> move_pos both arms")
        check_result(
            both.move_pos_and_wait(_joint_target(left, 45.0), _joint_target(right, 45.0), options),
            "dual_arm.move_pos_and_wait",
        )

        print("==> move_tool_point both arms")
        check_result(
            both.move_tool_point_and_wait(_tool_pose_left(), _tool_pose_right(), v, t),
            "dual_arm.move_tool_point_and_wait",
        )

        print("==> move_pos with different targets")
        check_result(
            both.move_pos_and_wait(_joint_target(left, 45.0), _joint_target(right, 30.0), options),
            "dual_arm.move_pos_and_wait (different targets)",
        )

        print("==> move_tool_line both arms")
        check_result(
            both.move_tool_line_and_wait(_tool_pose_left(), _tool_pose_right(), v, t),
            "dual_arm.move_tool_line_and_wait",
        )

        print("==> go_home both arms")
        check_result(both.go_home_and_wait(MotionOptions.speed_limited(20)), "dual_arm.go_home_and_wait")

        print("Motion completed")


if __name__ == "__main__":
    main()
