import time

from utils import check_result, build_robot_ip_parser, robot_session
from robot_sdk import Position


def print_pos_soft_limits(title: str, limits) -> None:
    print(f"{title} (deg):")
    for i, lim in enumerate(limits):
        print(f"  joint {i}: [{lim.min}, {lim.max}]")


def print_vel_soft_limits(title: str, limits) -> None:
    print(f"{title} (deg/s, symmetric):")
    for i, lim in enumerate(limits):
        print(f"  joint {i}: ±{lim.max}")


def main() -> None:
    args = build_robot_ip_parser().parse_args()
    print(
        "Writes tool offset and soft limits to RT (may persist to runtime_config.json).\n"
        "Use on a test robot or restore values manually after the demo.\n"
    )

    with robot_session(args.ip) as robot:
        print("Connected, arm joints:", robot.joint_count())

        configurator = robot.get_configurator()

        tool_offset = configurator.get_tool_offset()
        print(
            "Tool offset before (m):",
            tool_offset.x,
            tool_offset.y,
            tool_offset.z,
        )
        check_result(
            configurator.set_tool_offset(Position(x=0.01, y=0.02, z=0.03)),
            "set_tool_offset",
        )
        time.sleep(0.5)
        tool_offset = configurator.get_tool_offset()
        print(
            "Tool offset after  (m):",
            tool_offset.x,
            tool_offset.y,
            tool_offset.z,
        )
        print("--------------------------------------------------------")

        pos_before = configurator.get_arm_pos_limits()
        print_pos_soft_limits("Soft position limits before", pos_before)

        pos_new = []
        for i, lim in enumerate(pos_before):
            mn, mx = lim.min, lim.max
            if i == 0:
                mn += 1.0
                mx -= 1.0
            pos_new.append((mn, mx))
        check_result(configurator.set_arm_pos_limits(pos_new), "set_arm_pos_limits")
        time.sleep(0.5)

        pos_after = configurator.get_arm_pos_limits()
        print_pos_soft_limits("Soft position limits after", pos_after)
        print("--------------------------------------------------------")

        vel_before = configurator.get_arm_vel_limits()
        print_vel_soft_limits("Soft velocity limits before", vel_before)

        vel_new = []
        for i, lim in enumerate(vel_before):
            if i == 0:
                vel_new.append((-250.0, 250.0))
            else:
                vel_new.append((lim.min, lim.max))
        check_result(configurator.set_arm_vel_limits(vel_new), "set_arm_vel_limits")
        time.sleep(0.5)

        vel_after = configurator.get_arm_vel_limits()
        print_vel_soft_limits("Soft velocity limits after", vel_after)
        print("--------------------------------------------------------")

        print_pos_soft_limits("Hard position limits (read-only)", configurator.get_arm_max_pos())
        print_vel_soft_limits("Hard velocity limits (read-only)", configurator.get_arm_max_vel())
        print("--------------------------------------------------------")


if __name__ == "__main__":
    main()
