using System;
using System.Linq;
using Robot.Sdk;

namespace Spark2.Examples
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            var robot = new Robot();
            Logging.SetLogLevel(LogLevel.Info);

            ExampleCommon.ConnectToRobot(robot, ExampleCommon.RobotIpFromArgs(args));

            ExampleCommon.EnableAllArmJoints(robot);

            const int speed = 30;
            var target = new[] { 10f, 20f, 30f, 40f, 50f, 60f };
            ExampleCommon.CheckResult(robot.MovePos(target, speed, 0f), "move_pos");
            ExampleCommon.CheckResult(robot.WaitUntilIdle(60f, 0.1f), "wait_until_idle");

            var joints = robot.GetPos();
            Console.WriteLine(
                "Arm joints (deg): [" +
                string.Join(", ", joints.Arm.Select(v => v.ToString("F2"))) + "]");

            var toolPose = robot.GetToolPose();
            Console.WriteLine(
                string.Format("Tool pose: pos=({0:F3}, {1:F3}, {2:F3})",
                    toolPose.Position.X, toolPose.Position.Y, toolPose.Position.Z));

            ExampleCommon.CheckResult(robot.Disconnect(), "disconnect");
            Console.WriteLine("Done.");
        }
    }
}
