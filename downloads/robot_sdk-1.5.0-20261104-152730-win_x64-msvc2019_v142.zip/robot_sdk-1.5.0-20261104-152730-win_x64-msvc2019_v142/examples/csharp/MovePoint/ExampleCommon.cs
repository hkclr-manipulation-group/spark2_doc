using System;
using Robot.Sdk;

namespace Spark2.Examples
{
    internal static class ExampleCommon
    {
        public static void CheckResult(RobotResult result, string label)
        {
            if (!result.Ok)
            {
                throw new InvalidOperationException(
                    string.Format("{0} failed: {1} ({2})", label, result.Message, result.Code));
            }
        }

        /// <summary>
        /// Parse optional robot IP from args: program [IP] or program --ip IP ...
        /// </summary>
        public static string RobotIpFromArgs(string[] args)
        {
            for (var i = 0; i + 1 < args.Length; i++)
            {
                if (args[i] == "--ip")
                {
                    return args[i + 1];
                }
            }

            if (args.Length >= 1 && !args[0].StartsWith("-"))
            {
                return args[0];
            }

            return null;
        }

        /// <summary>
        /// Connect to ip when given; otherwise enumerate and use the first robot.
        /// </summary>
        public static void ConnectToRobot(Robot robot, string ip)
        {
            if (!string.IsNullOrEmpty(ip))
            {
                Console.WriteLine("Connecting to {0}", ip);
                CheckResult(robot.Connect(RtConnectionInfo.To(ip)), "connect");
                return;
            }

            var robots = Robot.EnumerateRobots();
            if (robots.Length == 0)
            {
                Console.WriteLine("EnumerateRobots: no robots found on the network");
                Environment.Exit(1);
            }

            Console.WriteLine(
                "Found {0} robot(s); connecting to {1} (session_id={2})",
                robots.Length,
                robots[0].ServerIp,
                robots[0].SessionId);
            CheckResult(robot.Connect(robots[0]), "connect");
        }

        public static void EnableAllArmJoints(Robot robot)
        {
            CheckResult(robot.EnableArmJoint(robot.AllEnabledMask()), "enable_arm_joint");
        }
    }
}
