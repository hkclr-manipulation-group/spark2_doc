#include "example_common.h"

#include <cstdlib>
#include <iostream>
#include <string>

using namespace robot;
using namespace robot_example;

namespace {

void printDiscoveredRobots(const std::vector<DiscoveredRobot>& robots){
    std::cout << "Found " << robots.size() << " robot(s):\n";
    for (std::size_t i = 0; i < robots.size(); ++i){
        const DiscoveredRobot& entry = robots[i];
        std::cout << "  [" << i << "] " << entry.toString() << "\n";
        std::cout << "      handshake_rtt_ms="
                  << (entry.handshake_rtt_us / 1000.0) << "\n";
    }
}

bool parseConnectFlag(int argc, char* argv[], int& connect_index){
    connect_index = 0;
    for (int i = 1; i < argc; ++i){
        if (std::strcmp(argv[i], "--connect") == 0){
            if (i + 1 < argc){
                connect_index = std::atoi(argv[i + 1]);
                if (connect_index < 0){
                    connect_index = 0;
                }
            }
            return true;
        }
    }
    return false;
}

}  // namespace

int main(int argc, char* argv[]){
    std::cout << "Probe the LAN for rt_control servers (enumerateRobots).\n\n";

    const std::vector<DiscoveredRobot> robots = enumerateRobots();
    if (robots.empty()){
        std::cerr << "No robots found.\n"
                  << "Tips:\n"
                  << "  - Ensure cuarm_rt_control is running and reachable on the same subnet.\n"
                  << "  - WiFi may block broadcast/multicast; SDK falls back to unicast subnet sweep.\n"
                  << "  - If search still fails, connect by IP: connection_options / move_point with IP arg.\n";
        return 1;
    }

    printDiscoveredRobots(robots);

    int connect_index = 0;
    if (!parseConnectFlag(argc, argv, connect_index)){
        std::cout << "\nSearch complete. Pass --connect [index] to verify connect() on a listed robot.\n";
        return 0;
    }

    if (static_cast<std::size_t>(connect_index) >= robots.size()){
        std::cerr << "Index " << connect_index << " out of range (0.."
                  << (robots.size() - 1) << ").\n";
        return 1;
    }

    const DiscoveredRobot& chosen = robots[static_cast<std::size_t>(connect_index)];
    std::cout << "\nConnecting to [" << connect_index << "] " << chosen.server_ip << " ...\n";

    Robot robot;
    ROBOT_CHECK(robot.connect(chosen), "connect");
    std::cout << "Connected. robot_name=" << robot.robotName() << "\n";
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
