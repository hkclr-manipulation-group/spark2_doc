#include "robot_sdk.h"
#include "example_common.h"

#include <iostream>
#include <thread>
#include <chrono>

using namespace robot;
using namespace robot_example;

namespace {

void printArmPosSoftLimits(const char* title, const JointLimitValues& limits) {
    std::cout << title << " (deg):\n";
    for (std::size_t i = 0; i < limits.size(); ++i) {
        std::cout << "  joint " << i << ": [" << limits[i].min << ", " << limits[i].max << "]\n";
    }
}

void printArmVelSoftLimits(const char* title, const JointLimitValues& limits) {
    std::cout << title << " (deg/s, symmetric):\n";
    for (std::size_t i = 0; i < limits.size(); ++i) {
        std::cout << "  joint " << i << ": ±" << limits[i].max << "\n";
    }
}

}  // namespace

int main(int argc, char *argv[]){
    std::cout << "Writes tool offset and soft limits to RT (may persist to runtime_config.json).\n"
              << "Use on a test robot or restore values manually after the demo.\n\n";

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    std::cout << "Connected, arm joints: " << robot.jointCount() << std::endl;

    Configurator& configurator = robot.getConfigurator();

    //------------------------- Tool offset (optional) -------------------------
    Position tool_offset = configurator.getToolOffset();
    std::cout << "Tool offset before (m): " << tool_offset.x << ", " << tool_offset.y << ", "
              << tool_offset.z << "\n";
    ROBOT_CHECK(configurator.setToolOffset({0.01f, 0.02f, 0.03f}), "setToolOffset");
    std::this_thread::sleep_for(std::chrono::milliseconds(500));
    tool_offset = configurator.getToolOffset();
    std::cout << "Tool offset after  (m): " << tool_offset.x << ", " << tool_offset.y << ", "
              << tool_offset.z << "\n";
    std::cout << "--------------------------------------------------------\n";

    //------------------------- Arm soft position limits -----------------------
    const int joint_count = robot.jointCount();
    JointLimitValues pos_before = configurator.getArmPosLimits();
    printArmPosSoftLimits("Soft position limits before", pos_before);

    JointLimitValues pos_new = pos_before;
    if (pos_new.size() > 0) {
        // Demo: narrow joint 0 range by 1 deg on each side (stay inside current limits).
        pos_new[0].min += 1.f;
        pos_new[0].max -= 1.f;
    }
    ROBOT_CHECK(configurator.setArmPosLimits(pos_new), "setArmPosLimits");
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    JointLimitValues pos_after = configurator.getArmPosLimits();
    printArmPosSoftLimits("Soft position limits after", pos_after);
    std::cout << "--------------------------------------------------------\n";

    //------------------------- Arm soft velocity limits -----------------------
    JointLimitValues vel_before = configurator.getArmVelLimits();
    printArmVelSoftLimits("Soft velocity limits before", vel_before);

    JointLimitValues vel_new = vel_before;
    if (vel_new.size() > 0) {
        // Demo: cap joint 0 soft speed to 250 deg/s (API uses symmetric ±max).
        vel_new[0].min = -250.f;
        vel_new[0].max = 250.f;
    }
    ROBOT_CHECK(configurator.setArmVelLimits(vel_new), "setArmVelLimits");
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    JointLimitValues vel_after = configurator.getArmVelLimits();
    printArmVelSoftLimits("Soft velocity limits after", vel_after);
    std::cout << "--------------------------------------------------------\n";

    // Hard limits (read-only from RT bootstrap / config)
    printArmPosSoftLimits("Hard position limits (read-only)", configurator.getArmMaxPos());
    printArmVelSoftLimits("Hard velocity limits (read-only)", configurator.getArmMaxVel());
    std::cout << "--------------------------------------------------------\n";

    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
