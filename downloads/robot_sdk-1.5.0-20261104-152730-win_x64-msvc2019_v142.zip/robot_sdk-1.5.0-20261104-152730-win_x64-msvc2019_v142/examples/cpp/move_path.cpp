#include "robot_sdk.h"
#include "example_common.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

int main(int argc, char *argv[]){ 
    setLogLevel(LogLevel::kInfo);
    setLogToStderr(true);

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");
    std::cout << "Arm started" << std::endl;

    const float print_dt = 0.3f;
    const float timeout = 50.f;
    std::string prefix_text;
    Pose current_pose, target_pose;
    JointState current_joint_pos;

    const float t = 3.f;
    const JointValues joint_target = {10.f, 20.f, 30.f, 40.f, 50.f, 60.f};
    
    prefix_text = "==> movePos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n";
    ROBOT_CHECK(robot.movePos(joint_target, 0, t), "movePos");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text, joint_target),
                "wait after movePos");

    prefix_text = "==> Move Tool Line\n";
    target_pose = current_pose;
    target_pose.position.z -= 0.05f;
    target_pose.position.y -= 0.1f;
    Path<Pose> path1 = {target_pose, current_pose};
    Path<int> v1 = {30, 30};
    ROBOT_CHECK(robot.moveToolLinePath(path1, v1, {}), "moveToolLinePath");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after moveToolLinePath");

    prefix_text = "==> movePos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n";
    ROBOT_CHECK(robot.movePos(joint_target, 0, t), "movePos");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text, joint_target),
                "wait after movePos");

    prefix_text = "==> Move Tool Point\n";
    target_pose = current_pose;
    target_pose.position.z -= 0.05f;
    target_pose.position.y += 0.1f;
    target_pose.position.x -= 0.2f;
    Path<Pose> path2 = {target_pose, current_pose};
    Path<float> t2 = {t, t};
    ROBOT_CHECK(robot.moveToolPointPath(path2, {}, t2), "moveToolPointPath");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after moveToolPointPath");

    prefix_text = "==> Move Joint Pos\n";
    Path<JointValues> path3 = {
        {-10.0, -20.0, -30.0, -10.0, -10.0, -10.0},
        {0.0, 0.0, 0.0, 0.0, 0.0, 0.0}
    };
    Path<float> t3 = {t, t};
    ROBOT_CHECK(robot.movePosPath(path3, {}, t3), "movePosPath");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text, path3.back()),
                "wait after movePosPath");

    std::cout << "Motion completed" << std::endl;
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
