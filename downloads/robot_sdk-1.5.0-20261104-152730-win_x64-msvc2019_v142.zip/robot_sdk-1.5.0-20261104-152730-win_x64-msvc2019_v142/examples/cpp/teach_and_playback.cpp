#include "robot_sdk.h"
#include "example_common.h"

#include <iostream>

#if defined(_WIN32)
    #include <conio.h>
#else
    #include <termios.h>
    #include <unistd.h>
#endif

using namespace robot;
using namespace robot_example;

int waitForKeyPress() {
#if defined(_WIN32)
    return _getch(); 
#else
    struct termios oldt, newt;
    int ch;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);          
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt); 
    return ch;
#endif
}

int main(int argc, char *argv[]){ 
    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");
    std::cout << "Arm started" << std::endl;

    const float print_dt = 0.3f;
    const float timeout = 50.f;
    std::string prefix_text;
    JointState current_joint_pos;

    std::cout << "Press any key to START TEACH...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.startTeach(), "startTeach");

    std::cout << "Press any key to STOP RECORDING (drag remains enabled)...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.stopRecording(), "stopRecording");

    std::cout << "Press any key to END TEACH and HOLD the current position...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.stopTeach(), "stopTeach");

    // Optional second argument: client-side JSON output path. Requires Teach RPC on RT.
    if (argc > 2) ROBOT_CHECK(robot.saveTrajectory(argv[2]), "saveTrajectory");

    std::cout << "Press any key to MOVE TO INITIAL POSITION of playback...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.resetPlayback(), "resetPlayback");
    prefix_text = "==> Go to initial position of playback.\n";
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, nullptr, prefix_text),
                "wait after resetPlayback");

    std::cout << "Press any key to START REPLAY...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.startPlayback(), "startPlayback");
    prefix_text = "==> Playback\n";
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, nullptr, prefix_text),
                "wait after startPlayback");

    std::cout << "Press any key to STOP REPLAY...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.stopPlayback(), "stopPlayback");

    std::cout << "Press any key to GO HOME...\n";
    waitForKeyPress();
    ROBOT_CHECK(robot.goHome(30, 0), "goHome");
    prefix_text = "==> Go home.\n";
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, nullptr, prefix_text),
                "wait after goHome");

    std::cout << "Motion completed" << std::endl;
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
