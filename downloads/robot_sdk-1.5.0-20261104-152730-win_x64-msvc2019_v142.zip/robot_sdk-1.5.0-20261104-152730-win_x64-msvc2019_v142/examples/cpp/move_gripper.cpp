#include "robot_sdk.h"
#include "example_common.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

namespace {

void printGripperState(const Robot& robot, const char* title) {
    const JointState state = robot.getJointState();
    std::cout << title << " gripper joints: ";
    if (state.gripper.size() == 0) {
        std::cout << "(none)\n";
        return;
    }
    for (std::size_t i = 0; i < state.gripper.size(); ++i) {
        std::cout << state.gripper[i] << (i + 1 < state.gripper.size() ? " " : "");
    }
    std::cout << "\n";
}

void printLimits(const char* title, const JointLimitValues& limits) {
    std::cout << title << ":\n";
    for (std::size_t i = 0; i < limits.size(); ++i) {
        std::cout << "  joint " << i << ": [" << limits[i].min << ", " << limits[i].max << "]\n";
    }
}

void printCommand(const char* title, const JointValues& pos) {
    std::cout << title << ": ";
    for (std::size_t i = 0; i < pos.size(); ++i) {
        std::cout << pos[i] << (i + 1 < pos.size() ? " " : "");
    }
    std::cout << "\n";
}

/** Panel gripper command space is [0, 1] (0=open, 1=close), not safety soft limits. */
JointValues gripperPanelPos(int dof, float panel_value) {
    return makeJointValues(dof, panel_value);
}

}  // namespace

int main(int argc, char* argv[]) {
    std::cout << "Demonstrates moveGripperPosAndWait (open / close).\n"
              << "Requires a robot with gripper_count() > 0.\n"
              << "Gripper commands/feedback use panel units [0, 1]:\n"
              << "  0 = open, 1 = close (same as getJointState().gripper).\n"
              << "Safety soft/hard limits from the configurator are motor units\n"
              << "(e.g. degrees) and must not be used as moveGripperPos targets.\n\n";

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");

    const int gripper_slots = robot.gripperCount();
    const int gripper_dof = robot.gripperJointCount();
    std::cout << "Topology: arm_count=" << robot.armCount()
              << " gripper_count=" << gripper_slots
              << " gripper_joint_count=" << gripper_dof << "\n";
    if (gripper_slots <= 0 || gripper_dof <= 0) {
        std::cerr << "No gripper on this robot; nothing to demo.\n";
        ROBOT_CHECK(robot.disconnect(), "disconnect");
        return 1;
    }

    Configurator& cfg = robot.getConfigurator();
    printLimits("Gripper soft limits (safety, not command units)", cfg.getGripperPosLimits());
    printLimits("Gripper hard limits (safety, not command units)", cfg.getGripperMaxPos());

    const int v = 30;
    const float timeout_sec = 30.f;
    const float poll_interval_sec = 0.1f;
    // Panel space: keep a margin from the endpoints so both moves are visible.
    const JointValues open_pos = gripperPanelPos(gripper_dof, 0.1f);
    const JointValues close_pos = gripperPanelPos(gripper_dof, 0.9f);

    printGripperState(robot, "Current");
    printCommand("Open command (panel)", open_pos);
    printCommand("Close command (panel)", close_pos);

    std::cout << "\n==> moveGripperPosAndWait (open)\n";
    ROBOT_CHECK(
        robot.moveGripperPosAndWait(open_pos, v, 0.f, timeout_sec, poll_interval_sec),
        "moveGripperPosAndWait(open)");
    printGripperState(robot, "After open");

    std::cout << "\n==> moveGripperPosAndWait (close)\n";
    ROBOT_CHECK(
        robot.moveGripperPosAndWait(close_pos, v, 0.f, timeout_sec, poll_interval_sec),
        "moveGripperPosAndWait(close)");
    printGripperState(robot, "After close");

    ROBOT_CHECK(robot.disconnect(), "disconnect");
    std::cout << "\nGripper demo completed.\n";
    return 0;
}
