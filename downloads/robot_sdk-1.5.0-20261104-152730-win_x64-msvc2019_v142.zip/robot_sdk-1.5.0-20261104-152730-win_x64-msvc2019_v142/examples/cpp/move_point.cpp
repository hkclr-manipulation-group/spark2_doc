#include "robot_sdk.h"
#include "example_common.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

int main(int argc, char *argv[]){ 
    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");
    std::cout << "Arm started" << std::endl;

    const int v = 30;
    const float t = 5.f;
    const float print_dt = 0.3f;
    const float timeout = 50.f;
    std::string prefix_text;
    Pose current_pose, target_pose;
    JointState current_joint_pos;
    
    prefix_text = "==> movePos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n";
    ROBOT_CHECK(robot.movePos({10.0, 20.0, 30.0, 40.0, 50.0, 60.0}, v, 0.f), "movePos");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after movePos");

    target_pose = current_pose;
    target_pose.position.z -= 0.05f;
    target_pose.position.y -= 0.1f;
    prefix_text = "==> moveToolPoint\n";
    ROBOT_CHECK(robot.moveToolPoint(target_pose, v, 0.f), "moveToolPoint");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after moveToolPoint");

    prefix_text = "==> movePos (10.0, 20.0, 30.0, 40.0, 50.0, 60.0)\n";
    ROBOT_CHECK(robot.movePos({10.0, 20.0, 30.0, 40.0, 50.0, 60.0}, v, 0.f), "movePos");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after movePos");
    
    target_pose = current_pose;
    target_pose.position.z -= 0.05f;
    target_pose.position.y += 0.1f;
    prefix_text = "==> moveToolLine\n";
    ROBOT_CHECK(robot.moveToolLine(target_pose, v, 0.f), "moveToolLine");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after moveToolLine");

    prefix_text = "==> Go to home position\n";
    ROBOT_CHECK(robot.goHome(20, t), "goHome");
    ROBOT_CHECK_BOOL(printMotionFeedback(robot, print_dt, timeout, &current_joint_pos, &current_pose, prefix_text),
                "wait after goHome");
    
    std::cout << "Motion completed" << std::endl;
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
