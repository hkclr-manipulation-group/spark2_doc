#include "robot_sdk.h"
#include "example_common.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

int main(int argc, char* argv[]){
    setLogLevel(LogLevel::kInfo);
    setLogToStderr(true);

    std::cout << "Demonstrates foldArm: move directly to built-in fold posture.\n\n";

    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    ROBOT_CHECK(enableAllArmJoints(robot), "enableArmJoint");

    const int v = 30;
    const float t = 5.f;
    const float timeout_sec = 20.f;
    const float poll_interval_sec = 0.1f;

    std::cout << "\n==> moveAndWait + foldArm\n";
    ROBOT_CHECK(robot.moveAndWait(
        [&]() { return robot.foldArm(v, t); },
        timeout_sec, poll_interval_sec), "moveAndWait(foldArm)");

    ROBOT_CHECK(
        robot.movePosAndWait({10.0, 10.0, 10.0, 10.0, 10.0, 10.0}, v, 0.f),
        "movePosAndWait");

    std::cout << "\n==> foldArmAndWait\n";
    ROBOT_CHECK(robot.foldArmAndWait(v, t, timeout_sec, poll_interval_sec), "foldArmAndWait");

    std::cout << "\n==> movePosAndWait (leave fold)\n";
    ROBOT_CHECK(
        robot.movePosAndWait({10.0, 10.0, 10.0, 10.0, 10.0, 10.0}, v, 0.f),
        "movePosAndWait");

    const JointState state = robot.getJointState();
    std::cout << "Final joint position (deg): ";
    for (std::size_t i = 0; i < state.arm.size(); ++i){
        std::cout << state.arm[i] << " ";
    }
    std::cout << "\n";


    // go home
    std::cout << "\n==> movePosAndWait (go home)\n";
    ROBOT_CHECK(robot.movePosAndWait({0.0, 0.0, 0.0, 0.0, 0.0, 0.0}, v, 0.f), "movePosAndWait");
    
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    std::cout << "Fold motion completed.\n";
    return 0;
}
