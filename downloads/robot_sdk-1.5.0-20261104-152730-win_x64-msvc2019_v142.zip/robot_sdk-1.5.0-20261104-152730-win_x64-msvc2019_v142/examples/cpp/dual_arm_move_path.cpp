/**
 * Synchronized dual-arm path motions (public SDK).
 *
 * Ported from dual_arm_sdk/cpp/examples/move_path.cpp.
 * Requires a robot with arm_count >= 2.
 */

#include "example_common.h"
#include "robot_sdk.h"

#include <iostream>

using namespace robot;
using namespace robot_example;

namespace {

JointValues makeJointWaypoint(const Arm& arm, float j4_deg) {
    JointValues target = arm.zeroJoints();
    if (target.size() > 3) {
        target[3] = j4_deg;
    }
    if (target.size() > 4) target[4] = 5.f;
    if (target.size() > 5) target[5] = 5.f;
    if (target.size() > 6) {
        target[6] = 5.f;
    }
    return target;
}

}  // namespace

int main(int argc, char* argv[]) {
    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");

    if (robot.armCount() < 2) {
        std::cerr << "This example requires a dual-arm robot (arm_count >= 2).\n";
        return 1;
    }

    ROBOT_CHECK(
        robot.dualArm().enableArmJoint(robot.arm(0).allEnabledMask(), robot.arm(1).allEnabledMask()),
        "enableArmJoint both");

    const int v = 30;
    const float t = 0.f; // Speed mode: v remains the active speed limit.
    DualArm both = robot.dualArm();

    Path<JointValues> left_path{
        makeJointWaypoint(robot.arm(0), 30.f),
        makeJointWaypoint(robot.arm(0), 45.f),
    };
    Path<JointValues> right_path{
        makeJointWaypoint(robot.arm(1), 30.f),
        makeJointWaypoint(robot.arm(1), 45.f),
    };
    Path<int> speeds{ v, v };
    Path<float> durations{ t, t };

    std::cout << "==> movePosPath both arms (2 waypoints)\n";
    ROBOT_CHECK(
        both.movePosPathAndWait(left_path, right_path, speeds, durations),
        "dual_arm.movePosPathAndWait");

    Pose tool_left{};
    tool_left.position = {0.363605f, 0.760355f, 1.33114f};
    tool_left.orientation = {0.680006f, -0.645236f, -0.200654f, 0.284605f};
    Pose tool_right{};
    tool_right.position = {0.363605f, -0.760355f, 1.33114f};
    tool_right.orientation = {0.645234f, -0.680031f, 0.284588f, -0.200598f};

    Path<Pose> left_tool_path{ tool_left, tool_left };
    Path<Pose> right_tool_path{ tool_right, tool_right };

    std::cout << "==> moveToolLinePath both arms\n";
    ROBOT_CHECK(
        both.moveToolLinePathAndWait(left_tool_path, right_tool_path, speeds, durations),
        "dual_arm.moveToolLinePathAndWait");

    std::cout << "==> goHome both arms\n";
    ROBOT_CHECK(both.goHomeAndWait(MotionOptions::speedLimited(20)), "dual_arm.goHomeAndWait");

    std::cout << "Path motion completed\n";
    ROBOT_CHECK(robot.disconnect(), "disconnect");
    return 0;
}
