# Position move timing

This behavior requires the matching rt_control planner changes. The wire layout is unchanged, but legacy servers use different timing rules.

- `t=0`: speed mode. SDK `v` is a percentage in `(0,100]`, normalized to `(0,1]` on the wire. Default `v=50` means half of the configured soft velocity limit. The planner selects a feasible duration using its motion limits.
- `t>0`: time mode. `t` is the expected duration of this move in seconds. SDK sends ratio `1`, independently of the valid `v` argument. `movePos(q,t=5)` and `movePos(q,v=100,t=5)` request the same trajectory. Motion limits remain active; planning may extend the duration but must never shorten it.
- Path `t[i]` belongs to segment `i`, not to the entire path. Empty `t` selects speed mode for every segment. Empty `v` uses 50 percent for speed segments. Nonempty timing arrays must exactly match the nonempty path. Mixed speed/time segments are supported.
- NaN, infinity, negative duration, and zero speed in speed mode are rejected. Ordinary commands do not rewrite server motion defaults.
- A new command owns a new timing budget, including a repeated destination. Resending the same request continues the current trajectory. Ordinary position moves configured with LowPass use a finite cosine profile; jog retains its filter behavior. Joint-position `ControlStream` ticks use the same finite move contract as `CommandFrame`, including LowPass-to-Cos conversion.

Actual arrival and settling can take longer than the planned duration. `waitUntilIdle` timeouts remain independent and should cover motion plus settling. Cartesian lines use geometry-based IK samples to estimate joint velocity/acceleration and extend/revalidate the task timeline. Mixed line paths use the tightest speed cap conservatively. This discrete check is not a proof of continuous joint-space bounds; existing execution safety limits remain active. Oversized validation workloads or infeasible plans are rejected. New-plan work still runs on the control thread and has no proven worst-case execution time.

Deploy the SDK and server changes together: old scripts relying on `t=0` using the configured default duration may run faster with speed mode. Velocity ramps, jog, stop/recovery, teaching, and grippers retain their separate interfaces.
