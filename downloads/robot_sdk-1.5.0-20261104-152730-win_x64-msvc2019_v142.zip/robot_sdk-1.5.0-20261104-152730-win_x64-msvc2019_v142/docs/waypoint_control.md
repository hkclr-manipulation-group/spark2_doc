# Waypoint control

Path APIs (`movePosPath`, Cartesian path APIs, and `CommandFrame::jointPath`)
automatically select `QuinticPath`. Applications do not need to change smoothing
before sending a path. Single-point APIs restore the per-arm smoothing preference;
if the connection inherited path mode and has no point-filter preference, they use
`Cos`.

A path call waits for the configuration response and the command acceptance ACK.
It does not wait for the motion to finish. Use the existing `AndWait` APIs or motion
completion events to wait for completion. A rejected or timed-out ACK returns a
failure; after a command ACK timeout, acceptance is uncertain, so inspect robot
state before issuing another motion.

The SDK checks that the configuration response matches the requested strategy,
target type, actuator mode, and smoothing. A mismatch returns `kConfigAckFailed`
and prevents the motion command from being sent. Failed mode changes restore the
local configuration cache so a subsequent call retries configuration.

`robot_client` already checks the result of `movePosPath` before starting its motion
wait. Rebuild it with the updated diagnostic headers and deploy the updated SDK DLL
so the client reports command/configuration failures and uses the corrected fault
bits.

Offline regressions are in `scripts/tests`; hardware validation should exercise a
five-point path from LowPassFilter mode, a single-point move immediately afterward,
and another path, checking RT configuration and command ACK logs.
