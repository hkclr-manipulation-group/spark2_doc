# SDK / RT 可扩展通信协议方案

## 决策与本次交付边界

不引入 FlatBuffers、Protobuf 或新的第三方依赖。内部继续使用 C++ DTO，线上采用显式小端编解码、稳定信封、带长度的 TLV 与能力协商。

**运动命令、实时目标、控制心跳和高频状态始终使用 UDP。TCP RPC 只用于维护、能力/拓扑查询、配置及其他慢速服务。不得通过新增 RPC 绕过 UDP 控制权、时序和安全检查。**

协议优化只发生在 SDK/RT 通信层。公开 `Robot / Arm / DualArm`、Python、C 和 CLR 接口保持既有范围；新增协议查询和显式 V2 UDP 操作仅放入 `robot::internal::Robot` / `robot_sdk.internal`。旧 UDP 布局、TCP v3 外层帧和控制权规则保留，既有运动入口不自动切换传输。

`internal::ProtocolInfo.major == 2` 表示支持新描述 schema；`motion_major` 是最高支持的运动版本，不表示已选通道。阶段二的显式 V2 UDP 单点关节组及生命周期已接入，范围和验证见 [V2 UDP 说明](udp_motion_v2.md)。原有公开运动调用继续走 Legacy UDP，头、腰和底盘仍需各自实现后才能声明能力。

## 分层

```text
公共 Robot / Arm / DualArm / 将来的 Head、Waist、Base
                    |
             SDK 内部强类型 DTO
                    |
         Legacy 编解码器 / V2 编解码器
           |                      |
     UDP 运动与实时状态       TCP v3 慢速服务
           |                      |
         RT 准入 / 部件适配层 / 内部有界命令
                    |
                  控制器
```

V2 编码器不使用 `sizeof(struct)`、原生枚举布局或指针作为线上格式。字段编号、服务号、消息号发布后永久保留；删除功能使用弃用标记，不复用编号。不通过调大 Legacy `MAX_ARM_SIZE` 等宏改变已发布格式。

## 已实现的服务

沿用现有 TCP v3 会话认证与 RPC 外层：`ServiceId = 9`（Protocol），`Method = 1`（Describe）。

1. SDK 内部通过 `internal::Robot::getProtocolInfo()` 显式查询；`connect()` 和运动函数不隐式调用它。
2. SDK 先读取现有 `System.GetCapabilities`。
3. 服务清单明确不包含 `9/1`，或旧 System 能力接口明确返回 404/501：无必需能力时返回成功且 `major=1`、部件列表为空。
4. 服务存在：发送 Hello，RT 在同一响应中返回协商结果和拓扑快照。
5. TCP 连接失败、超时、损坏响应、认证失败都返回错误，不能假装得到 Legacy 结果。
6. 已声明 `9/1` 又返回 404，属于服务器不一致，返回错误而非降级。
7. 调用方要求能力而旧 RT 无法满足时返回 Unsupported。

查询需要存活的已认证 UDP 会话，但不要求获取运动控制权。身份只能来自现有 TCP 外层认证。RT 在控制线程重新检查会话并读取短拓扑快照；TLV 解码与响应编码在 TCP 线程执行。队列满、停机和快照不可用返回服务错误。跨线程快照使用受管理的所有权，超时后任务不能引用栈对象。

SDK 不缓存查询结果，调用失败不覆盖 C++ 调用方之前的输出。`timeout_sec` 为每个 RPC 的超时预算，能力查询和 Describe 最多各一次，TCP 首次连接还有既有独立连接预算。客户端应串行使用同一 Robot 的阻塞 TCP/会话接口。

## 信封：32 字节

所有整数是无符号、固定宽度、小端。此信封是 TCP RPC 的消息体，不是替换 TCP v3 的帧头，也不是目前的 UDP 信封。

| 偏移 | 字节 | 字段 | 当前值/含义 |
|---:|---:|---|---|
| 0 | 4 | magic | 字节 `53 52 50 32`，ASCII SRP2 |
| 4 | 2 | major | 2 |
| 6 | 2 | minor | 0，后续允许仅增加可选字段 |
| 8 | 2 | kind | 1=Hello，2=Profile |
| 10 | 2 | flags | 0，未知位拒绝 |
| 12 | 4 | header_size | 32 |
| 16 | 4 | payload_size | 必须严格等于实际剩余长度 |
| 20 | 8 | request_id | 非零；响应原样回显 |
| 28 | 4 | reserved | 必须为 0 |

信封主版本改变表示不兼容。新增 minor 必须保持已存在字段语义，旧解码器可以跳过新可选字段；新必需字段仍导致拒绝。未来要扩展固定头或改变鉴权封装，应建立新主版本，不能依赖旧解码器猜测。

## TLV

每条记录为 `tag:u16 + flags:u16 + length:u32 + value[length]`。`flags.bit0=critical`，其他位保留并拒绝。`tag=0` 非法。

- 未知且非 critical：按长度跳过。
- 未知且 critical：拒绝整条消息。
- 已知必需字段缺失、单值字段重复、长度不匹配：拒绝。
- 部件记录允许重复 tag，但 ID 和稳定名称均必须唯一。
- 不接受尾部垃圾、越界长度、整数溢出导致的长度绕过或超过数量限制的记录。
- 解码到临时 DTO，完整验证后才替换输出，失败不能留下半份拓扑。

### Hello 字段

| tag | 内容 | 必需 |
|---:|---|---|
| 1 | min_major:u16、max_major:u16、max_minor:u16、reserved:u16=0 | 是 |
| 2 | required_features:u64 | 是 |

当前仅支持描述 major 2；minor 选择本地与对方共同支持的值。请求中的 required_features 必须全部满足，不能通过丢弃位实现“成功”。

### Profile 字段

| tag | 内容 | 必需 |
|---:|---|---|
| 10 | major:u16、minor:u16、motion_major:u16、reserved:u16=0 | 是 |
| 11 | features:u64 | 是 |
| 12 | max_message:u32、max_components:u16、max_joints:u16 | 是 |
| 13 | boot_high:u64、boot_low:u64 | 是 |
| 14 | topology_revision:u64 | 是 |
| 20 | 一个部件的嵌套 TLV | 可重复 |

`boot_high/low` 沿用 RT 本次启动的身份，两者不能都为零。拓扑版本为部件规范编码的 FNV-1a 64 位指纹，**是 opaque token，不是递增计数，也不是安全哈希**；与 boot identity 一起使用，用于检测变化，不作为认证依据。当前 RT 拓扑来自实际运行部件，重连后必须重新查询，不能跨启动复用数值 ID。

### 部件记录

| tag | 内容 | 必需 |
|---:|---|---|
| 1 | id:u32，非零 | 是 |
| 2 | kind:u16，非零 | 是 |
| 3 | joint_count:u16；底盘等非关节部件可为 0 | 是 |
| 4 | 稳定名称，可打印 ASCII，无空格，1..64 字节 | 是 |
| 5 | command_features:u64，V2 控制能力 | 是 |

kind：1=Arm、2=Gripper、3=Head、4=Waist、5=Base。未知非零 kind 保留数值，允许显示但不能因此执行控制。国际化显示名称应作为独立可选字段增加，稳定名称用于代码和配置。

当前 RT 分配 arm IDs 为 `1+slot`，gripper IDs 为 `0x100+slot`，名称与既有 SDK 拓扑一致；不报告不存在的部件。所有 `command_features=0`，因为本轮不实现 V2 UDP 运动。

### 能力和限制

当前全局能力：bit0=可查询通用拓扑，bit1=可跳过可选 TLV。其他位不声明。描述协议的能力不等于部件控制能力。

实现上限：整条消息 16384 字节、64 个部件、每部件 256 关节、名称 64 字节、每层 256 字段。它们是编解码上限，不是当前机器人硬件能力。将来新的硬限制需双方协商，不能信任对方报告的长度直接分配内存。

主要拒绝码：400=损坏/非法输入，401=会话失效，406=无共同 schema，412=必需能力不满足，413=过大，422=未知必需字段，503=快照/服务不可用。既有 TCP v3 状态编码保持不变。

## 后续 UDP 控制协议设计约束

后续落地应作为独立交付，不能仅增加本文件中的能力常量就视为实现。
阶段二的 SDK 与已写入 RT 的 UDP 接入源码见 [V2 UDP 关节运动](udp_motion_v2.md)。本文件的兼容矩阵描述阶段一，实际能力以服务端声明为准。

1. **独立 UDP magic 与协商入口。** 旧接收器不会将新帧误解为 Legacy；只有双方声明能力后才启动 V2 UDP。
2. **控制报文有界。** 起始数据报预算不超过 1200 字节，最终按实际网络验证并协商。带宽不足时降低字段或订阅频率，不依赖 IP 分片。
3. **明确目标。** 每个记录携带 component_id、command_type、topology/config revision；无共享 union 的隐式解释。未知必需目标整组拒绝。
4. **明确单位与时间。** rad、m、s；坐标系 ID；明确速度模式/指定时长，速度和加速度上限独立；禁止通过 0 值隐式沿用上次运动设置。
5. **逻辑命令生命周期。** 区分 packet_sequence、command_id、operation_id；boot/session 绑定；Accepted 不等于 Succeeded；可观测 Cancelled/Failed/Superseded。
6. **原子组。** 所有部件先准入再同周期提交；同周期提交不等于全身协调规划，只能对支持的同步域作承诺。
7. **有效期和控制权。** 控制租约、流超时、换控制者、重启和拓扑变化必须使旧目标失效。停止/保护逻辑保持独立，不被低频服务排队阻塞。
8. **轨迹数据与执行分离。** 大数据可通过 TCP 上传/校验；实际运动启动、暂停、取消和实时目标仍通过 UDP 控制通道提交，不新增运动 RPC。
9. **状态按组件订阅。** 带采样序号、采样时刻、有效性；低频温度等与高频关节状态分开。不能把缺失值填零后伪装有效。
10. **鉴权与解码。** 网络线程验证身份、整包完整性、防重放与语义，控制线程仅读取有界内部命令；通信格式不能泄漏到规划器接口。

## 迁移与兼容矩阵

| SDK / RT | 行为 |
|---|---|
| 旧 SDK / 新 RT | 原 UDP/TCP 接口原样工作，不要求了解服务 9 |
| 新 SDK / 旧 RT，有 TCP 能力服务 | 显式缺少服务 9 时查询返回 major=1；运动仍使用 Legacy UDP |
| 新 SDK / 无 TCP 的旧 RT | 运动仍可用；显式描述查询报告 TCP 不可用，不把网络失败解释为协商成功 |
| 新 SDK / 新 RT | 内部查询返回描述 major=2、最高运动版本及真实拓扑；公开运动调用维持原行为 |
| 任一端能力不满足或协议损坏 | 返回错误，保留调用方输出；不重发、降级或恢复运动 |

先部署新 RT 再部署新 SDK，或反过来均不要求同时升级；新增描述服务不修改旧流量。C++/Python 查询仅供内部 SDK 使用；所有公开 API 本次均不扩展。

## 内部用法

```cpp
#include <robot_internal.h>
robot::internal::Robot robot;
robot::internal::ProtocolInfo info;
// robot 已完成 connect()。
robot.getProtocolInfo(info).throwIfError();
// 要求一定支持拓扑，不接受 Legacy：
robot.getProtocolInfo(info, robot::internal::ProtocolFeatures::kTopology).throwIfError();
```

```python
from robot_sdk.internal import Robot
robot = Robot()
# robot 已完成 connect()。
result, info = robot.get_protocol_info(required_features=1)
result.raise_for_error()  # 或使用示例中的 check_result(result, ...)
print(info.major, info.motion_major)
```

完整可运行示例：`examples/internal/cpp/protocol_info.cpp`、`examples/internal/python/protocol_info.py`。

## 维护要求与验证

`deps/robot_platform_utils/cpp/include/protocol_v2*.h` 为 SDK 的规范实现，RT 对应副本必须字节一致。协议更改需在两端一起审查；不能通过“仅双方重新编译即可”替代兼容性规范。

- 固定 Hello 字节样本验证字节序和字段编号；不只测试同一编码器的 roundtrip。
- 对每个截断位置、恶意长度、重复字段、未知必需/可选字段、版本、数量上限和确定性随机损坏进行解码检查。
- 真实 TCP 回环测试覆盖当前 SDK 查询、旧服务、未满足能力、错误认证、损坏 Profile、错误 request_id、已声明却返回 404、超时后不降级。
- RT 服务测试验证认证边界和协商响应；部署前在 RT 的实际构建环境完成完整构建，并验证控制周期负载。
- 描述服务本身不改变运动报文。V2 UDP 的独立验证与剩余验收见阶段二说明，不能据此宣称全身控制已完成。
