# Robot SDK C API

Maintenance API boundary: TCP calibration solving, detailed diagnostics/metrics/fault callbacks and fault recovery are internal SDK features. Use the Robot Client UI for these operations. C++ trusted clients include `robot_internal.h` / `tcp_calibration.h` and link `robot::internal_sdk`; Python trusted clients import `robot_sdk.internal`. These entry points are removed from the public C++, Python, C and CLR surfaces. This is a source/API breaking change; rebuild affected consumers. Basic SystemStatus/raw flags, connection state, ordinary state/motion events, known tool offsets and stop commands remain public.

C bindings for the public Robot SDK (`librobot_sdk_c.so`), delegating to the C++ `robot::Robot` API.

## Headers

```c
#include "robot_sdk_c.h"
```

If your release includes offline kinematics:

```c
#include "robot_sdk_c/kinematics.h"
```

## CMake integration

```cmake
find_package(robot_sdk REQUIRED)
target_link_libraries(my_app PRIVATE robot::sdk_c)
target_include_directories(my_app PRIVATE ${robot_sdk_INCLUDE_DIRS})
```

Link `robot::sdk_c` (alias of `robot_sdk_c`). The library loads `librobot_sdk.so` at runtime (`RPATH $ORIGIN` on Linux).

With kinematics (when shipped in your release):

```cmake
target_link_libraries(my_app PRIVATE robot::kinematics_c)
```

## Connection Flow

```c
robot_session* session = robot_session_create();

robot_rt_connection_info info = {"192.168.1.10"};
robot_result result = robot_session_connect_info(session, &info);
if (!robot_result_ok(&result)) {
    fprintf(stderr, "%s: %s\n",
            robot_error_code_to_string(result.code), result.message);
}

/* Or enumerate first */
robot_discovered_robot robots[8];
size_t count = 0;
robot_enumerate_robots(robots, 8, &count);
if (count > 0) {
    robot_session_connect_discovered(session, &robots[0]);
}

robot_session_destroy(session);
```

Use `robot_session_create()` plus `robot_session_connect_info()` / `robot_session_connect_discovered()`. There is no constructor that takes an IP address.

## Connection State

```c
robot_connection_status status;
if (robot_result_ok(&robot_session_get_connection_status(session, &status))) {
    if (!status.connected && status.telemetry_timed_out) {
        /* The watchdog latched: reconnect before sending more commands. */
    }
}
int live = robot_session_is_connected(session);  /* 1 or 0 */
```

Both calls read SDK-owned state only. They never touch the network and never run
the watchdog, so they are safe to poll from a UI thread. A latched
`telemetry_timed_out` stays `1` until the next successful `connect()`.

## Network Configuration

All four calls require a connected session and travel over the command channel.

```c
robot_network_config config;
if (robot_result_ok(&robot_session_get_network_config(session, &config, 5000.f))) {
    printf("eth %s/%d gw %s wifi=%d ssid=%s\n",
           config.eth_ip, config.eth_prefix, config.eth_gateway,
           config.wifi_enable, config.wifi_ssid);
}

/* STA mode; password may be NULL for an open network. */
robot_session_set_wifi(session, "office-ap", "secret", 1, 10000.f);

/* Static IP. The link drops on success: reconnect using the new address. */
robot_session_set_eth_static(session, "192.168.1.20", "255.255.255.0",
                             "192.168.1.1", NULL, 5000.f);

/* Restore factory network settings; also drops the link. */
robot_session_reset_network_config(session, 10000.f);
```

`robot_session_get_network_config()` zero-fills the struct when it fails, so a
caller that ignores the return value cannot read stale addresses. `wifi_password`
comes back empty when the robot masks it. `set_eth_static()` accepts a NULL
netmask (defaults to /24), gateway or DNS.

## Variable-Length Joint Vectors

After `connect()`, joint counts come from the robot:

```c
int dof = robot_session_joint_count(session);
float joints[ROBOT_MAX_JOINTS];
size_t count = 0;
robot_session_zero_joints(session, joints, ROBOT_MAX_JOINTS, &count);
robot_session_move_pos(session, joints, (size_t)dof, 50, 0.f);
```

Pass buffers with length matching `joint_count()` / `gripper_joint_count()`. Undersized buffers return `ROBOT_INVALID_ARGUMENT`.

## Blocking Motion

```c
robot_session_fold_arm(session, 50, 0.f);                    /* fire and forget */
robot_session_fold_arm_and_wait(session, 50, 0.f, 30.f, 0.1f);

float grip[ROBOT_MAX_JOINTS] = {0.8f};
robot_session_move_gripper_pos_and_wait(session, grip, 1, 50, 0.f, 30.f, 0.1f);
```

`move_gripper_pos_and_wait` waits on gripper feedback, not on robot state. RT keeps
`system_state` at `Idle` during gripper-only motion, so
`robot_session_wait_until_idle()` (or `move_and_wait` around
`move_gripper_pos`) returns before the jaws reach the target.

## Path Motion

Joint-space paths use contiguous waypoint storage:

```c
float waypoints[] = {0, 0, 0, 0, 0, 0,   10, 0, 0, 0, 0, 0};
int speeds[] = {50, 50};
robot_joint_path path = {waypoints, 2, (size_t)dof};
robot_session_move_pos_path(session, &path, speeds, NULL);
```

Provide either a velocity path (`v`) or a time path (`t`), not both.

## Dual-Arm Motion

On a dual-arm robot (arm index 0 = left, 1 = right), the `robot_session_dual_arm_*`
calls command both arms in one packet. Size each per-arm vector to
`robot_session_arm_joint_count(session, arm_index)`:

```c
int left_dof  = robot_session_arm_joint_count(session, 0);
int right_dof = robot_session_arm_joint_count(session, 1);
float left[ROBOT_MAX_JOINTS]  = {0};
float right[ROBOT_MAX_JOINTS] = {0};

robot_session_dual_arm_move_pos(session, left, (size_t)left_dof,
                                right, (size_t)right_dof, 50, 0.f);
robot_session_dual_arm_move_pos_and_wait(session, left, (size_t)left_dof,
                                         right, (size_t)right_dof, 50, 0.f, 30.f, 0.1f);
robot_session_dual_arm_go_home_and_wait(session, 50, 0.f, 30.f, 0.1f);
```

The EE/tool point and line variants (`move_ee_point`, `move_ee_line`,
`move_tool_point`, `move_tool_line`) take two `robot_pose` targets. Path variants
take two `robot_joint_path` / `robot_pose_path` with equal `waypoint_count`.

## Event Callbacks

```c
void on_state(robot_robot_state prev, robot_robot_state curr,
              const robot_system_status* status, void* user_data) {
    (void)prev; (void)curr; (void)status; (void)user_data;
}

robot_session_set_on_state_changed(session, on_state, NULL);
```

Callbacks run on the same threads as the C++ SDK:

| Callback | Thread |
|---|---|
| `set_on_state_changed` | SDK event thread (never a transport thread) |
| `set_on_motion_done` | Thread that called `wait_until_idle` / `move_and_wait` |

Handlers for one session are serialized, so a slow handler delays later events but never affects telemetry reception.

`robot_session_disconnect` from a callback is supported: the session is closed immediately, but sockets and threads are released on the next call made from the application thread (or when the session is destroyed). Do not call blocking motion APIs or connect from callbacks.

## Configurator

All configuration APIs use the `robot_session_config_*` prefix and require an active session:

```c
robot_position offset = {0.f, 0.f, 0.1f};
robot_session_config_set_tool_offset(session, &offset);
```


## Kinematics (optional)

```c
robot_kinematics* kin = robot_kinematics_create("/path/to/configuration", "spark2_v2");
float joints[6] = {0};
robot_pose pose;
robot_kinematics_forward_kinematics(kin, joints, 6, &pose);
robot_kinematics_destroy(kin);
```

Requires `librobot_kinematics_c.so` and the `configuration/` directory from your SDK release.

## Logging

```c
robot_set_log_level(ROBOT_LOG_INFO);
robot_set_log_to_file(1);
robot_set_log_to_stderr(1);
```

## Public API Coverage

The C API mirrors the public C++ surface:

- Logging and discovery
- `Robot` session (connection, connection state, motion, feedback, events, metrics)
- Network configuration (`robot_session_*network_config`, `set_wifi`, `set_eth_static`)
- `Configurator` (via `robot_session_config_*`)
- Diagnostics helpers
- `Kinematics` (optional separate library)

Object handles that have no C representation are the only remaining gap:
`Arm` (a per-arm view; the C API takes joint vectors instead), `Configurator` as a
returned object, and the two `connect()` overloads, which appear as
`robot_session_connect_info` / `robot_session_connect_discovered`.
`scripts/check_binding_surface.py` enforces this: adding a method to
`robot::Robot` without a C binding fails the build.

The C API covers the public Robot SDK surface only.

Sample code may ship under `examples/c/` in your SDK release.
