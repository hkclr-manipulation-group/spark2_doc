# V2 UDP 关节运动：阶段二源码接入

SDK 的显式入口、共享编码和 RT 接收/执行链路已接入工作区。2026-11-02 补齐真实服务/仲裁器/规划器离线集成、空闲周期快速路径及待处理过期处理。没有启动生产 RT 或下发真机运动。服务器需要构建并部署相应版本后才能声明新能力，SDK 不会自动改用 V2。
初始审查记录为 [`rt_control_udp_v2.patch`](patches/rt_control_udp_v2.patch)，后续修复记录为 [`rt_control_udp_completion.patch`](patches/rt_control_udp_completion.patch)，两者均已应用，不应在当前工作区重复执行。后续补丁已通过只读反向应用检查；共享文件可用下文脚本核对。

## 传输与范围

- 运动提交和精确操作状态查询都使用 **UDP**，复用 core UDP 端口，以 `SRU2` magic 与 Legacy 分流。
- TCP 仍仅用于协议、拓扑、配置版本等慢速查询，没有运动 RPC。
- 首个运动 schema 只支持**当前所有机械臂组成的单点关节位置组**。不支持省略臂、混合模式、笛卡尔、夹爪、底盘或连续流；不声明对应能力。
- 内部 SDK 的 V2 输入关节角度为 degree，线上固定 IEEE754 float32 rad。定时模式仍独立施加 `velocity_scale`，不会忽略速度上限。
- 复用现有会话 HMAC、心跳、控制仲裁、故障门禁和规划器。没有新增鉴权密钥或第三方依赖。最大签名数据报 1200 字节。
- HMAC 的密钥字节沿用 Legacy 的解释：注册字符串的前 16 字节，不在 V2 中另作十六进制解码。

## 协商与配置约束

描述服务新增可选 TLV 15：`configuration_revision:u64`，老解码器可跳过。新功能使用 capability bit8=UDP joint position、bit9=UDP operation status；支持时 `motion_major=2` 表示最高支持版本，不表示自动切换。臂的 `command_features` 同时声明 bit8。

配置 revision 对控制策略、目标/执行器类型、插补方式、使能及相关软限位进行规范编码后生成指纹，排除 sequence/timestamp 等元数据。拓扑和配置指纹是变化检测 token，不是认证凭证。

调用方先显式查询能力和配置，再提交 V2 运动。首版要求现有配置为每臂 Joint/Position，执行器 Position 或 Velocity，插补 Linear/Cos/Cubic/Quintic。服务器不替调用方修改模式；配置或拓扑变化后应重新查询，旧命令不得被重新解释成速度或力矩。

## 数据报

固定 80 字节小端头，后跟有界消息体和 16 字节现有会话 HMAC。HMAC 覆盖完整头部与消息体。

| 偏移 | 字段 |
|---:|---|
| 0 | magic:u32，字节 SRU2 |
| 4 | version:u16=2、kind:u16（Submit=1 / Query=2 / Status=3） |
| 8 | header_size:u16=80、flags:u16=0 |
| 12 | payload_length:u32 |
| 16 | client:u16、reserved:u16=0 |
| 20 | session:u32、packet_sequence:u32 |
| 28 | command_id:u64 |
| 36 | boot_high:u64、boot_low:u64 |
| 52 | topology_revision:u64 |
| 60 | configuration_revision:u64 |
| 68 | issued_us:u64（RT 同步时钟） |
| 76 | valid_for_ms:u32（1..5000） |

Submit 消息体：

- 必需 TLV 1：timing:u16（0=速度限制，1=定时）、reserved:u16=0、velocity_scale:f32、duration_sec:f32。
- 重复必需 TLV 20：component_id:u32、command_type:u16=1、joint_count:u16、position_rad:f32[joint_count]。
- 速度比例必须在 `(0,1]`。速度模式 duration=0；定时模式 duration>0。所有值必须有限，ID 不重复。
- 未知必需字段、目标类型、部件或不完整臂组整体拒绝，不执行部分目标。

Query 消息体为空。Status 消息体固定 16 字节：phase:u16、reason:u16、execution_sequence:u32、diagnostics:u64。

phase：Received=1、Accepted=2、Running=3、Succeeded=4、Failed=5、Superseded=6、Expired=7、Unknown=8。

reason：None=0、Invalid=1、Unsupported=2、Revision=3、Expired=4、Ownership=5、Fault=6、Capacity=7、Conflict=8、NotFound=9、Planner=10。

## 执行与生命周期

1. 网络线程先验证完整 HMAC、长度、枚举与会话，将请求放入有界逻辑命令账本。
2. Received 只表示已记录。控制线程每周期最多取一个请求，再验证 boot、revision、有效期、所有臂尺寸/软限位及控制模式。
3. 适配器生成一个现有内部关节组命令，经原有 ClientCoordinator 准入；Accepted 不等于开始或完成。
4. 真正进入规划器前再次验证有效期、配置及拓扑。排队期间发生变化必须拒绝。
5. 对应 command/session 的精确执行 sequence 被处理后才能观察 Running/终态。Idle 还必须同时满足所有目标关节误差 ≤1°、速度 ≤1°/s，连续三个控制周期，才记 Succeeded。
6. 故障记 Failed；被其他控制者/新命令替代记 Superseded。原有 UDP stop/safeguard 独立可用。

内部 `SdkCommandReq.internal_v2_command_id` 仅标记本地适配命令，**不进入 Legacy 线上字节**；Legacy 解码显式清零，外部 Legacy 包不能伪造该标记。已失去账本记录的 V2 标记命令按失败处理，不能退回普通 Legacy 执行。

账本容量 64、待处理上限 8、同一客户端会话同时一个未完成操作。终态先入先出淘汰；保留会话级递增逻辑 ID 水位，淘汰后的旧 ID 不能再次执行。支持最多 32 个客户端 ID 的水位槽；同一客户端的新已认证会话会使旧会话的待处理操作失效。
没有未完成操作时，控制周期中的 V2 钩子不获取账本锁，也不构造协议描述。尚未准入的命令也会在认证后的 UDP 提交/查询中清理过期状态，因此暂停控制循环不会让查询永久停留在 Received。已开始运行的动作不受该排队有效期取消。
当前 SDK 从既有递增 sequence 分配逻辑 ID，同一会话不能跨越其 32 位回绕边界；耗尽前须建立新会话，不能从较小 ID 继续提交。

`valid_for_ms` 是排队/开始执行前的有效期，不是运动持续时间，也不是运行后的自动取消时限。网络延迟超过有效期将拒绝动作；控制时钟允许最多 250ms 的未来偏差。

## 内部 SDK 入口

```cpp
#include <robot_internal.h>

robot::internal::Robot robot;
robot::internal::ProtocolInfo protocol;
robot.getProtocolInfo(protocol,
    robot::internal::ProtocolFeatures::kUdpJointPosition |
    robot::internal::ProtocolFeatures::kUdpOperationStatus).throwIfError();

// 每一臂均需给出目标，component_id 与 joint_count 来自刚查询的拓扑。
std::vector<robot::internal::UdpJointTarget> targets = /* 明确的目标角度 */;
robot::internal::UdpMotionOperation operation;
robot::internal::UdpMotionTiming timing{0.2f, 0.f, 1000};
auto result = robot.submitJointMotionV2(protocol, targets, timing, operation);
// 如超时，operation 仍保留 command_id；只能查询该操作，不能当作未执行再次提交。
if (operation.command_id) {
    robot.getJointMotionV2Status(operation).throwIfError();
    // 检查 phase；一次查询尚未终态时，由应用调度后续查询。
}
```

以上类型与方法只随内部 SDK 提供，公开 `Robot / Arm / DualArm` 接口及其传输行为不变。

Python 从 `robot_sdk.internal` 导入 `Robot`、`UdpJointTarget`、`UdpMotionTiming` 等：`result, operation = robot.submit_joint_motion_v2(protocol, targets, timing)`；
`result = robot.get_joint_motion_v2_status(operation)`，后者更新同一个操作对象。

运动调用不会调用 TCP，也不会静默回退 Legacy。UDP 回应必须通过服务端地址/端口、HMAC、会话、boot、command_id、请求 packet_sequence、拓扑与配置 token 的关联检查。SDK 不自动重发提交。

## 验证与启用

SDK 离线测试覆盖固定字节、每处截断、篡改/错误密钥、未知输入、大小约束、定时速度上限、原子适配、Legacy 字节不变、去重/冲突/淘汰和超时保留操作身份。SDK 回环使用模拟对端；另外新增的 RT 离线项目直接编译、链接真实接收服务、CoreUdpServer、ClientCoordinator 和 RobotPlanner，没有链接硬件驱动或生产 RT 主程序。

接口收回内部后，SDK 公共版 CTest **13/13**、内部版 **31/31** 通过；安装包边界、公开 C++ 调用程序和内部示例编译检查通过。此前 RT 离线单臂、双臂、仲裁断连/恢复 **4/4** 通过，描述服务/字节协议 **2/2** 通过；完整 Linux RT 构建与综合回归结果见后文及 WSL 环境记录。

RT 集成覆盖完整签名和会话门禁、真实 UDP 分流与回复源端口、整组准入、重复/冲突请求、排队及执行前过期、配置变化、控制权切换、故障诊断、运行/完成关联，以及空闲 1000 次钩子无堆分配。数值反馈使用位置执行器；极短定时请求仍检查测得速度不超过独立速度上限。
集成还修复了两项启动/平台问题：会话及内部队列统一使用显式 64 位微秒时间，避免 Windows `long` 截断；初始配置响应尚未建立时，旧配置接口安全返回 `RejectedConfigNotReady`，不解引用空指针。相关回归已加入离线测试。

测试模型副本写入构建目录：保留生产模型的关节运动学与惯量，将外部网格替换为小球，并规范化关节名称以避免关节/连杆同名。碰撞检测在测试中关闭。因此这些测试不证明生产网格、碰撞安全或整个硬件控制循环正确。早期 Windows 离线接收器使用 `MSG_DONTWAIT=0` 兼容定义，AppContext 对象检查使用既有 zstd 声明桩；后续 WSL 检查已使用真实 Linux 头文件及系统库完成完整 RT 编译、链接。

### 可复用检查入口

以下命令从 SDK 根目录执行，依赖使用现有工程的 CMake 包，无 FlatBuffers 或新 SDK 运行时依赖：

```powershell
python scripts/check_rt_protocol_sync.py --rt-root ../cuarm_rt_control
cmake -S ../cuarm_rt_control/test/protocol -B build_rt_protocol_v142 -G "Visual Studio 16 2019" -DCMAKE_PREFIX_PATH=C:/Users/liang/work_dir/spark2_deps/install_md -DROBOTICS_STATIC=OFF -DENABLE_COLLISION=ON
cmake --build build_rt_protocol_v142 --config Release --parallel 4
ctest --test-dir build_rt_protocol_v142 -C Release --output-on-failure
```

同步脚本核对 9 个共享文件的完整字节，差异或缺失返回非零退出码；不会自动覆盖文件。离线项目也已注册到 RT 的既有 C++ 测试构建中（存在 planner target 时）。Linux 可使用同一源码入口，去掉 Windows generator，指定实际依赖前缀及 `-DCMAKE_BUILD_TYPE=Release`。

### 尚需目标环境完成

- 完整 Linux RT 和 `test_runtime_shared_state` 已在 WSL 构建。软限位已按用户确认的严格拒绝契约更新旧测试，专项通过；七项选定回归为 6/7。综合测试剩余失败为独立的 `TCP offset not restored` 配置恢复问题，详见 `wsl_rt_environment.md`。
- 使用生产模型和完整网格验证实际机器人配置。上述数值模型替换不能替代这一项。
- 活跃运动、UDP 负载及丢包下的控制周期最坏耗时。活跃 V2 路径仍有账本锁和容器快照，空闲零分配检查不代表硬实时保证。
- 目标环境通过后，再安排独立的真机低速验收。本次未启动生产 RT 或发送真机运动。

此前缺少 `console_bridge` 的环境阻塞已解除：用户指定参考机 `192.168.3.210` 后，已将精选自编译依赖复制并重定位到 WSL 私有前缀，同时安装系统开发包。完整 RT 已在 Ubuntu 22.04 / GCC 11.4 编译链接，动态库解析无缺失项，具体用法和综合测试剩余问题见 [WSL 环境记录](wsl_rt_environment.md)。

V2 当前只完成全臂单点关节位置组。笛卡尔、路径、夹爪及流式接口继续沿用现有 Legacy UDP；头、腰、底盘等新增控制器和对应 V2 schema 属于后续扩展，不声明为已支持。
