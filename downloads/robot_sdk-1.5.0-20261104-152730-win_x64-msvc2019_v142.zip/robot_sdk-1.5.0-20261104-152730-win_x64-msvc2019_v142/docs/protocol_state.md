# 状态帧字段约定

`SrvState.payload.robot_name` 是发送状态帧的机器人名称。
`current_client_id` 与 `payload.session_id` 配对，表示当前控制者及其会话；
没有控制者时两者为零。`session_id` 不是状态帧接收者的会话编号，因此观察者
可以接收另一控制者的状态。

`current_client_sequence_id` 表示本轮控制处理的请求序号，未处理请求时可为零。
`payload.last_processed_seq` 表示当前控制会话最近处理的运动命令序号；
控制者或会话改变时清零。SDK 仅在控制者和会话匹配时用这些字段同步自身序号。

SDK 为旧版 RT 保留空 `robot_name` 和零 `session_id` 的兼容行为；非空机器人
名称必须匹配，自己的客户端编号对应其他非零控制会话时判定控制权已丢失。

RT 的 `SystemState::kOffline` 映射到 SDK 的 `RobotState::kOffline`，C/Python/CLR
接口均提供对应状态。SDK 原有枚举数值不变；该状态下运动等待以硬件离线错误结束。

ACK RTT 使用 SDK 本地单调时钟记录发送到接收的间隔，包含返回路径，
不依赖 RT 的时钟偏移。ACK 中的 RT 时间戳继续用于握手时钟同步。
