# Robot SDK API (Python)

Maintenance API boundary: TCP calibration solving, detailed diagnostics/metrics/fault callbacks and fault recovery are internal SDK features. Use the Robot Client UI for these operations. C++ trusted clients include `robot_internal.h` / `tcp_calibration.h` and link `robot::internal_sdk`; Python trusted clients import `robot_sdk.internal`. These entry points are removed from the public C++, Python, C and CLR surfaces. This is a source/API breaking change; rebuild affected consumers. Basic SystemStatus/raw flags, connection state, ordinary state/motion events, known tool offsets and stop commands remain public.

- **Requirements:** CPython 3.9–3.13
- **Package:** `robot_sdk` (wheel or install tree from your SDK release)

Install the wheel shipped with your SDK release, then import and connect:

```bash
pip install robot_sdk-*.whl
python -c "from robot_sdk import Robot; print(Robot)"
```

```python
from robot_sdk import Robot, RtConnectionInfo, enumerate_robots

robot = Robot()
result = robot.connect(RtConnectionInfo())  # auto-discover RT server on the LAN
if not result.ok:
    raise RuntimeError(f"connect failed: {result.message}")
```

Offline **Kinematics** needs the `configuration/` directory from the same SDK release (URDF and meshes). Pass its path to `Kinematics(...)`; the live **Robot** class does not use it.

---

## Return values and errors

Command-style APIs (`connect`, motion, configuration, teach/playback, …) return `RobotResult` instead of raising on failure.

```python
from robot_sdk import Robot, RobotError, RobotErrorCode, RtConnectionInfo

robot = Robot()
result = robot.connect(RtConnectionInfo())
if not result.ok:
    print(f"connect failed: {result.message} ({result.code.name})")
```

| Still raises | Returns `RobotResult` |
|---|---|
| `ValueError` (invalid jog args) | Connection / motion / config failures |
| `RobotError` on control lost | Jog stream send success (execution still async) |
| Query APIs before start | |

Import helpers: `RobotResult`, `RobotErrorCode`, `RobotError` from `robot_sdk`.

Motion APIs returning success mean the command was sent locally; they do not prove RT admission or successful planning. Use `wait_until_idle()` / `move_and_wait()` to block until execution completes, or poll `get_status()` manually.

With an updated RT, `move_pos_and_wait()` / `wait_until_idle()` return a specific execution rejection immediately after receiving matching telemetry, even if the robot remains Idle. Invalid targets, an out-of-range measured start, and a trajectory crossing a joint limit return `CommandInvalid`; a position-boundary stop returns `MotionInterrupted`. Messages include the command sequence and available arm/joint context (indices start at 0). These are motion errors, not hardware faults requiring recovery.

`MOTION_COMMAND_REJECTED` marks terminal rejection. Decode `TARGET_POS_OUT_OF_RANGE`, `MOTION_START_POS_OUT_OF_RANGE`, `MOTION_PROFILE_POS_OUT_OF_RANGE`, `MOTION_BOUNDARY_BLOCKED`, or `PLAN_INVALID_SETTING` from system/joint diagnostic flags for the cause. RT retains the rejection until a new command, configuration, fault/recovery transition, or control-owner change; waits match client/session/command sequence to ignore stale rejections. Nonblocking motion still returns after sending; inspect status diagnostics or call the wait API for the eventual result. Older RT versions without these flags retain the existing timeout behavior. The UDP state layout is unchanged.

### Thread safety

A single `Robot` instance is **not thread-safe**. Call motion, query, and connection APIs from one application thread (or serialize access with your own lock). Telemetry event handlers run on a dedicated SDK event thread — never on a transport thread — so a slow handler cannot stall telemetry reception or trip the 3 s receive watchdog; handlers for one `Robot` are serialized. `on_motion_done` runs on the thread that called `wait_until_idle()` / `move_and_wait()`.

Blocking calls (`connect`, `disconnect`, `wait_until_idle`, `move_*_and_wait`, motion sends, network configuration) release the GIL, so other Python threads keep running while the SDK waits on the robot. `move_and_wait` is the exception: it invokes the Python callable from C++ and therefore holds the GIL for the duration of the wait.

Calling `disconnect()` / `stop()` from an event callback is supported: the session is closed immediately, but the socket close and thread joins are deferred until the next call made from your application thread (or until the `Robot` is destroyed), because the callback is still running on an SDK thread. Do not call blocking motion APIs or `connect()` from an event callback.

`wait_until_idle()` returns `RobotResult`, but it may still raise `RobotError` with `CONTROL_LOST` if another client takes control while waiting.

---

## Logging

```python
from robot_sdk import LogLevel, set_log_level, set_log_to_file, set_log_to_stderr
from robot_sdk import set_log_handler, enable_python_logging

set_log_level(LogLevel.DEBUG)
set_log_to_file(True)             # writes logs/robot_YYYY-MM-DD.log
set_log_to_stderr(True)           # default True; independent of file
enable_python_logging()           # optional: bridge to logging.getLogger("robot_sdk")
```

---

## Core SDK API (`Robot`)

| API | Description | Group |
|---|---|---|
| `Robot()` | Create SDK client for rt_control networking. | constructor |
| `enumerate_robots()` | Probe the network; return `List[DiscoveredRobot]`. Call before `connect(robot)` / `connect(info)`. | connection |
| `connect(robot \| info)` | Connect via enumerated robot or `RtConnectionInfo` (empty `server_ip` auto-discovers). | connection |
| `disconnect()` / `stop()` | Send session disconnect to RT, then stop heartbeats/transport. `stop()` aliases `disconnect()`. | connection |
| `arm_count()`, `gripper_count()` | Arm / gripper slot counts from RT (0 before `connect()`). | connection |
| `robot_name()` | RT robot identity (empty before `connect()`). | connection |
| `joint_count()`, `gripper_joint_count()`, `joint_names()` | Runtime DOF and names for arm slot 0 (0 / empty before `connect()`). | connection |
| `zero_joints()`, `all_enabled_mask()` | Helpers sized to `joint_count()` / `gripper_joint_count()`. | connection |
| `release_control()` | Release SDK control token; subsequent commands fail until reconnect. | connection |
| `stop_motion(wait_for_command_ack=False)` | Hold at current pose; does not fault the robot. | motion |
| `trigger_safeguard_stop()` | Protective stop (monitoring UDP, Panel abort); enters RT `ERROR`. Not hardware E-stop. | safety |
| `get_network_config(ack_timeout_ms=5000.0)` | Read robot network settings; returns `(RobotResult, NetworkConfig)`. WiFi password is masked. | network |
| `set_wifi(ssid, password, enable=True, ack_timeout_ms=10000.0)` | Connect robot WiFi to a router (STA mode). | network |
| `set_eth_static(eth_ip, eth_netmask, eth_gateway, eth_dns="", ack_timeout_ms=5000.0)` | Set wired static IP (connection drops; reconnect with new IP). | network |
| `reset_network_config(ack_timeout_ms=10000.0)` | Restore factory network settings. | network |
| `enable_arm_joint(arm_state)` | Enable arm slot 0; pass a bool list length `joint_count()`. | connection |
| `wait_until_idle(timeout_sec=30.0, poll_interval_sec=0.1)` | Poll until robot finishes motion or reports failure. | motion completion |
| `move_and_wait(move, timeout_sec=30.0, poll_interval_sec=0.1)` | Run a move callable, then wait until idle. | motion completion |
| `move_pos_and_wait(arm_pos, v=50, t=0.0, ...)` | `move_pos` + `wait_until_idle` (arm slot 0). | motion completion |
| `go_home_and_wait(v=50, t=0.0, ...)` | `go_home` + `wait_until_idle`. | motion completion |
| `set_arm_smoothing_method(method)` | Select smoothing strategy for single-target arm motion. | motion mode |
| `move_pos(arm_pos, v=50, t=0.0)` | Joint-space target for arm slot 0; list length = `joint_count()`. | manual motion |
| `move_pos_path(path, v_path, t_path)` | Joint waypoints for arm slot 0; each list length = `joint_count()`. | manual motion |
| `move_vel(arm_vel, a=10, t=0.0)` | Joint velocity for arm slot 0; list length = `joint_count()`. | manual motion |
| `move_ee_point(pose, v=50, t=0.0)` | Move end-effector to cartesian pose (point mode). | manual motion |
| `move_ee_point_path(path, v_path, t_path)` | Move through end-effector pose waypoints (point mode). | manual motion |
| `move_ee_line(pose, v=50, t=0.0)` | Move end-effector to cartesian pose (line mode, arm slot 0). | manual motion |
| `move_ee_line_path(path, v_path, t_path)` | Move through end-effector pose waypoints (line mode, arm slot 0). | manual motion |
| `move_tool_point(pose, v=50, t=0.0)` | Move tool frame to cartesian pose (point mode). | manual motion |
| `move_tool_point_path(path, v_path, t_path)` | Move tool frame through cartesian waypoints (point mode). | manual motion |
| `move_tool_line(pose, v=50, t=0.0)` | Move tool frame to cartesian pose (line mode). | manual motion |
| `move_tool_line_path(path, v_path, t_path)` | Move tool frame through cartesian waypoints (line mode). | manual motion |
| `go_home(v=50, t=0.0)` | Move robot arm to predefined home pose. | manual motion |
| `move_gripper_pos(pos, v=50, t=0.0)` | Gripper joints in panel units `[0,1]` (`0`=open, `1`=close); list length = `gripper_joint_count()`. | manual motion |
| `move_gripper_pos_and_wait(pos, …)` | `move_gripper_pos` + wait on gripper feedback (RT may stay Idle during gripper-only moves). | motion completion |
| `start_teach(), stop_recording(), stop_teach()` | Start drag/recording; freeze recording while allowing drag; end teaching with position hold. | [teaching lifecycle](teaching_lifecycle.md) |
| `save_trajectory(local_path)` | Export a frozen RT recording to a client-side JSON file; requires a compatible RT. | [teaching lifecycle](teaching_lifecycle.md) |
| `start_playback(), stop_playback(), reset_playback()` | Control playback mode lifecycle. | playback mode |
| `get_joint_state(), get_joint_vel(), get_joint_tor()` | Arm slot 0 joint feedback (runtime-sized vectors). | feedback |
| `joint_positions()` | Arm slot 0 positions only. | feedback |
| `get_ee_pose(), get_tool_pose()` | Arm slot 0 end-effector / tool cartesian pose. | feedback |
| `get_arm_joint_enabled_mask()` | Arm slot 0 enable mask (length `joint_count()`). | status |
| `get_status(), print_status(status)` | Read or print aggregated runtime status (`SystemStatus`). Joint diagnostics are indexed `[arm][joint]`. | status |
| `get_configurator()` | Access RT configuration subsystem for arm slot 0. | subsystems |

A single `Robot` session owns the UDP connection. On dual-arm robots, the convenience methods directly on `Robot` target **arm slot 0**; use public `arm(index)` handles for other arms and `dualArm()` (Python: `dual_arm()`) for synchronized motion. Use `arm_count()` / `gripper_count()` after `connect()` to inspect topology; `wait_until_idle()` waits for the whole robot.


## Configuration (`configuration/`)

See [BREAKING_CONFIG.md](BREAKING_CONFIG.md). The SDK uses the built-in model `spark2_v2`. Runtime limits and modes come from the RT platform after `connect()`.

## RT connection (`RtConnectionInfo`)

Import `RtConnectionInfo` from `robot_sdk`. Only `server_ip` is configurable in the public API; UDP ports use SDK built-in defaults.

| Field | Default |
|---|---|
| `server_ip` | `""` (auto-discover on `connect()`) |

```python
from robot_sdk import Robot, RtConnectionInfo, enumerate_robots

# Auto-discover on the network (default empty server_ip).
robot = Robot()
robot.connect(RtConnectionInfo())

# Known RT host.
robot = Robot()
robot.connect(RtConnectionInfo.to("192.168.1.10"))

# Enumerate, then connect to the first reply.
robot = Robot()
robots = enumerate_robots()
if not robots:
    raise RuntimeError("No robots discovered")
robot.connect(robots[0])
```

Pass connection settings to `connect(info)` or `connect(robot)` when starting a session.

Normal motion methods return after the UDP command is sent; they do not wait for a command ACK. Configuration changes still wait for their ACK. Use the `*_and_wait` methods or `wait_until_idle()` when completion confirmation is required.

## Examples (`examples/python/`)

Public motion examples use shared helpers in `utils.py`:

| Helper | Description |
|---|---|
| `build_robot_ip_parser()` | `argparse` parser with optional positional `[IP]` |
| `get_robot_connection(ip=None)` | Returns `RtConnectionInfo` when `ip` is set, else the first `DiscoveredRobot` |
| `require_first_robot()` | Enumerate and return the first robot (exits if none found) |
| `check_result(result, context)` | Print and exit on failure |

```powershell
cd examples/python
python move_point.py                         # auto-discover first robot
python move_point.py 192.168.1.10            # connect to known RT IP
python network_config.py --ip 192.168.1.10   # use --ip when other CLI flags are present
```

Typical example flow:

```python
from utils import check_result, get_robot_connection, build_robot_ip_parser
from robot_sdk import Robot

args = build_robot_ip_parser().parse_args()
robot = Robot()
check_result(robot.connect(get_robot_connection(args.ip)), "connect")
```

See `connection_options.py` for auto-discover (`RtConnectionInfo()`), fixed IP (`RtConnectionInfo.to(...)`), and enumerate-first (`require_first_robot()`) patterns. Kinematics examples under `calculate_kinematics.py` do not connect to rt_control.

## Configuration API (`Configurator`)

| API | Description |
|---|---|
| `set_tool_offset(offset), set_arm_pos_limits(limit), set_arm_vel_limits(limit), set_gripper_pos_limits(limit)` | Set configuration; return `RobotResult`. |
| `get_tool_offset(), get_arm_pos_limits(), get_arm_vel_limits(), get_gripper_pos_limits()` | Read active configuration values. |
| `get_arm_max_pos(), get_arm_max_vel()` | Get hardware max position/velocity constraints. |
| `get_arm_max_pos_jump(), get_arm_max_vel_jump()` | Get anti-jump protection limits. |
| `get_arm_max_pos_follow_error(), get_arm_max_vel_follow_error(), get_arm_max_tor_follow_error()` | Get following-error thresholds. |
| `set_gripper_pos_limits(limit)` | Set gripper position limits; return `RobotResult`. |
| `get_gripper_max_pos()` | Get gripper hardware max range. |

## Kinematics API (`Kinematics`)

Standalone class — import from `robot_sdk`. Requires a configuration directory with URDF/meshes.

| API | Description |
|---|---|
| `Kinematics(config_prefix_path, model_id="")` | Load built-in model from URDF; optional `model_id` overrides `config.yaml` / default `spark2_v2`. |
| `joint_count()` | Active DOF for the loaded kinematics model. | 
| `forward_kinematics(arm_pos)` | Compute cartesian pose from joint state (length = `joint_count()`). |
| `inverse_kinematics(ee_pose, arm_pos)` | Solve joint state for a target cartesian pose; returns `(RobotResult, sequence[float])`. |
| `euler_to_quaternion(euler)` | Convert intrinsic XYZ Euler angles to quaternion. |
| `quaternion_to_euler(quat)` | Convert quaternion to intrinsic XYZ Euler angles. |
| `ee_to_tool_pose(ee_pose, tool_offset)` | Transform end-effector pose into tool pose. |
| `tool_to_ee_pose(tool_pose, tool_offset)` | Transform tool pose into end-effector pose. |

## Types

Core types (`Pose`, `Position`, `RobotResult`, `RobotState`, `Robot`, …) mirror the public C++ SDK. Motion APIs accept plain Python lists; bound types `JointValues`, `JointLimitValues`, and `JointDiagnosticFlags` are also available.

| Type / Enum | Description |
|---|---|
| `DiscoveredRobot` | Result of `enumerate_robots()` (`server_ip`, `robot_name`, …). |
| `NetworkConfig` | Network settings from `get_network_config()` (`eth_ip`, `wifi_ssid`, …). |
| `Position`, `Quaternion`, `EulerAngle` | Cartesian position, orientation, and intrinsic XYZ Euler angles. |
| `Pose` | Cartesian pose = `Position` + `Quaternion` orientation. |
| `JointValues`, `JointMask`, `JointState` | Variable-length joint vectors, enable masks, and arm+gripper feedback. |
| `JointLimitValues`, `JointDiagnosticFlags` | Variable-length per-joint limit pairs and diagnostic flag vectors. |
| `List[T]` | Waypoint sequence (e.g. `List[Pose]`, `List[float]` for joint paths). |
| `JointLimits` | Per-joint min/max (`min`, `max`). Limit getters return `JointLimitValues`. |
| `make_joint_values`, `make_joint_mask`, `make_joint_limit_values`, `make_joint_diagnostic_flags` | Build runtime-sized vectors. |
| `SmoothingMethod` | `LINEAR`, `COS`, `CUBIC`, `QUINTIC`, `QUINTIC_PATH`, `NONE`. |
| `RobotState` | `STARTUP`, `IDLE`, `MOVING`, `SETTLING`, `ERROR`, `RECOVERY`, `SHUTDOWN`. |
| `PlanResult` | `SUCCESS`, `POSE_NOT_REACHABLE`, `LINEAR_PATH_FAILED`, `NONE`. Use `is_plan_result_ok()` to test success/idle. |
| `SystemStatus` | Aggregated status: `robot_state`, `plan_result`, `robot_diagnostic_flags`, `arm_size`, `gripper_size`, per-arm/per-gripper joint diagnostic flags (`[arm][joint]`). |
| `DiagnosticFlags` | Bitmask flags for target/actuator saturation, jump limits, boundary safety, planner events, and hardware/tracking faults. |

### SDK-owned connection liveness

`robot.is_connected()` and `robot.get_connection_status()` report the SDK watchdog state. `ConnectionStatus` exposes `connected`, `telemetry_timed_out`, `receive_age_ms`, and `receive_timeout_ms` (3000). The background heartbeat thread detects silence independently of application polling. Authenticated packets matching the robot reset the receive timer even if timestamp/sequence filtering rejects the state.

The timeout latches until reconnect. Late packets cannot revive an expired session. Control ownership and operation errors do not disconnect a session that continues receiving valid RT packets. Timeout stops SDK transport loops and wakes waiting operations; thread joining and socket cleanup are performed inside the SDK on disconnect, reconnect, or destruction. Status freshness remains separate from connection liveness.


## Public arm handles

`from robot_sdk import Robot, Arm, DualArm` is available without the internal
module. After checking connect(), use `robot.arm(index)` for per-arm control and
`robot.dual_arm()` for synchronized motion. For example:

```python
both = robot.dual_arm()
check_result(both.enable_arm_joint(robot.arm(0).all_enabled_mask(),
                                   robot.arm(1).all_enabled_mask()), "enable")
check_result(both.move_pos_and_wait(q0, q1), "move")
```

Both arms share v/t and each joint vector must match its arm's DOF. The handle
keeps its Python Robot alive. Reacquire after reconnecting. dual_arm() requires
a connected robot with at least two arms and otherwise raises RobotError.
Existing Robot convenience methods retain their behavior. Internal imports
re-export the same Arm/DualArm Python types for compatibility. C and CLR
component handle APIs are outside this change.


For component scope, language capabilities, explicit timing adapters and the exact
completion guarantees, see [the user guide](USER_GUIDE.md#component-api-and-language-capabilities).

The numeric v/t overloads of joint move/home methods that now accept MotionOptions
are deprecated. Prefer the same method name with a MotionOptions argument. Existing
numeric calls remain compatible until a future major release; see the user guide
for the exact scope and migration examples.
