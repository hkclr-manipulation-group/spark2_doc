# Robot SDK API (C++)

Maintenance API boundary: TCP calibration solving, detailed diagnostics/metrics/fault callbacks and fault recovery are internal SDK features. Use the Robot Client UI for these operations. C++ trusted clients include `robot_internal.h` / `tcp_calibration.h` and link `robot::internal_sdk`; Python trusted clients import `robot_sdk.internal`. These entry points are removed from the public C++, Python, C and CLR surfaces. This is a source/API breaking change; rebuild affected consumers. Basic SystemStatus/raw flags, connection state, ordinary state/motion events, known tool offsets and stop commands remain public.

- **Requirements:** C++17, CMake 3.21+
- **Integration:** `find_package(robot_sdk)` → link `robot::sdk`
- **Main header:** `#include "robot_sdk.h"` (kinematics: `#include "robot_kinematics/kinematics.h"` when included in your release)

## Quick start

Link against the installed SDK prefix (set `CMAKE_PREFIX_PATH` to your release directory):

```cmake
cmake_minimum_required(VERSION 3.21)
project(my_app LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)

find_package(robot_sdk REQUIRED)

add_executable(my_app main.cpp)
target_link_libraries(my_app PRIVATE robot::sdk)
```

```bash
cmake -S . -B build -DCMAKE_PREFIX_PATH=/path/to/sdk
cmake --build build --parallel
```

On Linux, packaged releases usually resolve bundled libraries via `$ORIGIN` RPATH. On Windows, keep `robot_sdk.dll` (and any bundled DLLs) next to your executable or on `PATH`.

Minimal session:

```cpp
#include "robot_sdk.h"

robot::Robot robot;
if (robot::RobotResult r = robot.connect(robot::RtConnectionInfo{}); !r) {
    // handle connect failure
}
```

Offline **Kinematics** uses the `configuration/` directory from the same SDK release. The live **Robot** class does not load it.

---

## Return values and errors

Command-style APIs (`connect`, `move*`, `set*`, teach/playback, …) return `RobotResult`.

```cpp
#include "robot_sdk.h"
#include <iostream>

robot::Robot robot;
if (robot::RobotResult result = robot.connect(robot::RtConnectionInfo{}); !result) {
    std::cerr << "connect failed: " << result.message
              << " (" << robot::errorCodeToString(result.code) << ")\n";
    return 1;
}
```

| Still throws | Returns `RobotResult` |
|---|---|
| Invalid arguments (`std::invalid_argument`) | Connection / motion / config ACK failures |
| Control lost (`RobotException`, code `kControlLost`) | Transport unavailable, timeout, keys load failure |
| Query APIs before start (`getPos`, `getStatus`, …) | Jog stream send success (execution still async) |

`RobotResult` fields: `code` (`RobotErrorCode`), `message`, `ok()`.

| `RobotErrorCode` | Typical cause |
|---|---|
| `kOk` | Success |
| `kNotStarted` | Robot session not started |
| `kTransportUnavailable` | UDP client not ready |
| `kTimeout` | ACK or SrvState wait timeout |
| `kKeysLoadFailed` | Embedded SDK client keys failed to load |
| `kStartFailed` | Wrapped start/stream failure |
| `kCommandRejectedFaulted` | Robot faulted |
| `kCommandRejectedSequence` | Stale sequence ID |
| `kCommandInvalid` | Invalid command payload |
| `kInvalidClientOrSession` | Auth/session mismatch |
| `kInvalidConfig` | Invalid configuration |
| `kConfigAckFailed` | Config ACK failed |
| `kCommandAckFailed` | Command ACK failed |
| `kControlLost` | Used with `RobotException` only |
| `kMotionInterrupted` | Motion failed or robot entered ERROR while waiting |
| `kPoseNotReachable` | IK or planner could not reach target pose |
| `kRecoveryFailed` | Platform recovery request rejected |
| `kReleaseControlFailed` | Platform release-control request rejected |
| `kDisconnectFailed` | Platform `SdkDisconnectReq` rejected / timed out (local teardown still proceeds) |
| `kUnknown` | Unmapped platform status |

Motion APIs returning `kOk` mean the command was sent locally; they do not prove RT admission or successful planning. Use `waitUntilIdle()` / `moveAndWait()` to block until execution completes, or poll `getStatus()` manually.

With an updated RT, `movePosAndWait()` / `waitUntilIdle()` return a specific execution rejection immediately after receiving matching telemetry, even if the robot remains Idle. Invalid targets, an out-of-range measured start, and a trajectory crossing a joint limit return `CommandInvalid`; a position-boundary stop returns `MotionInterrupted`. Messages include the command sequence and available arm/joint context (indices start at 0). These are motion errors, not hardware faults requiring recovery.

`MOTION_COMMAND_REJECTED` marks terminal rejection. Decode `TARGET_POS_OUT_OF_RANGE`, `MOTION_START_POS_OUT_OF_RANGE`, `MOTION_PROFILE_POS_OUT_OF_RANGE`, `MOTION_BOUNDARY_BLOCKED`, or `PLAN_INVALID_SETTING` from system/joint diagnostic flags for the cause. RT retains the rejection until a new command, configuration, fault/recovery transition, or control-owner change; waits match client/session/command sequence to ignore stale rejections. Nonblocking motion still returns after sending; inspect status diagnostics or call the wait API for the eventual result. Older RT versions without these flags retain the existing timeout behavior. The UDP state layout is unchanged.

### Thread safety

A single `Robot` instance is **not thread-safe**. Call motion, query, and connection APIs from one application thread (or serialize access with your own mutex). Telemetry event handlers run on a dedicated SDK event thread — never on a transport thread — so a slow handler cannot stall telemetry reception or trip the 3 s receive watchdog; handlers for one `Robot` are serialized. `on_motion_done` runs on the thread that called `waitUntilIdle()` / `moveAndWait()`.

Calling `disconnect()` from an event callback is supported: the session is closed and the RT session removed immediately, but the socket close and thread joins are deferred until the next application-thread API call (or `~Robot`) because that callback is still running on an SDK thread. Do not call blocking motion APIs or `connect()` from an event callback — poll motion state from your application thread instead.

`waitUntilIdle()` returns `RobotResult`, but it may still throw `RobotException` with `kControlLost` if another client takes control while waiting. Wrap calls in `try/catch (const RobotException&)` when control loss must be handled gracefully.

---

## Logging

Configure via `robot_sdk.h` (no separate logging header is installed):

```cpp
#include "robot_sdk.h"

robot::setLogLevel(robot::LogLevel::kDebug);
robot::setLogToFile(true);              // writes logs/robot_YYYY-MM-DD.log
robot::setLogToStderr(true);            // default true; independent of file
```

When file logging is enabled, the SDK creates `logs/` (cwd-relative) if needed and appends to `logs/robot_YYYY-MM-DD.log`, rotating automatically at local midnight. File lines include a timestamp prefix. Default stderr format remains `[Robot][INFO][Connection] ...`.

---

## Core SDK API (`Robot`)

Fault recovery and session setup after physical-button recovery are performed through the UI or internal SDK. Public SDK applications should handle motion errors and reconnect after recovery if their session is no longer ready. Old streams and cached motion targets are invalidated; submit a new command after setup.

| API | Description | Group |
|---|---|---|
| `Robot()` | Create SDK client for rt_control networking. | constructor |
| `enumerateRobots()` | Probe the network; return `vector<DiscoveredRobot>`. Call before `connect(robot)` / `connect(info)`. | connection |
| `connect(robot), connect(info)` | Connect to rt_control via enumerated robot or `RtConnectionInfo` (empty `server_ip` auto-discovers). | connection |
| `disconnect()` | Send `SdkDisconnectReq`, wait for ACK, then stop heartbeats/transport. Next `connect()` gets a new session. | connection |
| `armCount()`, `gripperCount()` | Arm / gripper slot counts from RT (0 before `connect()`). | connection |
| `robotName()` | RT `robot_name` from config (empty before `connect()`). | connection |
| `releaseControl()` | Release SDK control token only (session may remain until disconnect/heartbeat timeout). | connection |
| `stopMotion(wait_for_command_ack=false)` | Hold at current pose via Core command; **does not** enter ERROR/Fault. Default: no ACK wait (fastest stop). | motion |
| `triggerSafeguardStop()` | Protective software stop (`SdkSafeguardReq` on monitoring UDP **8882**, same as Panel abort). Latches until `SrvState` reports `ERROR`. Not hardware E-stop. | safety |
| `getNetworkConfig(out_config, ack_timeout_ms=5000)` | Read robot network settings (WiFi password masked). Requires `connect()`. | network |
| `setWifi(ssid, password, enable=true, ack_timeout_ms=10000)` | Connect robot WiFi to a router (STA mode). | network |
| `setEthStatic(eth_ip, eth_netmask, eth_gateway, eth_dns="", ack_timeout_ms=5000)` | Set wired static IP (connection drops; reconnect with new IP). | network |
| `resetNetworkConfig(ack_timeout_ms=10000)` | Restore factory network settings. | network |
| `jointCount()`, `gripperJointCount()`, `jointNames()` | Runtime DOF for arm slot 0; `jointNames()` returns generic `j1`…`jN` from DOF (0 / empty before `connect()`). | connection |
| `zeroJoints()`, `allEnabledMask()` | Helpers sized to `jointCount()` / `gripperJointCount()`. | connection |
| `enableArmJoint(arm_state)` | Enable arm slot 0 joints; `JointMask` length must match `jointCount()`. | connection |
| `waitUntilIdle(timeout_sec=30, poll_interval_sec=0.1)` | Poll until robot finishes motion or reports failure. | motion completion |
| `moveAndWait(move, timeout_sec=30, poll_interval_sec=0.1)` | Run a move lambda, then wait until idle. | motion completion |
| `movePosAndWait(arm_pos, v=50, t=0, ...)` | Arm-0 target arrival (1 degree) plus fresh settled Idle. | motion completion |
| `goHomeAndWait(v=50, t=0, ...)` | Arm-0 zero-target arrival (1 degree) plus fresh settled Idle. | motion completion |
| `setArmSmoothingMethod(method)` | Select smoothing strategy for single-target arm motion. | motion mode |
| `movePos(arm_pos, v=50, t=0)` | Joint-space target for arm slot 0; `JointValues` length = `jointCount()`. | manual motion |
| `movePosPath(path, vPath, tPath)` | Joint-space waypoints for arm slot 0; each vector length = `jointCount()`. | manual motion |
| `moveVel(arm_vel, a=10, t=0)` | Joint-space velocity for arm slot 0; length = `jointCount()`. | manual motion |
| `moveEEPoint(pose, v=50, t=0)` | Move end-effector to cartesian pose (point mode). | manual motion |
| `moveEEPointPath(path, vPath, tPath)` | Move through end-effector pose waypoints (point mode). | manual motion |
| `moveEELine(pose, v=50, t=0)` | Move end-effector to cartesian pose (line mode, arm slot 0). | manual motion |
| `moveEELinePath(path, vPath, tPath)` | Move through end-effector pose waypoints (line mode, arm slot 0). | manual motion |
| `moveToolPoint(pose, v=50, t=0)` | Move tool frame to cartesian pose (point mode). | manual motion |
| `moveToolPointPath(path, vPath, tPath)` | Move tool frame through cartesian waypoints (point mode). | manual motion |
| `moveToolLine(pose, v=50, t=0)` | Move tool frame to cartesian pose (line mode). | manual motion |
| `moveToolLinePath(path, vPath, tPath)` | Move tool frame through cartesian waypoints (line mode). | manual motion |
| `goHome(v=50, t=0)` | Move robot arm to predefined home pose. | manual motion |
| `moveGripperPos(pos, v=50, t=0)` | Command gripper joints in panel units `[0,1]` (`0`=open, `1`=close); length = `gripperJointCount()`. Not soft/hard safety limits. | manual motion |
| `moveGripperPosAndWait(pos, …)` | `moveGripperPos` + wait on gripper feedback (RT may stay Idle during gripper-only moves). | motion completion |
| `startTeach(), stopRecording(), stopTeach()` | Start drag/recording; freeze recording while allowing drag; end teaching with position hold. | [teaching lifecycle](teaching_lifecycle.md) |
| `saveTrajectory(local_path)` | Export a frozen RT recording to a client-side JSON file; requires a compatible RT. | [teaching lifecycle](teaching_lifecycle.md) |
| `startPlayback(), stopPlayback(), resetPlayback()` | Control playback mode lifecycle. | playback mode |
| `getJointState(), getJointVel(), getJointTor()` | Arm slot 0 joint feedback with runtime-sized vectors. | feedback |
| `jointPositions()` | Arm slot 0 positions only (`JointValues`, length = `jointCount()`). | feedback |
| `getEEPose(), getToolPose()` | Arm slot 0 end-effector / tool cartesian pose. | feedback |
| `getArmJointEnabledMask()` | Arm slot 0 per-joint enable mask (length = `jointCount()`). | status |
| `getStatus(), printStatus(status)` | Read or print aggregated runtime status (`SystemStatus`). Joint diagnostics are indexed `[arm][joint]`. | status |
| `getConnectionStatus()` / `isConnected()` | SDK-owned connection state; autonomous 3000 ms RT receive timeout. | diagnostics |
| `getConfigurator()` | Access RT configuration subsystem for arm slot 0. | subsystems |

A single `Robot` session owns the UDP connection. On dual-arm robots, the convenience methods directly on `Robot` target **arm slot 0**; use public `arm(index)` handles for other arms and `dualArm()` (Python: `dual_arm()`) for synchronized motion. Use `armCount()` / `gripperCount()` after `connect()` to inspect topology; `waitUntilIdle()` waits for the whole robot.


## Configuration (`configuration/`)

| Source | Purpose |
|---|---|
| **Built-in model registry + URDF/meshes** | Offline kinematics via standalone `Kinematics(config_prefix_path)` |
| **SDK built-in HMAC keys** | UDP message authentication (client_id 0 + 10003) |
| **SDK built-in defaults** | Protocol ports, receive timing, default motion parameters |
| **`RtConnectionInfo` / `enumerateRobots()`** | Target RT server IP |
| **RT `SdkConfigRes` after `connect()`** | Authoritative limits, modes, tool offset (`Configurator` getters) |

`config.yaml` is optional for **Kinematics** only. **Robot** does not load it. See [BREAKING_CONFIG.md](BREAKING_CONFIG.md).

Recommended connection patterns:

```cpp
// Auto-discover rt_control on the network (default empty server_ip).
Robot robot;
if (RobotResult result = robot.connect(RtConnectionInfo{}); !result) { /* ... */ }

// Known RT server IP.
Robot robot;
if (RobotResult result = robot.connect(RtConnectionInfo::to("192.168.1.10")); !result) { /* ... */ }

// Enumerate multiple robots, then connect to one.
Robot robot;
auto robots = robot.enumerateRobots();
if (!robots.empty()) {
    if (RobotResult result = robot.connect(robots.front()); !result) { /* ... */ }
}
```

## RT connection

`RtConnectionInfo` exposes only `server_ip` in the public API. UDP ports are fixed SDK defaults.

| Field | Default | Description |
|---|---|---|
| `server_ip` | `""` (auto-discover) | RT server IP; set via `RtConnectionInfo::to(ip)` or `connect(info)` |

Helper: `RtConnectionInfo::to(server_ip)` — connect to a known RT host.

Other protocol settings (heartbeat port, telemetry port, client id, multicast probe) are fixed SDK defaults and are not configurable in the public API.

Pass connection settings to `connect(info)` or `connect(robot)` when starting a session.

Path APIs accept either a velocity path (`v`) or a time path (`t`) matching the waypoint count. When only `t` is supplied, the SDK fills each waypoint with the default speed ratio (50%).

Motion speed `v` / `a` is in `[0, 100]` percent and maps to `interpolation_speed_ratio` (`v / 100`). Per RT planner: `v > 0` sets an explicit ratio; `v = 0` sends ratio `0` and **keeps the current speed ratio unchanged** (not max speed). Use `v = 100` for full speed.

Normal motion commands return after the UDP command is sent; they do not wait for a command ACK. Configuration changes still wait for their ACK. Use `movePosAndWait`, `goHomeAndWait`, or `waitUntilIdle` when completion confirmation is required.

## Examples (`examples/cpp/`)

Public motion examples use shared helpers in `example_common.h`:

| Helper | Description |
|---|---|
| `robotIpFromArgs(argc, argv)` | Parse optional `[IP]` or `--ip IP` from the command line |
| `connectToRobot(robot, ip)` | Connect via `RtConnectionInfo::to(ip)` when `ip` is non-empty, else `requireFirstRobot()` |
| `requireFirstRobot()` | Enumerate and return the first robot (exits if none found) |
| `ROBOT_CHECK(result, context)` | Print and return 1 on failure |

```bash
cmake -S /path/to/prefix/examples/cpp -B build -DCMAKE_PREFIX_PATH=/path/to/prefix
cmake --build build --parallel
./build/move_point
./build/move_point 192.168.1.10
./build/network_config --ip 192.168.1.10
./build/network_config --ip 192.168.1.10 --set-eth 192.168.2.100 255.255.255.0 192.168.2.1
```

Typical example flow:

```cpp
#include "example_common.h"

using namespace robot;
using namespace robot_example;

int main(int argc, char* argv[]) {
    Robot robot;
    ROBOT_CHECK(connectToRobot(robot, robotIpFromArgs(argc, argv)), "connect");
    // ...
}
```

See `connection_options.cpp` for auto-discover, fixed IP, and enumerate-first patterns. Kinematics examples under `calculate_kinematics.cpp` do not connect to rt_control.

## Configuration API (`Configurator`)

| API | Description |
|---|---|
| `setToolOffset(offset), setArmPosLimits(limit), setArmVelLimits(limit), setGripperPosLimits(limit)` | Set configuration; return `RobotResult`. |
| `getToolOffset(), getArmPosLimits(), getArmVelLimits(), getGripperPosLimits()` | Read active configuration values. |
| `getArmMaxPos(), getArmMaxVel()` | Get hardware max position/velocity constraints. |
| `getArmMaxPosJump(), getArmMaxVelJump()` | Get anti-jump protection limits. |
| `getArmMaxPosFollowError(), getArmMaxVelFollowError(), getArmMaxTorFollowError()` | Get following-error thresholds. |
| `getGripperMaxPos()` | Get gripper hardware max range. |

## Kinematics API (`Kinematics`)

Standalone class — not part of `Robot`. Requires a configuration directory with URDF/meshes.

| API | Description |
|---|---|
| `Kinematics(config_prefix_path, model_id="")` | Load built-in model from URDF under `config_prefix_path`; optional `model_id` overrides `config.yaml` / default `spark2_v2`. |
| `jointCount()` | Active DOF for the loaded kinematics model. |
| `forwardKinematics(arm_pos)` | Compute cartesian pose from joint state (length = `jointCount()`). |
| `inverseKinematics(ee_pose, arm_pos)` | Solve joint state for a target cartesian pose; returns `RobotResult` and updates `arm_pos` on success. |
| `eulerToQuaternion(euler)` | Convert intrinsic XYZ Euler angles to quaternion. |
| `quaternionToEuler(quat)` | Convert quaternion to intrinsic XYZ Euler angles. |
| `eeToToolPose(ee_pose, tool_offset)` | Transform end-effector pose into tool pose. |
| `toolToEEPose(tool_pose, tool_offset)` | Transform tool pose into end-effector pose. |

## Types (`robot_sdk/types.h`)

| Type / Enum | Description |
|---|---|
| `DiscoveredRobot` | Result of `enumerateRobots()` (`server_ip`, `robot_name`, …). |
| `NetworkConfig` | Network settings from `getNetworkConfig()` (`eth_ip`, `wifi_ssid`, …). |
| `Position`, `Quaternion`, `EulerAngle` | Cartesian position, orientation, and intrinsic XYZ Euler angles. |
| `Pose` | Cartesian pose = `Position` + `Quaternion` orientation. |
| `JointValues`, `JointMask`, `JointState` | Variable-length joint vectors, enable masks, and arm+gripper feedback. Length must match `jointCount()` / `gripperJointCount()` after connect. Prefer `zeroJoints()` / `makeJointValues()`. |
| `JointLimitValues`, `JointDiagnosticFlags` | Variable-length per-joint limit pairs and diagnostic flag vectors. |
| `makeJointValues(count, fill=0)`, `makeJointMask(count, enabled=true)` | Build vectors sized to runtime DOF. |
| `makeJointLimitValues(count, fill={-90,90})`, `makeJointDiagnosticFlags(count, fill=0)` | Build limit/diagnostic vectors sized to runtime DOF. |
| `Path<T>` | Waypoint sequence (`std::vector<T>`). |
| `JointLimits<T>` | Per-joint min/max limits for arm and gripper. |
| `SmoothingMethod` | `kLinear`, `kCos`, `kCubic`, `kQuintic`, `kQuinticPath`, `kNone`. |
| `RobotState` | `kStartup`, `kIdle`, `kMoving`, `kSettling`, `kError`, `kRecovery`, `kShutdown`. |
| `PlanResult` | `kSuccess`, `kPoseNotReachable`, `kLinearPathFailed`. |
| `SystemStatus` | Aggregated status: `robot_state`, `plan_result`, `robot_diagnostic_flags`, `arm_size`, `gripper_size`, per-arm/per-gripper joint diagnostic flags (`[arm][joint]`). |
| `DiagnosticFlags` | Bitmask flags for target/actuator saturation, jump limits, boundary safety, planner events, and hardware/tracking faults. |

The timeout latches until reconnect. Late packets cannot revive an expired session. Control ownership and operation errors do not disconnect a session that continues receiving valid RT packets. Timeout stops SDK transport loops and wakes waiting operations; thread joining and socket cleanup are performed inside the SDK on disconnect, reconnect, or destruction. Status freshness remains separate from connection liveness.


## Component handles and header organization

`#include <robot_sdk.h>` includes Robot, Arm and DualArm. For selective inclusion,
use `robot_sdk/robot.h` with `robot_sdk/arm.h` and/or `robot_sdk/dual_arm.h`.
Robot owns the connection, whole-robot state/events and stop commands. Arm owns
per-arm motion, feedback, enabling and configuration. DualArm owns synchronized
arm-0/arm-1 motion and `enableArmJoint(mask0, mask1)` in one configuration packet.

```cpp
#include <robot_sdk.h>
robot::Robot robot;
// Check connect() before obtaining a DualArm handle.
// robot.connect(robot::RtConnectionInfo::to("192.168.1.10"));
// robot.arm(0).movePos(q0);
// robot.dualArm().movePosAndWait(q0, q1);
```

Both arms share v/t; joint vectors match each arm's runtime DOF. Path waypoint
counts must match. Sequential per-arm commands do not synchronize both arms.
Acquiring dualArm() throws RobotException before connection or with fewer than
two arms; motion methods return RobotResult. Handles borrow the Robot: do not
outlive it, and reacquire them after moving the Robot or reconnecting.
Existing Robot motion, feedback and gripper convenience methods retain their
arm-0 semantics (including goHome); setArmSmoothingMethod still applies to all
arms. Use dualArm().goHome() for synchronized two-arm homing.

Future supported Head/Waist/Base/Gripper controls should get separate typed
headers and Robot accessors. No placeholder API or new hardware support is
introduced here. Existing gripper methods remain on Robot and Arm. Generic
Component/CommandFrame/ControlStream and maintenance APIs remain internal.
C and CLR APIs retain their current scope; these new component handles are
published for C++ and Python.


For component scope, language capabilities, explicit timing adapters and the exact
completion guarantees, see [the user guide](USER_GUIDE.md#component-api-and-language-capabilities).

The numeric v/t overloads of joint move/home methods that now accept MotionOptions
are deprecated. Prefer the same method name with a MotionOptions argument. Existing
numeric calls remain compatible until a future major release; see the user guide
for the exact scope and migration examples.
